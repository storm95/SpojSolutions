#include<bits/stdc++.h>
using namespace std;
int dx[]={-1,-1,-1,0,1,1,1,0};
int dy[]={-1,0,1,1,1,0,-1,-1};
int len =  0;
bool vis[65][65] ;
char mat[65][65];
int n,m;
bool valid(int i,int j)
{
    if(i<0 || j<0 || i>=n ||  j>=m)
        return false;
    return true;
}
int res =  0;



void dfs(int x,int y,int len)
{
vis[x][y] = true;
res = max(res,len);
for(int i = 0 ;  i< 8;i++)
{
    int nbx = x + dx[i];
    int nby = y + dy[i];
    if(!vis[nbx][nby] && valid(nbx,nby))
    {

        if(mat[nbx][nby] == (char)(mat[x][y]+1))
            {
                vis[nbx][nby] = true;
                dfs(nbx,nby,len+1);
            }
    }
}
}


int main()
{
    int tc = 1 ;
    scanf("%d%d",&n,&m);
    while(n || m)
    {
    res = 0 ;
    memset(vis,0,sizeof(vis));
    memset(mat,' ',sizeof(mat));
    len = 0 ;
    for(int i=0;i<n;i++)
        scanf("%s",mat[i]);
    bool flag=false; 
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
            if(mat[i][j]=='A')
            {
            	flag = true;
                memset(vis,0,sizeof(vis));
                len = 0 ;
                dfs(i,j,0);
            }
    }
    if(flag)
    printf("Case %d: %d\n",tc++,res+1);
    else printf("Case %d: %d\n",tc++,0);
    scanf("%d%d",&n,&m);
    }
    return 0;
}
