#include <bits/stdc++.h>
#define mp make_pair
using namespace std;
static int fix[][2]={{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
char s[55][55];
int dp[55][55];
bool mark[55][55];
int n,m;
int solve(int a,int b)
{
    memset(mark,true,sizeof(mark));
    mark[a][b]=false;
    queue< pair<int, pair<int,int> > > que;
    que.push(mp(1,mp(a,b)));
    int l;
    while(!que.empty())
    {
        l=que.front().first;
        int x=que.front().second.first;
        int y=que.front().second.second;
        que.pop();
        for(int i=0;i<8;i++)
        {
            a=x+fix[i][0];
            b=y+fix[i][1];
            if(a>=0 && a<n && b>=0 && b<m)
            {
                int k=s[x][y];
                int p=s[a][b];
                if(mark[a][b] && p==k+1)
                {
                    mark[a][b]=false;
                    que.push(mp(l+1,mp(a,b)));
                }
            }
        }
    }
return l;
}
int main()
{
    int t=0;
    while(1)
    {
        t++;
        scanf("%d%d",&n,&m);
        if(n==0 && m==0) return 0;
        for(int i=0;i<n;i++) scanf("%s",s[i]);
        int ans=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(s[i][j]=='A')ans=max(ans,solve(i,j));
            }
        }
        printf("Case %d: %d\n",t,ans);
    }

    return 0;
}
