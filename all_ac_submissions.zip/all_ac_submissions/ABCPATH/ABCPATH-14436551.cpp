#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
int n,m,f=0,vis[55][55],mx;
char dp[55][55];
int dfs(int i,int j)
{
       if(vis[i][j]!=-1)
        return vis[i][j];
       else
       {
        vis[i][j]=1;
        int dx[8]={0, 0, 1, -1, 1, 1, -1, -1};
        int dy[8]={1, -1, 0, 0, 1, -1, 1, -1};
        int mx =-1;
        for(int p=0;p<8;p++)
        {
                int nx=i+dx[p],ny=j+dy[p];
                if(nx>=0&&nx<n&&ny>=0&&ny<m)
                {
                    if(dp[nx][ny]==dp[i][j]+1)
                    {
                        vis[i][j]=max(vis[i][j],dfs(nx,ny)+1);
                    }
                }
       }

       }
       return vis[i][j];
}

int main()
{
    int t=1,i,j;
    sfd(n);
    sfd(m);
    while(n!=0&&m!=0)
    {

        mx=-1;

         scanf("%*c");
        for(i=0;i<n;i++)
        {
          sfs(dp[i]);
        }
         scanf("%*c");
        memset(vis,-1,sizeof(vis));
        mx=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(dp[i][j]=='A'&&vis[i][j]==-1)
                {
                    mx=max(mx,dfs(i,j));
                }
            }
        }
        cout<<"Case "<<t<<": ";
        t++;
        pfd(mx);
     sfd(n);
     sfd(m);
    }
    return 0;
}
