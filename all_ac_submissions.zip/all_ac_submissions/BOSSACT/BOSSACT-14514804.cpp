#include<bits/stdc++.h>
using namespace std;
bool comp(pair<int,int> a,pair<int,int> b)
	{
		if(a.second < b.second)
			return true;
		else return false;
	}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
		{
			int n;
			scanf("%d",&n);
			vector<pair<int,int> >v;
			for(int i=0;i<n;i++)
				{
					int s,e;
					scanf("%d %d",&s,&e);
					v.push_back(make_pair(s,e));
				}
		sort(v.begin(),v.end(),comp);
		int res  = 1;
		int prev = v[0].second;
		for(int i=1;i<n;i++)
			{
				if(v[i].first >= prev)
					{
						res++;
						prev = v[i].second;
					}
			}
		printf("%d\n",res);
		}
	return 0;
}