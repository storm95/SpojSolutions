#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char a[502],b[502];
    int i,c;
    char d[2]="*";
    scanf("%s %s",&a,&b);
    while((strcmp(a,d)!=0)&&(strcmp(b,d)!=0))
    {
        i=0,c=0;
        while(a[i]!='\0')
        {
          if(a[i]!=b[i]&&a[i+1]==b[i+1])
            c+=1;
            i++;
        }

    printf("%d\n",c);
    scanf("%s %s",&a,&b);
    }
    return 0;
}
