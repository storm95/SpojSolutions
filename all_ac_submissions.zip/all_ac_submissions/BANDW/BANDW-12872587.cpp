#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s,t;
	int i;
	while(cin>>s&&cin>>t)
	{
		if(s[0]=='*')
		break;
		int len=s.length();
		int ans=0;
		for(i=0;i<len;++i)
		{
			if(s[i]!=t[i])
			{
				while(i<len&&s[i]!=t[i])
				++i;
				++ans;
			}
		}
		printf("%d\n",ans);
	}
}
