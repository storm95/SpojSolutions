#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    int l,i,o,counter=0;
    char str1[100000],str2[100000];
    scanf("%s %s",str1,str2);
    while(str1[0]!='*'&&str2[0]!='*')
    {
        o=0;
        counter=0;
        l=strlen(str1);
        for(i=0;i<l;i++)
        {
            if(str1[i]!=str2[i])
            {
                if(o==0)
                    counter++;
                o=1;
            }
            else
                o=0;
        }
        printf("%d\n",counter);
        scanf("%s %s",str1,str2);
    }
    return 0;
}
