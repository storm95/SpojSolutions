#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    int l,i,j,ct;
   char a[503],b[503];
   cin>>a;
   cin>>b;
   while(a[0]!='*')
   {
      l=strlen(a);
      j=1;
      ct=0;
        for(i=0;i<l;i++)
        {
                if(a[i]==b[i])
                {
                    j=1;
                }
                else if(j==1)
                {
                    ct++;
                    j=0;
                }
        }

        /*if(j!=0&&ct==0)
            cout<<"1"<<endl;
        else*/
        cout<<ct<<endl;
         cin>>a;
   cin>>b;
   }
    return 0;
}
