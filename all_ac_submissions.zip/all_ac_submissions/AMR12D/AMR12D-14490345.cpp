#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        char s[101];
        scanf("%s",s);
        int l=strlen(s);
        int f=0;
        for(int i=0;i<=l/2;i++)
        {
            if(s[i]!=s[l-i-1])
            {
                f=1;
                break;
            }
        }
        if(f==0) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}