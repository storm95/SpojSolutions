#include<bits/stdc++.h>
using namespace std;
int main()
{
	int tc;
	cin>>tc;
	while(tc--)
	{
		string s;
		cin>>s;
		if(s!=string(s.rbegin(),s.rend()))
		cout<<"NO\n";
		else
		cout<<"YES\n";
	}
}