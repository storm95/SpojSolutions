#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
int t,middle,len,end,i;
    char arr[1000001];
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s",arr);
        len=strlen(arr);
        if(len==1)
            printf("YES\n");
        else if(len==2)
        {
            if(arr[0]==arr[1])
                printf("YES\n");
            else
                printf("NO\n");
        }
        else
        {
            if(len%2==0)
            {
                middle=len/2-1;
                end=len-1;
                for(i=0;i<=middle;i++)
                {
                    if(arr[i]==arr[end])
                        end=end-1;
                    else{
                        printf("NO\n");
                        break;
                    }
                }
                if(i==middle+1)
                    printf("YES\n");
            }
            else
            {
                middle=len/2;
                end=len-1;
                for(i=0;i<middle;i++)
                {
                    if(arr[i]==arr[end])
                        end=end-1;
                    else
                    {
                        printf("NO\n");
                        break;
                    }
                }
                if(i==middle)
                    printf("YES\n");
            }
        }
    }





    return 0;
}

