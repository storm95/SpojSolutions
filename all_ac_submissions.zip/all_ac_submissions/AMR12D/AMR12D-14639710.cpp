#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;

int main()
{
    int t,i,j,f;
    string s;
    sfd(t);
    while(t--)
    {
       cin>>s;
       i=0;
       j=s.length()-1;
       f=0;
       while(i<=j)
        {
            if(s.at(i)!=s.at(j))
            {
                f=1;
                break;
            }
            i++;
            j--;
        }
        if(f)
            cout<<"NO\n";
        else
            cout<<"YES\n";
    }
    return 0;
}
