#include<iostream>
#include<cstdio>
#include<deque>
int arr[1000000];
void sub(int arr[],int n,int k)
{
    std::deque<int> q(k);
    int i;
    for(i=0;i<k;++i)
    {
        while((!q.empty())&&(arr[i]>=arr[q.back()]))
            q.pop_back();
        q.push_back(i);
    }
    for(;i<n;++i)
    {
        printf("%d ",arr[q.front()]);
        while((!q.empty())&&(q.front()<=i-k))
            q.pop_front();
        while((!q.empty())&&(arr[i]>=arr[q.back()]))
            q.pop_back();
        q.push_back(i);
    }
    printf("%d",arr[q.front()]);
}
using namespace std;
int main()
{
    int tc,n,i,k;
        scanf("%d",&n);
        printf("\n");
        for(int i=0;i<n;i++)
            scanf("%d",&arr[i]);
        scanf("%d",&k);
        sub(arr,n,k);
    return 0;
}
