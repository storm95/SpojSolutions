#include<bits/stdc++.h>
using namespace std;
deque<int> s;
int a[1000100];
int main()
{
	int n,k,i,j,l,maxi;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	scanf("%d",&a[i]);
	scanf("%d",&k);
	for(i=0;i<k-1;++i)
	{
		while((!s.empty())&&(a[s.back()]<=a[i]))
		s.pop_back();
		s.push_back(i);
	}
	for(i=k-1;i<n;++i)
	{
		while((!s.empty())&&((i-s.front())>=k))
		s.pop_front();
		while((!s.empty())&&(a[s.back()]<=a[i]))
		s.pop_back();
		s.push_back(i);
		printf("%d ",a[s.front()]);
	}
	return 0;
}
