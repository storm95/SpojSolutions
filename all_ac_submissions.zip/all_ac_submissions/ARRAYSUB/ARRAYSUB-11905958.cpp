#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int n,k,t,f,i,j,a;
    long long int tot;
    map<int,int > m;
    scanf("%lld",&a);
    map<int,int >::iterator it;
    int arr[a];
    scanf("\n");
    for(i=0;i<a;i++)
    {
        scanf("%d",&arr[i]);
    }
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        if(m.find(arr[i])==m.end())
            {
                m[arr[i]]=1;
                //m[arr[i]].first=arr[i];
            }
        else
            ++m[arr[i]];
    }
    for(i=n;i<a;i++)
    {
        it=m.end();
        --it;
        printf("%d ",it->first);
        if(m.find(arr[i])==m.end())
        {
            m[arr[i]]=1;
            //m[arr[i]].first=arr[i];
        }
        else
            ++m[arr[i]];
        --m[arr[i-n]];
        if(m[arr[i-n]]==0)
            m.erase(m.find(arr[i-n]));
    }
    it=m.end();
    --it;
    printf("%d",it->first);
    return 0;
}


