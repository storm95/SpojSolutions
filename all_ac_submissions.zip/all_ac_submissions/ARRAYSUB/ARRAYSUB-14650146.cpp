#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1


using namespace std;
multiset<int>s;
multiset<int>::reverse_iterator it;
int x[1000002];
void pm(int n,int k)
{
    deque<int>q(k);
    int i;
    for(i=0;i<k;i++)
    {
        while(!q.empty()&&x[i]>=x[q.back()])
            q.pop_back();
        q.push_back(i);
    }
    for(;i<n;i++)
    {
        printf("%d ",x[q.front()]);
        while(!q.empty()&&q.front()<=i-k)
            q.pop_front();
         while(!q.empty()&&x[i]>=x[q.back()])
            q.pop_back();
        q.push_back(i);
    }
     printf("%d",x[q.front()]);
}
int main()
{
    int n,k,i;
    sfd(n);

    for(i=0;i<n;i++)
    {
        sfd(x[i]);
    }
     sfd(k);
    pm(n,k);
   /*   for(i=0;i<n;i++)
    {
     if(s.size()<k)
         s.insert(x[i]);
        else
        {
            it=s.rbegin();
            printf("%d ",*it);
            s.erase(s.find(x[i-k]));
            s.insert(x[i]);
        }
    }
     it=s.rbegin();
    printf("%d ",*it);*/
    return 0;
}
