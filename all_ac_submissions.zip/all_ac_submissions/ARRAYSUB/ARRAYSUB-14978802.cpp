#include<bits/stdc++.h>
using namespace std;
int arr[1000001];
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
        scanf("%d",&arr[i]);
    int k;
    scanf("%d",&k);
    map<int,int> mp;
    for(int i=0;i<k-1;i++) mp[arr[i]]++;
    for(int i=0;i<=n-k;i++)
    {
        mp[arr[i+k-1]]++;
        map<int,int>::reverse_iterator it=mp.rbegin();
        cout<<it->first<<" ";
        mp[arr[i]]--;
        if(mp[arr[i]]==0) mp.erase(arr[i]);
    }
    printf("\n");
return 0;
}
