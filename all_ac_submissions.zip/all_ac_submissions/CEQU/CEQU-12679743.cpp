#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
unsigned int gcd(unsigned int a,unsigned int b)
{
    if(a==b)
        return a;
    if(a==0)
        return b;
    if(b==0)
        return a;
    if(~a&1)
    {
        if(b&1)
            return gcd(a>>1,b);
        else return gcd(a>>1,b>>1)<<1;
    }
    if(~b&1)
        return gcd(a,b>>1);
    if(a>b)
        return gcd((a-b)>>1,b);
    else return gcd((b-a)>>1,a);
}
int main()
{
   int tc,a,b,c,d;
   scanf("%d",&tc);
   for(int i=1;i<=tc;i++)
   {
       c=0;
    scanf("%d %d %d",&a,&b,&d);
    c=gcd(a,b);
     if(d%c==0)
        printf("Case %d: Yes\n",i);
     else printf("Case %d: No\n",i);
    }
    return 0;
}

