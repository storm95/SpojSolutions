#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    scanf("%d",&n);
    while(n!=-1)
    {
        //printf("%d\n",n);
        int i,a;
        for(i=0;;i++)
        {
            a=1+3*i*(i+1);
            if(a==n)
            {
                printf("Y\n");
                break;
            }
            if(a>n)
            {
                printf("N\n");
                break;
            }
        }
        scanf("%d",&n);
    }
    return 0;
}
