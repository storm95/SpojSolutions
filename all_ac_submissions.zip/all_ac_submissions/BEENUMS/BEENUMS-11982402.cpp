//Behives Numbers
#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
        long long n,flag=0;
        double x;
        while(scanf("%lld",&n)!=EOF&&n!=-1)
        {
                flag=0;
                if((n-1)%3==0)
                {
                        n=(n-1)/3;
                        x=sqrt(1+4*n)-1;
                        x/=2;
                        if( x-(long int)x ==0)
                        flag=1;
                }
                if(flag)
                printf("Y\n");
                else printf("N\n");
        }
        return 0;
}
