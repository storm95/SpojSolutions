#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long int
using namespace std;
ll dp[18261];
int b_search(int l,int h,int k)
{
    if(dp[l]>k || dp[h]<k) return 0;
    if(l<=h)
    {
        int mid=l+(h-l)/2;
        if(k>dp[mid]) return b_search(mid+1,h,k);
        else if(k<dp[mid]) return b_search(l,mid-1,k);
        else return 1;
    }
    return 0;
}
int main()
{
    dp[0]=1;
    for(int i=1;i<18257;i++)
    {
        dp[i]=dp[i-1]+i*1ll*6;
    }
    while(1)
    {
        int n;
        scanf("%d",&n);
        if(n==-1) break;
        if(b_search(0,18256,n)) printf("Y\n");
        else printf("N\n");
    }
    return 0;
}
