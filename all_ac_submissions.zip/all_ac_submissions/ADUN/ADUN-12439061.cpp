#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    long long int a,b;
    scanf("%lld %lld",&a,&b);
    printf("%lld\n",a+b);
    return 0;
}
