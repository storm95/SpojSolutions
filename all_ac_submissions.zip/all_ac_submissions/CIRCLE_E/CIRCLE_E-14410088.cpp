#include<stdio.h>
#include<math.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        double R1,R2,R3;
        scanf("%lf%lf%lf",&R1,&R2,&R3);
        double S1=1/R1;
        double  S2=1/R2;
        double  S3=1/R3;
        double  K4=S1+S2+S3;
        K4+=2*sqrt((S1*S2)+(S2*S3)+(S1*S3));
        double ans=1.0/K4;
        printf("%0.6lf\n",ans);
    }
    return 0;
}
