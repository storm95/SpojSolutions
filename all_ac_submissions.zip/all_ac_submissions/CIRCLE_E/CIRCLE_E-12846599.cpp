#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        double r1,r2,r3;
        cin>>r1>>r2>>r3;
        double x= 1/(1/r1 + 1/r2 + 1/r3 + 2*sqrt(1/(r1*r2)+1/(r1*r3)+1/(r2*r3)));
        cout<<fixed<<setprecision(6)<<x<<endl;
    }
    return 0;
}
