#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;

int main()
{
    double r1,r2,r3,s,r,a,b,c,f,k;
    int t;
    cin>>t;
    while(t--)
    {
        cin>>r1>>r2>>r3;
        a=r1+r2;
        b=r2+r3;
        c=r3+r1;
        s=(a+b+c)/2;
        f=2*sqrt(s*(s-a)*(s-b)*(s-c));

            k=(2*s*s)-(a*a+b*b+c*c)+(2*f);
        r=(f*f)/(2*s*k);
       printf("%0.6f\n",r);
    }
    return 0;
}
