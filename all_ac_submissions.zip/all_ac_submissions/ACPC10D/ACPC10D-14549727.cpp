#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lf 2*idx
#define rt 2*idx+1
#define md 1000000007

using namespace std;
ll dp[100005][3],s[100005][3];
int dx[]={0,-1,-1,-1};
int dy[]={-1,-1,0,1};
int main()
{
    int n,i,j,t=1;
    sfd(n);
    while(n!=0)
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<3;j++)
                sflld(s[i][j]);
        }
        dp[0][0]=1000000;
        dp[0][1]=s[0][1];
        dp[0][2]=s[0][1]+s[0][2];
        for(i=1;i<n;i++)
        {
            for(j=0;j<3;j++)
            {
                dp[i][j]=LONG_LONG_MAX;
              for(int p=0;p<4;p++)
              {
                  int nx=i+dx[p],ny=j+dy[p];
                  if(nx>=0&&nx<n&&ny>=0&&ny<3)
                  {
                      dp[i][j]=min(dp[i][j],dp[nx][ny]+s[i][j]);
                  }
              }
            //  cout<<dp[i][j]<<" ";
            }
           // cout<<endl;
        }
        cout<<t<<". ";
        t++;
        pflld(dp[n-1][1]);
        sfd(n);
    }
    return 0;
}
