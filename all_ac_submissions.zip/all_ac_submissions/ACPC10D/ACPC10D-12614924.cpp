#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define gc getchar_unlocked
#define pc putchar_unlocked
#define all(A) A.begin(),A.end()
#define mp make_pair
#define vi vector<int>
#define pii pair<int,int>
#define pic pair<int,char>
#define vpic vector< pic >
#define vpii vector< pii > 
using namespace std;

int n,arr[100009][3],dp[100009][3];

inline int inp()
{
	register int n = 0,c = gc(),f = 1;
	while(c!='-' && (c<'0' || c>'9'))
	c = gc();
	if(c == '-')
	{
		f = -1;
		c = gc();
	}
	while(c>='0' && c<='9')
	n = (n<<3) + (n<<1) + c - '0' , c = gc();
	return (n*f);
}

int main()
{
	int idx=1;
    while(1)
    {
	  n = inp();
      if( n == 0)  return 0;
      memset(dp,0,sizeof(dp));
      for(int i=0;i<n;++i)
      {
         arr[i][0] = inp();
         arr[i][1] = inp();
         arr[i][2] = inp();
      }
      dp[0][0] = 1000000000;
      dp[0][2] = arr[0][1] + arr[0][2]; 
      dp[0][1] = arr[0][1];
      for(int i=1;i<n;++i)
      {
        dp[i][0] = min(dp[i-1][0],dp[i-1][1]) + arr[i][0];
        dp[i][1] = min(min(min(dp[i-1][0],dp[i-1][1]),dp[i-1][2]),dp[i][0]) + arr[i][1];
        dp[i][2] = min(min(dp[i-1][1],dp[i-1][2]),dp[i][1]) + arr[i][2];
      }
      printf("%d. %d\n",idx++,dp[n-1][1]);
    }
    return 0;
}
