#include<bits/stdc++.h>
using namespace std;
long long  a[100100][4];
int main()
{
	int n,i,j,k,y=0;
	long long x;
	for(i=0;i<100100;++i)
	a[i][0]=10000000000000000LL;
	while(scanf("%d",&n)&&n)
	{
		++y;
		scanf("%lld%lld%lld",&a[0][1],&a[0][2],&a[0][3]);
		a[0][1]=100000000000000LL;
		a[0][3]+=a[0][2];
		for(i=1;i<n;++i)
		{
			for(j=1;j<=3;++j)
			{
				scanf("%lld",&x);
				a[i][j]=x+min(min(a[i][j-1],a[i-1][j-1]),min(a[i-1][j],a[i-1][j+1]));
			}
		}
	/*	for(i=0;i<=n;++i)
                {
                        for(j=1;j<=3;++j)
                        {	
				printf("%lld  ",a[i][j]);
			}
			printf("\n");
		}*/
		printf("%d. %lld\n",y,a[n-1][2]);
	}
	return 0;
}
