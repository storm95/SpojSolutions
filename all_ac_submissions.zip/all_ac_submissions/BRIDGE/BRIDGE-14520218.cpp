#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
struct node
{
    int x;
    int y;
}ar[1001];
int compare(const void* a,const void* b)
{
    struct node* t=(struct node*)a;
    struct node* s=(struct node*)b;
    int k=(t->x)-(s->x);
    if(k==0)
        return (t->y)-(s->y);
    return k;
}
int dp[1001];
int solve(int n)
{
    for(int i=0;i<n;i++) dp[i]=1;
    for(int i=1;i<n;i++)
    {
        int yi=ar[i].y;
        for(int j=0;j<i;j++)
        {
            int yj=ar[j].y; 
            if(yi>=yj && dp[i]<dp[j]+1) dp[i]=dp[j]+1;
        }
    }
    int mx=dp[0];
    for(int i=0;i<n;i++){ mx=max(mx,dp[i]);}
    return mx;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        for(int i=0;i<n;i++) scanf("%d",&ar[i].x);
        for(int i=0;i<n;i++) scanf("%d",&ar[i].y);
        qsort(ar,n,sizeof(ar[0]),compare);
        printf("%d\n",solve(n));
    }
}
