#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int t,n,i,j;
    sfd(t);
    while(t--)
    {
        sfd(n);
        pair<int,int>p[n];
        int dp[1003];
        for(i=0;i<n;i++)
        {
           sfd(p[i].first);
        }
        for(i=0;i<n;i++)
        {
            sfd(p[i].second);
        }
        sort(p,p+n);
        dp[0]=1;
        for(i=1;i<n;i++)
        {
            dp[i]=1;
            for(j=i-1;j>=0;j--)
            {
                if((p[i].first>=p[j].first&&p[i].second>=p[j].second)||(p[i].first<=p[j].first&&p[i].second<=p[j].second))
                    dp[i]=max(dp[i],dp[j]+1);
            }

        }
        cout<<*max_element(dp,dp+n)<<endl;
    }
    return 0;
}
