//score 100
#include<bits/stdc++.h>
using namespace std;
#define N 20010
char txt[N];
int n;
int suff_ar[N],rank[N];
int cnt[N],next[N];
bool bh[N],b2h[N];
bool small_first_char(int a,int b)
{
	return txt[a]<txt[b];
}
int height[N];
void suffix_sort()
{
	for(int i=0;i<n;++i)
		suff_ar[i]=i;
	sort(suff_ar,suff_ar+n,small_first_char);

	for(int i=0;i<n;++i)
	{
		bh[i]= (i==0||txt[suff_ar[i]]!=txt[suff_ar[i-1]]);
		b2h[i]=false;
	}
	int q;
	for(int h=1;h<n;h<<=1)
	{
		q=0;
		int i,b=0;
		for(i=0;i<n;++i)
		{
			b2h[i]=false;
			if(bh[i])
			{
				++b;
				next[q]=i;
				q=i;
				cnt[i]=0;
			}
			rank[suff_ar[i]]=q;
		}
		next[q]=i;
		if(b==n)
			break;

		++cnt[rank[n-h]];
		b2h[rank[n-h]]=true;
		for(int i=0;i<n;i=next[i])
		{
			for (int j=i;j<next[i];++j)
			{
				int s=suff_ar[j]-h;
				if(s>=0)
				{
					rank[s]=rank[s]+cnt[rank[s]]++;
					b2h[rank[s]]=true;
				}
			}
			for (int j=i;j<next[i];++j)
			{
				int s=suff_ar[j]-h;
				if(s>=0&&b2h[rank[s]])
				{
					for(int k=rank[s]+1;k<n&&b2h[k]&&(!bh[k]);++k)
						b2h[k]=false;
				}
			}
		}
		for(int i=0;i<n;++i)
		{
			suff_ar[rank[i]]=i;
			bh[i] |= b2h[i];
		}
	}
	int h=0;
	height[0]=0;
	for(int i=0;i<n;++i)
	{
		if(rank[i]>0)
		{
			int k= suff_ar[rank[i]-1];
			while(i+h<n&&k+h<n&&txt[i+h]==txt[k+h])
				++h;
			height[rank[i]]=h;
			h-=h>0;
		}
	}
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n1;
		scanf(" %s",txt);
		n1=strlen(txt);
		for(int i=0;i<n1;++i)
			txt[n1+i]=txt[i];
		n=n1<<1;
		txt[n]='\0';
		suffix_sort();
		int i;
		for( i=0;i<n;++i)
			if(suff_ar[i]<=n1)
				break;
		int ans=suff_ar[i];
		++i;
		while(i<n&&height[i]>=n1)
		{
			ans=min(ans,suff_ar[i]);
			++i;
		}
		printf("%d\n", ans+1);
	}
	return 0;
}