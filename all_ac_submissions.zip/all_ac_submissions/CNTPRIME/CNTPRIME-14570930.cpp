#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1
using namespace std;
#define size 2000001
#define MAX 100000
bool a[size+5];
int t[4*MAX+5],lz[4*MAX+5],arr[MAX+5];
void gen()
{
   ll i,j;
    memset(a,true,sizeof(a));
    a[0]=false;
    a[1]=false;
    for(i=2;i<=size;i++)
    {
        if(a[i])
        for(j=i*i;j<=size;j+=i)
        {
            a[j]=false;
        }
    }

}
void relax(int idx,int i,int j)
{
    if(lz[idx]!=0)
    {
        if(a[lz[idx]])
            t[idx]=(j-i+1);
        else
            t[idx]=0;
        if(i!=j)
        {
            lz[lt]=lz[idx];
            lz[rt]=lz[idx];
        }
        lz[idx]=0;
    }
    return;
}
void init(int i,int j,int idx)
{
    if(i==j)
    {
        if(a[arr[i]])
            t[idx]=1;
        else
            t[idx]=0;
        return;
    }
    int m=(i+j)>>1;
    init(i,m,lt);
    init(m+1,j,rt);
    t[idx]=t[lt]+t[rt];
}
void update(int i,int j,int a,int b,int idx,int v)
{
    relax(idx,i,j);
    if(i>j||j<a||i>b)
        return;
    if(a<=i&&b>=j)
    {
        lz[idx]=v;
        relax(idx,i,j);
        return;
    }
    int m=(i+j)>>1;
    update(i,m,a,b,lt,v);
    update(m+1,j,a,b,rt,v);
    if(i!=j)
      t[idx]=t[lt]+t[rt];
}
int sum(int i,int j,int a,int b,int idx)
{
    relax(idx,i,j);
    if(i>j||j<a||i>b)
        return 0;
    if(a<=i&&b>=j)
    {
        return t[idx];
    }
    int m=(i+j)>>1;
    return sum(i,m,a,b,lt)+sum(m+1,j,a,b,rt);
}
int main()
{
    int t1,n,q,i,x,y,v,k,cs=1;
    sfd(t1);
    gen();
    while(t1--)
    {
        sfd(n);
        sfd(q);
        for(i=0;i<n;i++)
            sfd(arr[i]);
        init(0,n-1,1);
        printf("Case %d:\n",cs);
        cs++;
        memset(lz,0,sizeof(lz));
        while(q--)
        {
            sfd(k);
            sfd(x);
            sfd(y);
            if(!k)
            {
                sfd(v);
                update(0,n-1,x-1,y-1,1,v);
            }
            else
                pfd(sum(0,n-1,x-1,y-1,1));
        }
    }
    return 0;
}
