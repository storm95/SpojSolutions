#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 9;
const int PMAX = 1e6 + 9;

bool primes[PMAX];
int num[4 * MAXN],tc,N,Q;
int tree[4 * MAXN];
int lazy[4 * MAXN];

inline void sieve(){
	for(int i = 0; i < PMAX;++i)
		primes[i] = true;
	primes[0] = primes[1] = false;
	for(long long i = 2;i < PMAX;++i)
		if(primes[i])
			for(long long j = i * i;j < PMAX;j += i)
				primes[j] = false;
}

inline void build(int node,int tl,int tr){
	if(tl == tr){
		lazy[node] = 0;
		if(primes[num[tl]])
			tree[node] = 1;
		else
			tree[node] = 0;
		return;
	}
	int md = (tl + tr) >> 1;
	build(2 * node,tl,md);
	build(2 * node + 1,md + 1,tr);

	tree[node] = tree[2 * node] + tree[2 * node + 1];
}

inline void pushdown(int node,int tl,int tr){
	if(lazy[node] != 0){
		if(primes[lazy[node]])
			tree[node] = (tr - tl + 1);
		else 
			tree[node] = 0;

		if(tl != tr){
			lazy[2 * node] = lazy[node];
			lazy[2 * node + 1] = lazy[node];
		}

		lazy[node] = 0;
	}
} 

inline void update(int node,int tl,int tr,int ql,int qr,int val){
	pushdown(node,tl,tr);
	if(tr < ql || tl > qr) 
		return;
	if(tl >= ql && tr <= qr){
		if(primes[val])
			tree[node] = (tr - tl + 1);
		else 
			tree[node] = 0;

		if(tl != tr){
			lazy[2 * node] = val;
			lazy[2 * node + 1] = val;
		}
	} else {
		int md = (tl + tr) / 2;
		update(2 * node,tl,md,ql,qr,val);
		update(2 * node + 1,md + 1,tr,ql,qr,val);

		tree[node] = tree[2 * node] + tree[2 * node + 1];
	}
}

inline int query(int node,int tl,int tr,int ql,int qr){
	if(tr < ql || tl > qr)
		return 0;
	pushdown(node,tl,tr);
	if(tl >= ql && tr <= qr)
		return tree[node];
	int md = (tl + tr) / 2;
	return query(2 * node,tl,md,ql,qr) + query(2 * node + 1,md + 1,tr,ql,qr);
}

int main (){
	sieve();
	scanf("%d",&tc);
	for(int kase = 1;kase <= tc;++kase){
		for(int i = 0;i < 4 * MAXN;++i)
			lazy[i] = tree[i] = num[i] = 0;
		scanf("%d %d",&N,&Q);
		for(int i = 0;i < N;++i)
			scanf("%d",&num[i]);
		build(1,0,N - 1);
		printf("Case %d:\n",kase);
		while(Q--){
			int type,x,y,v;
			scanf("%d",&type);
			if(type == 0){
				scanf("%d %d %d",&x,&y,&v);
				update(1,0,N - 1,x - 1,y - 1,v);
			} else {
				scanf("%d %d",&x,&y);
				printf("%d\n",query(1,0,N - 1,x - 1,y - 1));
			}
		}	
	}
	return 0;
}
