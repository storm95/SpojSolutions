#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
typedef pair<int,int> pr;
int a[100000];
int b[100000];
int main()
{
   int t;
   scanf("%d",&t);
   while(t--)
   {
       int n;
       scanf("%d",&n);
       for(int i=0;i<n;i++) scanf("%d",&a[i]);
       for(int i=0;i<n;i++) scanf("%d",&b[i]);
       vector<pr> v;
       for(int i=0;i<n;i++) v.push_back(mp(a[i],b[i]));
       sort(v.begin(),v.end());
       vector<int> dp;
       vector<int>:: iterator it;
       for(int i=0;i<v.size();i++)
       {
           it=upper_bound(dp.begin(),dp.end(),v[i].second);
           if(it==dp.end()) dp.push_back(v[i].second);
           else
            *it=v[i].second;
       }
       printf("%d\n",dp.size());
   }
    return 0;
}
