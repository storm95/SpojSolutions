//$andeep :)
#include<bits/stdc++.h>
#define ll long long 
using namespace std;

char *Days[]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
int DaysInMonth[]={0,31,28,31,30,31,30,31,31,30,31,30,31};

int Calculate(int ,int ,int );
int CheckLeap(int );

main(){
    
   int TestCases,Date,Month,Year,Deviation;
   
   scanf("%d",&TestCases);
   
   while(TestCases--){
    
      scanf("%d%d%d",&Date,&Month,&Year);
      
      Deviation=Calculate(Date,Month,Year);
      printf("%s\n",Days[Deviation]);

   }

}

int Calculate(int Date,int Month,int Year){
    
   int DaysElapsed=0,i;
    
   for(i=1;i<Month;i++) 
      DaysElapsed+=DaysInMonth[i];

   if(Month>2&&CheckLeap(Year))
      DaysElapsed++;   
   
   DaysElapsed+=(Year-2012)*365;
   
   for(i=2012;i<Year;i+=4)
        if(CheckLeap(i))
     DaysElapsed++;    
  
   DaysElapsed+=(Date-1);
   return DaysElapsed%7;

}

int CheckLeap(int Year){
    
   if((Year%400==0)||(Year%4==0&&Year%100))
      return 1;
   
   else return 0;

}
