#include<iostream>
#include<cstdio>
#include<cstring>
int main()
{
    int tc,d,m,y;
    scanf("%d",&tc);
    while(tc--)
    {
        int mon[15]={0,3,2,5,0,3,5,1,4,6,2,4};
        char ch[10][20]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        scanf("%d%d%d",&d,&m,&y);
        if(m<3) y--;
        int c=((y/4 + y+ y/400 - y/100 + mon[m-1] + d)%7);
        printf("%s\n",ch[c]);
    }
    return 0;
}
