#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
string s;
int a[32768],st[65536],mst[65536];
void build(int i,int j,int t)
{
    if(i==j)
    {
        st[t]=mst[t]=(s.at(i)=='(' ? 1 : -1);;
        return;
    }
    int mid=(i+j)/2;
    build(i,mid,2*t);
    build(mid+1,j,2*t+1);
    st[t]=st[2*t]+st[2*t+1];
    mst[t]=min(mst[2*t],st[2*t]+mst[2*t+1]);
}
void update(int i,int j,int loc,int t)
{
    if(i==j)
       {
           st[t]=mst[t]=-st[t];
          return;
       }
    int mid=(i+j)/2;
    if(loc<=mid)
      update(i,mid,loc,2*t);
    else if(loc>mid)
       update(mid+1,j,loc,2*t+1);
    st[t]=st[2*t]+st[2*t+1];
    mst[t]=min(mst[2*t],st[2*t]+mst[2*t+1]);
}

int main()
{

    int t=10,n,k,q,i,j=1;
    while(j<=t)
    {
        memset(st,0,sizeof(st));
        sfd(n);
        cin>>s;
        build(0,n-1,1);
        printf("Test %d:\n",j);
        j++;
        sfd(q);
        while(q--)
        {
            sfd(k);
            if(!k)
            {
                if(!st[1]&&!mst[1])
                    cout<<"YES\n";
                else
                    cout<<"NO\n";
            }
            else
                update(0,n-1,k-1,1);
        }

    }
    return 0;
}
