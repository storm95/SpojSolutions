#include <bits/stdc++.h>
using namespace std;
 
typedef long long             LL;
typedef long double           LD;
typedef vector< int >         vi;
typedef pair < int,int >      pii;
typedef vector < pii >        vpii;
typedef pair < LL ,LL >       pLL;
typedef vector < pLL >        vpLL;
 
#define  pb      push_back
#define  pf      push_front
#define  gc      getchar_unlocked
#define  pc      putchar_unlocked
#define  all(A)  A.begin(),A.end()
#define  mp      make_pair
#define  F       first
#define  S       second

#define  si(x)            scanf("%d",&x)
#define  slli(x)          scanf("%lld",&x)
#define  tr(C,it)         for(typeof(C.begin()) it=C.begin() ; it!=C.end() ;it++)
#define  DEBUG(Z,sz)      cout << " DEBUG "; for(int i = 0;i < sz;++i) cout << Z[i] << " ";
#define  TC               int tc; si(tc); while(tc--)

#define  PI      3.14159265358979323846264338327950
#define  mod     1000000007
#define  MAXN    100009


int n,m,len,k;
string s;

struct st {
   int open,close;
}tree[4 * 30009];

inline void build(int node, int tl,int tr) {
  	if(tl == tr) {
	   if(s[tl] == '(')
	   tree[node].open = 1,tree[node].close = 0;
	   else 
	   tree[node].close = 1,tree[node].open = 0;
	   return;
	}
	int tm = (tl + tr) >> 1;
	build(2*node,tl,tm);
	build(2*node + 1,tm + 1,tr);
    int sub = min(tree[2*node].open,tree[2*node + 1].close);
	int t1 = tree[2 * node].open;
	int t2 = tree[2*node + 1].close;
	t1-=sub;
	t2-=sub;
	tree[node].open = tree[2*node + 1].open + t1;
	tree[node].close = tree[2 * node].close + t2;
}

inline void update(int node,int l,int r,int upd) { 
    if(l == r) {
	       if(s[l] == '(')    tree[node].open = 1,tree[node].close = 0;
	       else               tree[node].open = 0,tree[node].close = 1;
	       return;	
    }
	int mid = (l + r)/2;
	if(upd <= mid) update(2*node,l,mid,upd);  
    else           update(2*node + 1,mid + 1,r,upd);
    int sub = min(tree[2*node].open,tree[2*node + 1].close);
	int t1 = tree[2 * node].open;
	int t2 = tree[2*node + 1].close;
	t1-=sub;
	t2-=sub;
	tree[node].open = tree[2*node + 1].open + t1;
	tree[node].close = tree[2 * node].close + t2;
}

int main () {
   int tc = 1;	
   while(cin >> n) {
	  for(int i = 0;i < (4 * 30009);++i) {
	     tree[i].open = tree[i].close = 0;
	  }
      cin >> s;
      si(m);
      build(1,0,n - 1);
      for(int z = 1;z <= m;++z) {
		 if(z == 1) printf("Test %d:\n",tc++);
	     si(k);
	     if(k != 0) {
		    if(s[k - 1] == '(') s[k - 1] = ')';
		    else s[k - 1] = '(';	 
		    update(1,0,n - 1,k - 1);
		 } else {
		  	if(tree[1].open == 0 && tree[1].close == 0) puts("YES");
		  	else puts("NO"); 
		}
	  }     
   }
   return 0;
}
