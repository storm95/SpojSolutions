#include<bits/stdc++.h>
using namespace std;
char str[30001];
typedef struct 
{
	int uo;
	int uc;
}node;
node tree[480001];
void build(int idx,int x,int y)
{
	if(x==y)
	{
		if(str[x]==')')
		{
			tree[idx].uc=1;
			tree[idx].uo=0;
		}
		else
		{
			tree[idx].uc=0;
			tree[idx].uo=1;	
		}
		return ;
	}
	int mid = (x+y)>>1;
	int l = (idx<<1)+1;
	int r = l+1;

	build(l,x,mid);
	build(r,mid+1,y);

	tree[idx].uc = tree[l].uc + tree[r].uc - min(tree[l].uo,tree[r].uc);
	tree[idx].uo = tree[l].uo + tree[r].uo - min(tree[l].uo,tree[r].uc);
}
void update(int idx,int x,int y,int vic)
{
	if(x==y)
	{
		if(str[x]==')')
		{
			tree[idx].uc=1;
			tree[idx].uo=0;
		}
		else
		{
			tree[idx].uc=0;
			tree[idx].uo=1;	
		}
		return ;
	}

	int mid = (x+y)>>1;
	int l = (idx<<1)+1;
	int r = l+1;

	if(vic<=mid)
		update(l,x,mid,vic);
	else update(r,mid+1,y,vic);
	tree[idx].uc = tree[l].uc + tree[r].uc - min(tree[l].uo,tree[r].uc);
	tree[idx].uo = tree[l].uo + tree[r].uo - min(tree[l].uo,tree[r].uc);
}
int main()
{
	int t=10;
	int n,x,m;
	for(int tc=1;tc<=t;++tc)
	{
		printf("Test %d:\n",tc);
		scanf("%d",&n);
		scanf(" %s",str);
		build(0,0,n-1);
		scanf("%d",&m);
		while(m--)
		{
			scanf("%d",&x);
			if(x==0)
			{
				if(tree[0].uo==0&&tree[0].uc==0)
				printf("YES\n");
				else printf("NO\n");
			}
			else
				{
					str[x-1] = '(' ^ ')' ^ str[x-1];
					update(0,0,n-1,x-1);
				}
		}
	}
	return 0;
}