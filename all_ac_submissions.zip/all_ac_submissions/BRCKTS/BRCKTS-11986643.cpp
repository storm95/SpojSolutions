#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<climits>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int arr[2][600001],temp;
char str[300000];
void form(int index,int start,int stop)
{
   //printf("start= %d   stop= %d\n      ",start,stop);
    //for(temp=0;temp<1000000000;temp++)
      //  ;
    if(start==stop)
    {
        //printf("indexnow= %d\n",index);
        arr[0][index]=(str[start-1]=='('?1:0);
        arr[1][index]=(str[start-1]==')'?1:0);
    }
    else
    {
        int z,u;
        z=(stop-start)/2+start;
        u=z+1;
        form(2*index,start,z);
        form(2*index +1,u,stop);
        arr[0][index]=arr[1][index]=0;
        //printf("uty op %d  cl %d\n",arr[0][7],arr[1][7]);
        if(arr[0][2*index]>arr[1][2*index +1])
        {
            arr[0][index]=arr[0][2*index]-arr[1][2*index +1];
        }
        else
        {
            arr[1][index]=arr[1][2*index +1]-arr[0][2*index];
        }
        arr[0][index]+=arr[0][2*index+1];
        arr[1][index]+=arr[1][2*index];
    }
}
void change(int position,int index,int start,int stop)
{
    if(position==start && position==stop)
    {
        temp=arr[0][index];
        arr[0][index]=arr[1][index];
        arr[1][index]=temp;
        //printf("ind %d\n",index);
        //printf("begin  o %d   c %d\n",arr[0][7],arr[1][7]);
    }
    else
    {
        int z,u;
        z=(stop-start)/2+start;
        u=z+1;
        if(position>z)
            change(position,2*index+1,u,stop);
        else
            change(position,2*index,start,z);
        arr[0][index]=arr[1][index]=0;
        //printf("o %d   c %d\n",arr[0][4],arr[1][4]);
        if(arr[0][2*index]>arr[1][2*index +1])
        {
            arr[0][index]=arr[0][2*index]-arr[1][2*index +1];
        }
        else
        {
            arr[1][index]=arr[1][2*index +1]-arr[0][2*index];
        }
        arr[0][index]+=arr[0][2*index+1];
        arr[1][index]+=arr[1][2*index];
        //printf("start= %d   stop= %d   open= %d  close= %d\n",start,stop,arr[0][index],arr[1][index]);
    }
    //printf("start= %d   stop= %d   open= %d  close= %d\n",start,stop,arr[0][index],arr[1][index]);
}
int main()
{
    int t,i,j,a,flag,b,c,len,n,k,m;
    for(t=1;t<=10;t++)
    {
        flag=0;
        scanf("%d",&len);
        scanf("%s",&str);
        //printf("idu");
        form(1,1,len);
      //  for(i=1;i<=2*len+1;i++)
        //printf("%d %d\n",arr[0][i],arr[1][i]);
        scanf("%d",&n);
        while(n--)
        {
            scanf("%d",&m);
            if(m==0)
            {
                if(flag==0)
                {
                    printf("Test %d:\n",t);
                    flag=1;
                }
                if(arr[0][1]==0 && arr[1][1]==0)
                    printf("YES\n");
                else
                    printf("NO\n");
            }
            else
            change(m,1,1,len);
        }
    }



    return 0;
}

