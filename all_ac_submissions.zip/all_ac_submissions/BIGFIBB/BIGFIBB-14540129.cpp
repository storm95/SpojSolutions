#include<bits/stdc++.h>
using namespace std;
#define mod 1000000007
void mul(long long (*a)[2],long long b[][2])
{
	long long c[2][2];
	for(int i=0;i<2;++i)
	{
		for(int j=0;j<2;++j)
		{
			c[i][j]=0;
			for(int k=0;k<2;++k)
			{
				c[i][j]=(c[i][j]+(a[i][k]*b[k][j])%mod)%mod;
			}
		}
	}
	for(int i=0;i<2;++i)
	{
		for(int j=0;j<2;++j)
		{
			a[i][j]=c[i][j];
		}
	}
}
long long power(long long n)
{
	long long Mat[2][2]={1,1,1,0};
	long long ans[2][2]={1,0,0,1};
	while(n)
	{
		if(n&1) mul(ans,Mat);
		mul(Mat,Mat);
		n>>=1;
	}
	return ans[0][0];
}
long long fibb(long long n)
{
	return power(n);
}
int main()
{
	int t;
	scanf("%d",&t);
	long long n;
	while(t--)
	{
		scanf("%lld",&n);
		printf("%lld\n",fibb(n) );
	}
	return 0;
}