#include <bits/stdc++.h>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>

using namespace std;

int main()
{
    int n,d,i,*a,k,p,s;

    scanf("%d",&n);
     scanf("%d",&d);
     while(n!=0)
     {
        k=0;
        for(i=1;i<=n;i++)
        {
            s=(s+d)%i;
        }
        cout<<n<<" "<<d<<" "<<s+1<<endl;
         scanf("%ld",&n);
     scanf("%ld",&d);
     }


    return 0;
}
