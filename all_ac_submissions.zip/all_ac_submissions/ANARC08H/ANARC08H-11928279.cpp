#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
void john(int n,int d)
{
    int k,i,ans=1;
    for(i=2;i<=n+1;i++)
    {
        k=ans;
        ans= (ans + d)%i;
        if(k+d>=i)
        ++ans;
    }
    printf("%d %d %d\n",n,d,ans);
}
void joseph(int n,int d)
{
    int i,ans=0;
    for(i=2;i<=n;i++)
    {
        ans= (ans +d )%i;
    }
    printf("%d %d %d\n",n,d,ans+1);
}
int main()
{
    int n,d,a,b,c;
    while(1)
    {
        scanf("%d %d",&n,&d);
        if(n==0 && d==0)
            break;
        joseph(n,d);
        //john(n,d);
    }



    return 0;
}

