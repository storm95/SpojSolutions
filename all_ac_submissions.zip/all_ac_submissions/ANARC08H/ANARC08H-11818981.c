#include<stdio.h>
int main()
{
    int n,d;
    scanf("%d %d",&n,&d);
    while(n!=0&&d!=0)
    {
        int a=0,i;
        for(i=2;i<=n;i++)
            a=(a+d)%i;
        printf("%d %d %d\n",n,d,a+1);
        scanf("%d %d",&n,&d);
    }
    return 0;
}
