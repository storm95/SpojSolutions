#include<bits/stdc++.h>
using namespace std;
int p[51];
int main()
{
    for(int i=0;i<51;i++) p[i]=i*i*i;
    int n;
    scanf("%d",&n);
    int ans=0;
    for(int a=0;a<51;a++)
    {
        int as=p[a];
        if(as>n) break;
        for(int b=a;b<51;b++)
        {
           	int bs=as+p[b];
            if(bs>n) break;
            for(int c=b;c<51;c++)
            {
                int cs=bs+p[c];
                if(cs>n) break;
                for(int d=c;d<51;d++)
                {
                    int ds=cs+p[d];
                    if(ds>n) break;
                    for(int e=d;e<51;e++)
                    {
                        int sum=ds+p[e];
                        if(sum>n) break;
                        if(sum==n) ans++;
                    }
                }
            }
        }
    }
    printf("%d\n",ans);
    return 0;
}
