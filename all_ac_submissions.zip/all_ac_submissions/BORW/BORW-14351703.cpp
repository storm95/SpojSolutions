#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)


using namespace std;
int v[202],n,dp[202][202][202];
int cal(int i,int b,int w)
{
   if(i>n)
    return 0;
   else
   {
       if(dp[i][b][w]==-1)
       {
           dp[i][b][w]=100000000;
           if((b==0||v[i]>v[b]))
              dp[i][b][w]=min(cal(i+1,i,w),dp[i][b][w]);
           if(w==0||v[i]<v[w])
                dp[i][b][w]=min(dp[i][b][w],cal(i+1,b,i));
           dp[i][b][w]=min(dp[i][b][w],1+cal(i+1,b,w));
       }
       return dp[i][b][w];
   }
}
int main()
{
    int i;
    sfd(n);
    while(n!=-1)
    {
        for(i=1;i<=n;i++)
           sfd(v[i]);
        memset(dp,-1,sizeof dp);
        cout<<cal(0,0,0)<<endl;
        sfd(n);
    }
    return 0;
}
