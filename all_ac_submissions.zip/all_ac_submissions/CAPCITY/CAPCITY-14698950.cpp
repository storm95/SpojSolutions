#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
vector<int>adj[100005],tadj[100005],vt;
int vis[100005],ct[100005],ot[100005];
void dfs1(int i)
{
    vis[i]=1;
    for(int j=0;j<adj[i].size();j++)
    {
        if(vis[adj[i][j]]==0)
            {
                dfs1(adj[i][j]);
            }
    }
    vt.push_back(i);
}
void dfs2(int i,int c)
{
    vis[i]=0;
    ct[i]=c;
    for(int j=0;j<tadj[i].size();j++)
    {
        if(vis[tadj[i][j]])
            dfs2(tadj[i][j],c);
    }
}
int main()
{
    int n,m,i,j,u,v,cp;
    sfd(n);
    sfd(m);
    while(m--)
    {
       sfd(u);
       sfd(v);
       adj[u].push_back(v);
       tadj[v].push_back(u);
    }
    memset(vis,0,sizeof(vis));
    for(i=1;i<=n;i++)
    {
        if(vis[i]==0)
            dfs1(i);
    }

    cp=0;
    for(i=vt.size()-1;i>=0;i--)
    {
        if(vis[vt[i]])
        {
            dfs2(vt[i],cp++);
        }
    }
     memset(ot,0,sizeof(ot));
    for(i=1;i<=n;i++)
        for(j=0;j<adj[i].size();j++)
            if(ct[i]!=ct[adj[i][j]])
                ot[ct[i]]++;
    int count=0;
    for(i=0;i<cp;i++)
        if(ot[i]==0)
         count++;
        //cout<<count<<endl;
    if(count>1)
         printf( "0\n" );
    else
    {
        count=0;
         for(i=1;i<=n;i++)
         {
             if(ot[ct[i]]==0)
                count++;
         }
          printf("%d\n",count);
          for(i=1;i<=n;i++)
         {
             if(ot[ct[i]]==0)
                printf("%d ",i);
         }
          printf("\n");
    }

    return 0;
}
