#include<iostream>
#include<cstdio>
#include<set>
using namespace std;
set<pair<int,bool> > s;
set<pair<int,bool> >::iterator p;
int main()
{
        int t,x,n,y,i;
        scanf("%d",&t);
        while(t--)
        {
                s.clear();
                scanf("%d",&n);
                for(i=0;i<n;++i)
                {
                        scanf("%d %d",&x,&y);
                        s.insert(pair<int,bool>(x,true));
                        s.insert(pair<int,bool>(y,false));
                }
                int now=0,ans=0;
                for(p=s.begin();p!=s.end();++p)
                {
                        if(p->second==true)
                        {
                                ++now;
                                if(now>ans)
                                ans=now;
                        }
                        else if(p->second==false)--now;
                }
                printf("%d\n",ans);
        }
        return 0;
}
