#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int t,n,*dp,m,mx,j,i,ct;
    sfd(t);
    while(t--)
    {
        sfd(n);
        pair< int,char>p[2*n];
       // dp=new int[n];
        for(i=0;i<2*n;i++)
        {
            sfd(p[i].first);
            if(i%2==0)
            p[i].second='l';
            else
                 p[i].second='r';


        }
        sort(p,p+2*n);
        mx=-100;
        ct=0;
        for(i=0;i<2*n;i++)
        {
            if(p[i].second=='l')
                ct++;
            else
                ct--;
            if(ct>mx)
                mx=ct;
        }
        cout<<mx<<endl;
    }
    return 0;
}
