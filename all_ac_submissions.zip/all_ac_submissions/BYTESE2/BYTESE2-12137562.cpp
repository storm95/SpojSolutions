#include<iostream>
#include<cstdio>
#include<algorithm>
int a[10000010],b[10000010];
int main()
{
	int t,x,n,maxi=0,y,i,j;
	scanf("%d",&t);
	for(i=0;i<10000010;++i)
                a[i]=b[i]=0;
	for(j=1;j<=t;++j)
	{
		scanf("%d",&n);
		maxi=0;
		for(i=0;i<n;++i)
		{
			scanf("%d %d",&x,&y);
			a[x]=b[y]=j;
			if(y>maxi)
			maxi=y;
		}
		int now=0,ans=0;
		for(i=0;i<=maxi;++i)
		{
			if(a[i]==j)
			{
				++now;
				if(now>ans)
	                        ans=now;
			}
			else if(b[i]==j)--now;
		}
		printf("%d\n",ans);
	}
	return 0;
}