#include <iostream>
#include<cstdio>
using namespace std;

int main() {
    int test;
    scanf("%d",&test);
    while(test--)
    {
        long long int n,i=12,j;
        scanf("%lld",&n);
        long long int x,y;
        if(n%2==0)
        {
            x=1;
            i=1;
            y=4*n;
        }
        else
        {
            x=(3*n*n)+1;
            y=n*n*n;
            if(x%2==0)
            {
                x/=2;
                i/=2;
            }
            if(x%2==0)
            {
                x/=2;
                i/=2;
            }
            if(x%3==0)
            {
                x/=3;
                i/=3;
            }
            if(y%x==0)
            {
                x=1;
                y/=x;
            }
            y*=i;
        }
        printf("%lld/%lld\n",x,y);
    }
	return 0;
}