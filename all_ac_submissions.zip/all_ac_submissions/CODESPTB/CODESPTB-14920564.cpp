#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1


using namespace std;

int f_merge(int*arr,int l,int m,int r)
{
    int i,j,k;
    int inv_count=0;
    int a=m-l+1;
    int b=r-m;
    int L[a],R[b];
    for(i=0;i<a;i++)
    {
        L[i]=arr[l+i];
    }
    for(j=0;j<b;j++)
    {
        R[j]=arr[m+1+j];
    }
    i=0,j=0,k=l;
    while(i<a && j<b)
    {
        if(L[i]<=R[j])
        {
            arr[k]=L[i];
            i++;
        }
        else
        {

            arr[k]=R[j];
            j++;
            inv_count+=(m-(l+i)+1);
        }
        k++;
    }
    while(i<a)
    {
        arr[k]=L[i];
        i++;
        k++;
    }
    while(j<b)
    {
        arr[k]=R[j];
        j++;
        k++;
    }

    return inv_count;
}
int msort(int*arr,int l,int r)
{
    int c=0;
    if(l<r)
    {
        int m=(l+r)/2;
        c+=msort(arr,l,m);
        c+=msort(arr,m+1,r);
        c+=f_merge(arr,l,m,r);
    }
    return c;
}
int main()
{
   int t;
   int n,i;
   sfd(t);
   while(t--)
   {
      sfd(n);
      int arr[n];
      for(i=0;i<n;i++)
      {
          sfd(arr[i]);
      }

      cout<<msort(arr,0,n-1)<<endl;
   }
   return 0;
}
