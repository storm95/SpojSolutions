#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)


using namespace std;

int main()
{
    int t,V,n,i,j,v[61],c[61],u[61],k,z;
    sfd(t);
    while(t--)
    {
        sfd(V);
        sfd(n);
        V/=10;
        int ct[n+1][2];
        for(i=0;i<=n;i++)
            for(j=0;j<2;j++)
                ct[i][j]=0;
        for(i=0;i<n;i++)
        {
            sfd(v[i]);
            v[i]/=10;
            sfd(c[i]);
            sfd(u[i]);
          if(ct[u[i]][0]==0)
            ct[u[i]][0]=i;
          else
            ct[u[i]][1]=i;
        }
        int dp[61][3205]={0};
        /*dp=new int*[n+1];
        for(i=0;i<n+1;i++)
            dp[i]=new int[V+1];*/
       //memset(dp,0,sizeof(dp));
        for(i=0;i<=n;i++)
        {
            for(j=0;j<=V;j++)
            {
                if(i==0||j==0)
                {
                    dp[i][j]=0;
                    continue;
                }
                dp[i][j]=dp[i-1][j];
                if(u[i-1]==0)
                {
                    if(v[i-1]<=j)
                        dp[i][j]=max(dp[i][j],dp[i-1][j-v[i-1]]+v[i-1]*c[i-1]);

                  if(ct[i][0]!=0)
                  {
                      if(v[i-1]+v[ct[i][0]]<=j)
                        dp[i][j]=max(dp[i][j],dp[i-1][j-v[i-1]-v[ct[i][0]]]+v[i-1]*c[i-1]+v[ct[i][0]]*c[ct[i][0]]);
                      if(ct[i][1]!=0)
                      {
                          if(v[i-1]+v[ct[i][1]]<=j)
                        dp[i][j]=max(dp[i][j],dp[i-1][j-v[i-1]-v[ct[i][1]]]+v[i-1]*c[i-1]+v[ct[i][1]]*c[ct[i][1]]);

                            if(v[i-1]+v[ct[i][1]]+v[ct[i][0]]<=j)
                        dp[i][j]=max(dp[i][j],dp[i-1][j-v[i-1]-v[ct[i][1]]-v[ct[i][0]]]+v[i-1]*c[i-1]+v[ct[i][1]]*c[ct[i][1]]+v[ct[i][0]]*c[ct[i][0]]);
                      }
                  }
                }
            }
        }
       /* for(i=0;i<=n;i++)
        {
            for(j=0;j<=V;j++)
                cout<<dp[i][j]<<" ";
            cout<<endl;
        }*/
        cout<<dp[n][V]*10<<endl;

    }
    return 0;
}
