#include<iostream>
#include<cstdio>
using namespace std;
int arr[100][100];
int main()
{
	int t,h,w,i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&h,&w);
		for(i=0;i<h;++i)
		for(j=0;j<w;++j)
		scanf("%d",&arr[i][j]);
		for(i=1;i<h;++i)
		{
			for(j=0;j<w;++j)
			{
				if(j>0&&j<(w-1))
				{
					arr[i][j]=max(arr[i-1][j],max(arr[i-1][j-1],arr[i-1][j+1]))+arr[i][j];
				}
				else
				{
					int t=0;
					if(j==0)
					{
						if((j+1)<w)
						t=arr[i-1][j+1];
					}
					else if((j-1)>=0)
					{
						t=arr[i-1][j-1];
					}
					arr[i][j]=max(t,arr[i-1][j])+arr[i][j];
				}
			}
		}
		int maxi=0;
		for(i=0;i<w;++i)
		if(arr[h-1][i]>maxi)
		maxi=arr[h-1][i];
		printf("%d\n",maxi);
	}
	return 0;
}
