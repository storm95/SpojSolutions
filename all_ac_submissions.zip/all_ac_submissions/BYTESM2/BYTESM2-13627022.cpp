#include<bits/stdc++.h>
using namespace std;
long long  arr[1001][1001];
long long  dp[1002][1003];
long long int mx=0;
int main()
{
    long long  tc,n,m;
    scanf("%lld",&tc);
    while(tc--)
    {
        scanf("%lld %lld",&n,&m);
        mx=0;
        long long int a,k=0,l=0;
        for(long long  i=1;i<=n*m;i++)
        {
            scanf("%lld",&a);
            arr[l][k]=a;
            k++;
           if((i%m) == 0)
            {
                l++;
                k=0;
            }
        }
     /*   cout<<endl;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                cout<<arr[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;*/
        for(long long int i=0;i<=n;i++)
        dp[i][0]=0;
    for(long long int i=0;i<=m+1;i++)
        dp[0][i]=0;
        for(int i=0;i<=n;i++)
            dp[i][m+1]=0;
        for(long long int i=1;i<=m;++i)
            dp[1][i]=arr[0][i-1];
        for(long long int i=2;i<=n;i++)
        {
            for(long long int j=1;j<=m;j++)
            {
                dp[i][j]=arr[i-1][j-1] + max(max(dp[i-1][j-1],dp[i-1][j]),dp[i-1][j+1]);
                if(mx<dp[i][j]) mx=dp[i][j];
            }
        }
       /* for(long long int i=0;i<=n;i++)
        {
            for(long long int j=0;j<=m+1;j++)
            {
                cout<<dp[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;*/
        for(long long int i=1;i<=m;i++)
        {
            if(mx<dp[n][i]) mx=dp[n][i];
        }
        cout<<mx<<endl;
    }
    return 0;
}
