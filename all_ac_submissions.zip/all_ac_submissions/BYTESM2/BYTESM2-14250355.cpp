#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int a[101][101],dp[101][101],m,n,i,j,t;
    sfd(t);
    while(t--)
    {
        sfd(m);
        sfd(n);
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                sfd(a[i][j]);
                if(i==0)
                    dp[i][j]=a[i][j];
            }
        }
        for(i=1;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                if(j==0)
                    dp[i][j]=a[i][j]+max(dp[i-1][j],dp[i-1][j+1]);
                else if(j==n-1)
                     dp[i][j]=a[i][j]+max(dp[i-1][j],dp[i-1][j-1]);
                else
                    dp[i][j]=a[i][j]+max(max(dp[i-1][j],dp[i-1][j-1]),dp[i-1][j+1]);
            }
        }
        cout<<*max_element(dp[m-1],dp[m-1]+n)<<endl;
    }

    return 0;
}
