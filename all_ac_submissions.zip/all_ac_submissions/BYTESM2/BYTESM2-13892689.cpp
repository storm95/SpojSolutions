//rathoreanirudh
#include<bits/stdc++.h>
#define lli long int
using namespace std;
int main()
{
    int test;
    cin>>test;
    while(test--)
    {
        int n,m;
        cin>>n>>m;
        lli arr[n][m],res=0;
        for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
                cin>>arr[i][j];
        lli ans[n][m];
        for(int j=0;j<m;j++)
            ans[n-1][j]=arr[n-1][j];
        for(int i=n-2;i>=0;i--)
        {
            for(int j=0;j<m;j++)
            {
                if(j==0)
                    ans[i][j]=arr[i][j]+max(ans[i+1][j],ans[i+1][j+1]);
                else if(j==m-1)
                    ans[i][j]=arr[i][j]+max(ans[i+1][j-1],ans[i+1][j]);
                else
                    ans[i][j]=arr[i][j]+max(ans[i+1][j-1],max(ans[i+1][j],ans[i+1][j+1]));
            }
        }
        for(int i=0;i<m;i++)
        {
            if(res<ans[0][i])
                res=ans[0][i];
        }
        cout<<res<<endl;
    }
    return 0;
}
