#include <stdio.h>


int max2(int a,int b)
{
    return a>b?a:b;
}
int max3(int a,int b,int c)
{
    int temp=a>b?a:b;
    return temp>c?temp:c;
}

#define MAX 101



int main()
{
    int a[MAX][MAX],s[MAX][MAX],x,t;
    int i,j,n,m;
    scanf("%d",&t);
    while(t--){
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++)
        {for(j=0;j<m;j++)
          {scanf("%d",&a[i][j]);
           s[i][j]=0;
          }
        }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            if(i==0||i==0&&j==0)
                s[i][j]=a[i][j];
            else if(i!=0&&j==0)
                s[i][j]=a[i][j]+max2(s[i-1][j],s[i-1][j+1]);
            else if(i!=0&&j==m-1)
                s[i][j]=a[i][j]+max2(s[i-1][j],s[i-1][j-1]);
            else
                s[i][j]=a[i][j]+max3(s[i-1][j],s[i-1][j-1],s[i-1][j+1]);
        }
    }
    x=s[n-1][0];
    for(i=n-1,j=1;j<m;j++)
        if(x<s[i][j])
           x=s[i][j];
    printf("%d\n",x);}

    return 0;
}
