#include<cstdio>
#include<vector>
#include<iostream>
using namespace std;
int maximum(int a,int b)
{
	if(a>b) return a;
	return b;
} 
int maximum3(int a,int b,int c)
{
	if(maximum(a,b)>c) return maximum(a,b);
	return c;
}
int main()
{
	int i,j,tc,h,w;
	scanf("%d",&tc);
	while(tc--)
	{
		int max=-100000;
		scanf("%d %d",&h,&w);
	  	vector<vector<int> > harry(h,vector<int> (w,0));
		for(i=0;i<h;i++)
		{
			for(j=0;j<w;j++)
			 scanf("%d",&harry[i][j]);
		}
		for(i=1;i<h;i++)
		{
			for(j=0;j<w;j++)
			{
				if(j==0)          harry[i][j]+=maximum(harry[i-1][j+1],harry[i-1][j]);
				else if(j==w-1)   harry[i][j]+=maximum(harry[i-1][j-1],harry[i-1][j]);
				else              harry[i][j]+=maximum3(harry[i-1][j-1],harry[i-1][j],harry[i-1][j+1]);
			}
		}
		for(j=0;j<w;j++)
		if(harry[h-1][j]>max) max=harry[h-1][j];
		printf("%d\n",max);
	}
    return 0;
}