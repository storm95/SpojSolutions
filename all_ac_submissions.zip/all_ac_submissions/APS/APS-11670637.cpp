#include<bits/stdc++.h>
#define ll  long long 
using namespace std;
int divisor[10000009]={};
ll ans[10000009]={};
void preprocess()                                //..Pre-processing all the divisors to answer queries in O(1)
{
	for(int i=2 ; i<=10000009 ; i++)
	{
		if(!divisor[i])                               //...Checking whether the divisors are already calculated or not
		{
			for(int j = (i+i) ; j<=10000009 ; j+=i)   //..If not calculated yet, calculating them 
				if(!divisor[j])                       //..Storing for all multiples of i
				divisor[j]=i;                         //...Storing the divisor..
				ans[i] = ans[i-1] + i;              
		}
		else
		ans[i] = ans[i-1] + divisor[i];
	}
}
int main()
{  
    preprocess();
	int tc,n;
	scanf("%d",&tc);
	while(tc--)
	{
		scanf("%d",&n);
		printf("%lld\n",ans[n]);
	}
	return 0;
}