#include<stdio.h>
int sum=0;
#define size 10000005
long long a[size+1]={0};
void isprime()
{
    int i,j,k;
    a[0]=0;a[1]=0;
    for(i=2;i<=size;i++)
    {
        if(a[i]==0)
        {
            a[i]=a[i-1]+i;
            for(j=i;j<=size;j+=i)
            {
                if(a[j]==0)
                a[j]=i;
            }
        }
        else
            a[i]=a[i-1]+a[i];
    }
}
int main()
{
    isprime();
    int test;
    scanf("%d",&test);
    while(test--)
    {
    long long int n;
    scanf("%lld",&n);
    printf("%lld\n",a[n]);
    }
return 0;
}
