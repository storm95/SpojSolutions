#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lf 2*idx
#define rt 2*idx+1
using namespace std;
#define size 10000009
ll a[size],ans[size];
void gen()
{
   ll i,j;
    memset(a,0,sizeof(a));
    ans[0]=ans[1]=0;
    for(i=2;i<size;i++)
    {
        if(a[i]==0)
        for(j=i;j<size;j+=i)
        {
          if(a[j]==0)
            a[j]=i;
        }
        ans[i]=ans[i-1]+a[i];
    }

}
int main()
{
    int t;
    ll n;
    gen();
    sfd(t);
    while(t--)
    {
        sflld(n);
        pflld(ans[n]);
    }
    return 0;
}
