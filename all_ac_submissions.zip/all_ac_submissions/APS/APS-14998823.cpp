#include<bits/stdc++.h>
using namespace std;
#define MOD 10000007
#define ll long long
template<class T >
T gcd(T a,T b)
{
	T z;
	while(b)
	{
		z = a;
		a = b;
		b = z%b;
	}
	return a;
}

#define sievelen 10000001
bool sieve[sievelen];
ll a[sievelen];
void init()
{
	memset(sieve,0,sizeof(sieve));
	for(int i=0;i<sievelen;++i)
		a[i] = INT_MAX;
	a[0]=a[1] = 0;
	for(ll i=2;i<sievelen;i+=2)
	{
		a[i]=2;
		sieve[i] = true;
	}
	for(int i=3;i<=sievelen;i+=2)
	{
		if(!sieve[i])
		{
			for(int j=i;j<sievelen;j+=i)
			{
				a[j]=min((ll)i,a[j]);
				sieve[j]=true;
			}
		}
	}
	for(int i=1;i<sievelen;++i)
	{
		a[i]+=a[i-1];
	}
	/*for(int i=0;i<100;++i)
	{
		cout<<a[i]<<"\n";
	}*/
}
#define maxArrLen 2000000
int main()
{
	init();
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		cout<<a[n]<<"\n";
	}
	return 0;
}