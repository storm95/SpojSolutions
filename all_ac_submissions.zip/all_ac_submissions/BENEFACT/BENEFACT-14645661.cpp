#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define sz 50005
#define P pair<int,int>
#define fs first
#define sd second
using namespace std;
vector<P >adj[sz];
int vis[sz],x,mx;
void dfs(int i,int l)
{
    if(l>mx)
    {
        mx=l;
        x=i;
    }
    vis[i]=1;
    for(int j=0;j<adj[i].size();j++)
    {
        if(vis[adj[i][j].fs]==0)
            dfs(adj[i][j].fs,l+adj[i][j].sd);
    }
}

int main()
{
    int t,n,i,j,u,v;
    sfd(t);
    while(t--)
    {
        sfd(n);
        for(i=1;i<=n;i++)
        {
            adj[i].clear();
        }
        for(i=0;i<n-1;i++)
        {

            sfd(u);
            sfd(v);
            sfd(j);
            adj[u].push_back(make_pair(v,j));
            adj[v].push_back(make_pair(u,j));
        }
        i=1;
        while(adj[i].size()==0)
        i++;
        memset(vis,0,sizeof(vis));
        mx=-1;
        dfs(i,0);
        memset(vis,0,sizeof(vis));
        mx=-1;
        dfs(x,0);
        pfd(mx);
    }
    return 0;
}
