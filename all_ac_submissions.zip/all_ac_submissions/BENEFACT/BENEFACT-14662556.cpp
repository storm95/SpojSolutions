#include<bits/stdc++.h>
using namespace std;
bool vis[50005];
vector<pair<int,int> >g[50005];
int maxi  = -1;
int max_pos = 0;
int bfs(int n,bool flag)
{
vis[n] = true;
queue<pair<int,int> > Q;
while(!Q.empty()) Q.pop();
Q.push(make_pair(n,0));
int dist = 0;
int u;
while(!Q.empty())
    {
        u =  Q.front().first;
        dist = Q.front().second;
        if(dist>maxi)
        {
        	maxi = dist;
        	max_pos = u ;
        }
        Q.pop();
        for(int i=0;i<g[u].size();i++)
        {
            if(!vis[g[u][i].first])
            {
                vis[g[u][i].first] = true;
                Q.push(make_pair(g[u][i].first,dist + g[u][i].second));
            }
        }
    }
if(!flag)
{
maxi = -1;
return max_pos;
}
else
return maxi;
}



int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        for(int i = 0 ;i<50005;i++)
        g[i].resize(0);
        for(int i = 0 ;i<50005;i++)
        vis[i] = 0;
        
        maxi  = -1;
		max_pos = 0;

        int n;
        scanf("%d",&n);
        int u,v,dist;
        for(int i=0;i<n-1;i++)
        {
           scanf("%d%d%d",&u,&v,&dist);
           g[u].push_back(make_pair(v,dist));
           g[v].push_back(make_pair(u,dist));
        }
        bool flag = false;
        int next = bfs(u,flag);
        for(int i = 0 ;i<50005;i++)
        vis[i] = 0;
        flag = true;
        printf("%d\n",bfs(next,flag));
    }
    return 0;
}
