/* e_coder :: MD ABDUSSAMAD
	Birla Institute Of Technology, Mesra
	cse dept.
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    int k;
    scanf("%d",&k);
    while(k--)
    {
        int a,b,c,d,e,f;
        scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
        a=a-e;
        b=b-f;
        c=c-e;
        d=d-f;
        if(abs(c)==abs(d))
        {
            int z= c*a>=0 && d*b>=0;
            z=z && (abs(c)==abs(a)+abs(abs(c)-abs(a))) && (abs(d)==abs(b)+abs(abs(d)-abs(b)));
            if(z) printf("NO\n");
            else printf("YES\n");
        }
        else printf("YES\n");
    }
return 0;
}
