#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;

int main()
{
    int  mx,my,ax,ay,bx,by,mt,ct,ml,mr,cr,cl,mb,cb;
    int t,r,c;
    sfd(r);
    sfd(c);
    sfd(t);
    while(t--)
    {
        cin>>mx>>my>>ax>>ay>>bx>>by;
        if((mx>=ax&&mx>=bx)||(mx<=ax&&mx<=bx)||(my>=ay&&my>=by)||(my<=ay&&my<=by))
             printf("YES\n");
        else
        {
            mt=abs(1-mx);
            ct=min(abs(1-ax)+abs(ay-my),abs(1-bx)+abs(by-my));
            mb=abs(r-mx);
            cb=min(abs(r-ax)+abs(ay-my),abs(r-bx)+abs(by-my));

            mr=abs(1-my);
            cr=min(abs(1-ay)+abs(ax-mx),abs(1-by)+abs(bx-mx));
            ml=abs(c-my);
            cl=min(abs(c-ay)+abs(ax-mx),abs(c-by)+abs(bx-mx));
            if(mt<ct||mb<cb||mr<cr||ml<cl)
                 printf("YES\n");
            else
                 printf("NO\n");
        }
    }
    return 0;
}
