#include <bits/stdc++.h>>
using namespace std;

int main() {
	
	int t;
	cin>>t;
	long long ans=0LL;
	for(int i=1;i<=sqrt(t);i++)
		ans+=(t/i-i+1);
	cout<<ans<<endl;

	return 0;
}