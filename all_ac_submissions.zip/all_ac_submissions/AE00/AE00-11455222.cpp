#include<bits/stdc++.h>
int main()
{
    int n,i,ans=0;
    scanf("%d",&n);
    for(i=1;i<=((int)sqrt(n));i++)
        ans+=(n/i-i+1);
    printf("%d",ans);
    return 0;
}