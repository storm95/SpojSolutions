//Rectangles
#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
        int n,j,i,count=0,sq,count1=0;
        scanf("%d",&n);
        sq=sqrt(n);
        for(i=1;i<=n;++i)
        {
                count+=n/i;
                if((n/i)>=i)
                ++count1;
        }
        printf("%d\n",(count+count1)/2);
        return 0;
}
