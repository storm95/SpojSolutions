//Rectangles
#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
        int n,j,i,count=0,sq,count1=0,flag=0;
        scanf("%d",&n);
        count=n;
        sq=sqrt(n);
        for(i=2;i<=n;++i)
        {
                if(flag)
                {
                        count+=n-i+1;
                        break;
                }
                count+=n/i;
                if(n/i==1)
                flag=1;
                if((n/i)>=i)
                ++count1;
        }
        printf("%d\n",(count+count1+1)/2);
        return 0;
}

