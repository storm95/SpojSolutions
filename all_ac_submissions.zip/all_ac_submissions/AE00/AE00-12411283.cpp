#include <iostream>

using namespace std;

int main()
{
    int i,j,n,ct=0,f=0;
    cin>>n;
    for(i=2;i<n/2;i++)
    {
        if(f==0)
        {
            for(j=i;j<=n/2;j++)
            {
                if(i*j<=n)
                    ct++;
                else
                    break;
            }
        }

    }
    cout<<ct+n;
    return 0;
}
