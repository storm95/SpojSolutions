//Rectangles
#include<iostream>
#include<cstdio>
int main()
{
        int n,j,i,count=0;
        scanf("%d",&n);
        for(i=1;i<=n;i++)
        {
                for(j=1;j<=i;j++)
                {
                        if( (i*j)>n )
                        break;
                        count++;
                }
        }
        printf("%d\n",count);
        return 0;
}