#include<bits/stdc++.h>
#define mp make_pair
using namespace std;
typedef pair<int,pair<int,int> > pr;
static int fix[][2]={{1,0},{0,1},{0,-1},{-1,0}};
int n,m;
int dx,dy,T;
int s[105][105];
bool mark[105][105];
void solve()
{
    priority_queue<pr>que;
    memset(mark,true,sizeof(mark));
    if(s[0][0]<=T) que.push(mp(T-s[0][0],mp(0,0)));
    mark[0][0]=false;
    while(!que.empty())
    {
        int cost=(que.top().first);
        int i=que.top().second.first;
        int j=que.top().second.second;
        que.pop();
        if(i==dx && j==dy)
        {
            printf("YES\n%d\n",cost);
            return ;
        }
        for(int k=0;k<4;k++)
        {
            int x=i+fix[k][0];
            int y=j+fix[k][1];
            if(x>=0 && x<n && y>=0 && y<m)
            {
                int c=cost-s[x][y];
                if(c>=0 && mark[x][y])
                {
                    que.push(mp(c,mp(x,y)));
               }
            }
        }
        mark[i][j]=false;
    }
printf("NO\n");
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        for(int i=0;i<n;i++)
            for(int j=0;j<m;j++) scanf("%d",&s[i][j]);
        scanf("%d%d%d",&dx,&dy,&T);
        dx--;
        dy--;
        solve();
    }
    return 0;
}
