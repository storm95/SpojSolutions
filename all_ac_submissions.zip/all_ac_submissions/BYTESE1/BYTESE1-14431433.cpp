#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
queue<int>x;
int main()
{
    int t,n,m,a,b,T,i,j,dp[101][101],p,v[101][101];
    sfd(t);
    while(t--)
    {
        sfd(m);
        sfd(n);
        queue<int>x,y;
        for(i=0;i<m;i++)
            for(j=0;j<n;j++)
             {
                 sfd(dp[i][j]);
                 v[i][j]=100000;
             }
        sfd(a);
        sfd(b);
        sfd(T);
        a--;
        b--;
        v[0][0]=dp[0][0];
        x.push(0);
        y.push(0);
        while(!x.empty())
        {
            i=x.front();
            j=y.front();
            x.pop();
            y.pop();
            int dx[4]={1,0,0,-1};
            int dy[4]={0,1,-1,0};
            for(p=0;p<4;p++)
            {
                int nx=dx[p]+i,ny=dy[p]+j;
                if(nx>=0&&nx<m&&ny>=0&&ny<n)
                {
                    if(v[nx][ny]>v[i][j]+dp[nx][ny])
                    {
                        v[nx][ny]=v[i][j]+dp[nx][ny];
                        x.push(nx);
                        y.push(ny);
                    }
                }
            }
        }
         if(v[a][b]<=T)
         {
             cout<<"YES\n"<<T-v[a][b]<<endl;
         }
         else
            cout<<"NO"<<endl;
    }
    return 0;
}
