#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int color[2005];
vector<int> adj[2005];
bool f;

void dfs(int x)
{
    for(int i=0;i<adj[x].size();i++)
    {
        int to=adj[x][i];
        //cout<<i<<" "<<to<<'\n';
        if(color[to]==-1)
            {color[to]=1-color[x];
            dfs(to);}
        else if(color[to]==color[x])
            {f=0;return;}
    }
    return;

}

int main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);
    int t,n,x,y;
    ll m;
    scanf("%d",&t);
    int cnt=t;
    while(t--)
    {
        f=1;
        memset(adj,0,sizeof adj);
        memset(color,-1,sizeof color);
        scanf("%d%lld",&n,&m);

        for(ll i=0;i<m;i++)
        {
            scanf("%d%d",&x,&y);
            x--;y--;
            adj[x].push_back(y);
            adj[y].push_back(x);
        }

        for(int i=0;i<n;i++)
        {
            if(color[i]==-1)
                {color[i]=0;dfs(i);}
            if(f==0)
                break;

        }
        //cout<<"f= "<<f<<'\n';
        printf("Scenario #%d:\n",cnt-t);
        if(f==0)
            printf("Suspicious bugs found!\n");
        else
            printf("No suspicious bugs found!\n");

    }


    return 0;
}

