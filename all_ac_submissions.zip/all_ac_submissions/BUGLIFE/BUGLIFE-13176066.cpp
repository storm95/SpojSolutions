#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define pb push_back
#define pf push_front
#define gc getchar_unlocked
#define pc putchar_unlocked
#define all(A) A.begin(),A.end()
#define mp make_pair
#define si(x) scanf("%d",&x)
#define slli(x) scanf("%lld",&x)
#define vi vector<int>
#define vvi vector < vi >
#define pii pair< int , int >
#define pic pair<int,char>
#define vpic vector< pic >
#define vll vector < ll >
#define vpll vector < pair < ll , ll > >
#define vpii vector< pii >
#define TC int tc; si(tc); while(tc--)
#define PI   3.14159265358979323846264338327950
#define mod 1000000007
#define MAXN 100009
using namespace std;

int N,E,A,B;
int color[2009];
bool vis[2009];
vi G[2009];

inline bool BIPARTITE(int root) {
     memset(color,-1,sizeof(color));
     memset(vis,false,sizeof(vis));
     queue <int> Q;
     Q.push(root);
     color[root] = 1;
     vis[root] = true;
     while(!Q.empty()) {
	   int cur = Q.front();
	   Q.pop();
	   for(int i = 0;i < (int)G[cur].size();++i) {
		     if(!vis[ G[cur][i] ]) {
				  vis[G[cur][i]] = true;
				  Q.push(G[cur][i]);	
			  }
			  if(color[G[cur][i]] == -1) {
			      color[G[cur][i]] = !color[cur];
			   } else if(color[G[cur][i]] == color[cur]) {
			       return false;
			  }   
	     }
	 }
  return true;
}

int main() {
   int cur = 0;
   TC {
	 bool ok = true;
     si(N); si(E);
     for(int i = 0;i < E;++i) { 
	    si(A); si(B);
	    G[A].pb(B);
	    G[B].pb(A);	 
	 }
	 for(int i = 1;i <= N;++i) {
	   ok = BIPARTITE(i);
	   if(ok == false) break;
     }
	 if(ok) printf("Scenario #%d:\nNo suspicious bugs found!\n",++cur);
	 else   printf("Scenario #%d:\nSuspicious bugs found!\n",++cur);
	 for(int i = 0;i < 2009;++i) G[i].clear();
   }
   return 0;
}
