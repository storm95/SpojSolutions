#include<bits/stdc++.h>
using namespace std;
int f=0;
vector<vector<int> > v(2001);
int visited[2001];
int color[2001] ;
void dfs(int x,int cur)
{
    visited[x]=1;
    color[x] = cur;
    int s= v[x].size();
    int cur1;
    if(cur == 1) cur1 = 2;
    else if(cur==2) cur1 = 1;

    for(int i=0;i<s&&(f==0);i++)
    {
        if(color[v[x][i]] == cur)
        {
            f=1;
            return ;
        }
        else if(color[v[x][i]]== 0)
        {

            dfs(v[x][i],cur1);
        }
    }
    return ;

}

int  main()
{
    int tc,n,m;
    int x,y;
    scanf("%d",&tc);
    for(int k=1;k<=tc;k++){

        memset(color,0,sizeof(color));
        memset(visited,0,sizeof(visited));
        f=0;
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;++i)
        {
            v[i].clear();
        }
    for(int i=0;i<m;++i)
    {
        scanf("%d%d",&x,&y);
        v[x].push_back(y);
        v[y].push_back(x);

    }
    for(int i=1;i<=n;++i){
        if(!visited[i])
        dfs(i,1);
    }
    printf("Scenario #%d:\n",k);
        if(f==1)
            printf("Suspicious bugs found!\n");
        else if(f==0)
            printf("No suspicious bugs found!\n");
    }
    return 0;
}
