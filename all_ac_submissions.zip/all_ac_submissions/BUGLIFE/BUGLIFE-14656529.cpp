#include<bits/stdc++.h>
using namespace std;
int col[2500];
vector<int> g[2500];
bool bfs(int n)
{
queue<int> Q;
while(!Q.empty()) Q.pop();
col[n] = 1;
Q.push(n);
bool flag  = true;
while(!Q.empty())
    {
        int u = Q.front();
        Q.pop();
        for(int i=0;i<g[u].size();i++)
        {
            int temp = g[u][i];
            if(col[temp] == 0)
                {
                    if(col[u]==1)
                    col[temp]  = 2;
                    else col[temp] = 1;
                    Q.push(temp);
                }
            else
            {
                if(col[temp] == col[u])
                    {
                    	flag = 0;
                    	break;
                    }
            }
        }
    }
if(flag)
return true;
else return false;
}

int main()
{
    int t;
    scanf("%d",&t);
    for(int j=1;j<=t;j++)
    {
        for(int i=0;i<2500;i++) g[i].resize(0);
        for(int i=0;i<2500;i++) col[i] = 0;
        int n;
        scanf("%d",&n);
        int e;
        scanf("%d",&e);
        int u,v;
        for(int i=0;i<e;i++)
        {
            scanf("%d %d",&u,&v);
            g[u].push_back(v);
            g[v].push_back(u);
        }
        bool  res = true;
        for(int i=1;i<=n;i++)
        {
        if(col[i] == 0)
        {
	        res = bfs(i);
	        if(res == false) 
	        {
	        	break;
	        }
        }
        }
        printf("Scenario #%d:\n",j);
        if(res)
            printf("No suspicious bugs found!\n");
        else
            printf("Suspicious bugs found!\n");
    }
    return 0;
}
