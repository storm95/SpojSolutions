#include<bits/stdc++.h>
#define lli long long int
using namespace std;
int main()
{
    //ios::sync_with_stdio(false);
    int test;
    scanf("%d",&test);
    for(int t=0; t<test; t++)
    {
        int v,e,a,b;
        scanf("%d%d",&v,&e);
        vector<int>arr[v];
        for(int i=0; i<e; i++)
        {
            scanf("%d%d",&a,&b);
            arr[a-1].push_back(b-1);
            arr[b-1].push_back(a-1);
        }
        //dfs to check cycle with odd number of nodes
        int vis[v],temp[v],c=0;
        fill(vis,vis+v,0);
        fill(temp,temp+v,0);
        for(int i=0; i<v; i++)
        {
            stack<int>mys;
            if(vis[i]==0)
            {
                mys.push(i);
                temp[i]=1;
            }
            else
                continue;
            //cout<<"first "<<i<<endl;
            while(!mys.empty())
            {
                a=mys.top();
                vis[a]=1;
                mys.pop();
                for(int i=0; i<arr[a].size(); i++)
                {
                    b=arr[a][i];
                    //cout<<a<<" -->"<<b<<endl;
                    if(vis[b]==0)
                    {
                        mys.push(b);
                        temp[b]=temp[a]+1;
                    }
                    else
                    {
                        if(abs(temp[b]-temp[a])%2==0){
                            c=1;
                            break;
                        }
                    }
                    //cout<<b<<" "<<temp[b]<<endl;
                }
                if(c==1)
                    break;
            }
            if(c==1)
                break;
        }
        printf("Scenario #%d:\n",t+1);
        if(c==1)
            printf("Suspicious bugs found!\n");
        else
            printf("No suspicious bugs found!\n");
    }
    return 0;
}
