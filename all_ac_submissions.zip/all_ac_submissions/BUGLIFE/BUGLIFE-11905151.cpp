#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
vector< vector<int> > arr(2001);
int gen[2001],b;
int fun(int index,int gender)
{
    //int p=(gen[index]==0?1:0);
    if(gen[index]==-1)
    {
        gen[index]=gender;
        int len=arr[index].size();
        int opp=(gender==0?1:0);
        for(int i=0;i<len;i++)
        {
            if(gen[arr[index][i]]==gen[index])
                b=1;
            else
            {
                fun(arr[index][i],opp);
            }
        }
    }
}
int main()
{
    int t,i,j,a,c,n;
    scanf("%d",&t);
    for(j=1;j<=t;j++)
    {
        scanf("%d %d",&n,&a);
        for(i=0;i<=n;i++)
        {
            arr[i].clear();
            gen[i]=-1;
        }
        while(a--)
        {
            int f,m;
            scanf("%d %d",&f,&m);
            arr[f].push_back(m);
            arr[m].push_back(f);
        }
        int k;b=0;
        for(k=1;k<=n;k++)
            {
                if(b==1)
                break;
                if(gen[k]==-1)
                fun(k,0);
            }
        printf("Scenario #%d:\n",j);
        if(b)
            cout<<"Suspicious bugs found!\n";
        else cout<<"No suspicious bugs found!\n";
    }
    return 0;
}


