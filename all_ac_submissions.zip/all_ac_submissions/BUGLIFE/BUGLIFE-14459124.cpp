#include<bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
int mark[2001];
bool BFS(vector<vi> V, int src)
{
    mark[src]=1;
    queue <int> q;
    q.push(src);
    while (!q.empty())
    {
        int u=q.front();
        q.pop();
        int sz=V[u].size();
        for(int j=0;j<sz;j++)
        {
            int v=V[u][j];
            if(mark[v]==-1)
            {
                mark[v]=1-mark[u];
                q.push(v);
            }
            else
                if(mark[v]==mark[u])
                    return false;
        }
    }
    return true;
}
int main()
{
    int t;
    scanf("%d",&t);
    for(int sn=1;sn<=t;sn++)
    {
        int n,e;
        scanf("%d%d",&n,&e);
        vector<vi> V(n+1);
        for(int i=0;i<e;i++)
        {
            int s,d;
            scanf("%d%d",&s,&d);
            V[s].push_back(d);
            V[d].push_back(s);
        }
        for(int i=0;i<=n;i++)
            mark[i]=-1;
        int f=1;
        for(int i=1;i<=n;i++)
        {
            if(mark[i]==-1)
            {
                if(!BFS(V,i))
                {
                    f=0;
                    break;
                }
            }
        }
        printf("Scenario #%d:\n",sn);
        if(f==0) printf("Suspicious bugs found!\n");
        else printf("No suspicious bugs found!\n");
    }
    return 0;
}
