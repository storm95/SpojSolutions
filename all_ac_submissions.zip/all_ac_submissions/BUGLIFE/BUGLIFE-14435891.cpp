#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

queue<int>q;
int dp[2006];
int main()
{
    int t,v,e,a,b,i,j,g=1;
    sfd(t);
    while(g<=t)
    {
        sfd(v);
        sfd(e);
        set<int>s;
        set<int>::iterator it;
        vector<int>adj[2006];
        while(e--)
        {
            sfd(a);
            sfd(b);
            s.insert(a);
            s.insert(b);
            adj[a].push_back(b);
            adj[b].push_back(a);
        }
        cout<<"Scenario #"<<g<<":"<<endl;
        g++;
        memset(dp,-1,sizeof(dp));
        int f=0,k=0;
      while(!s.empty()&&f==0)
        {
            it=s.begin();
            //cout<<*it<<endl;
            q.push(*it);
            s.erase(it);
            dp[*it]=1-k;
        while(!q.empty()&&f==0)
        {
            i=q.front();
            q.pop();
            s.erase(i);
            k=1-dp[i];
            for(j=0;j<adj[i].size();j++)
            {
                if(dp[adj[i][j]]==-1)
                   {
                       dp[adj[i][j]]=k;
                       q.push(adj[i][j]);
                   }
                else if(dp[adj[i][j]]==1-k)
                {
                    f=1;
                    break;
                }
            }
        }

      }
        while(!q.empty())
            q.pop();
        s.clear();
        if(f==1)
            cout<<"Suspicious bugs found!"<<endl;
        else
            cout<<"No suspicious bugs found!"<<endl;
    }
    return 0;
}
