#include<bits/stdc++.h>
using namespace std;
struct node
{
    int data;
    struct node *next;
}*start1,*start2,*start3;
struct node *create_node(int data)
{
        struct node *newptr = (struct node *)malloc(sizeof(struct node *));
        newptr->data = data;
        return newptr;
}
int revnum(int n)
{
    int ret = 0;
    while(n)
    {
        ret*=10;
        ret+=n%10;
        n/=10;
    }
return ret;
}
void addnum()
{
    struct node *ptr1,*ptr2,*prev;
    ptr1 = start1;ptr2 = start2;
    int carry =  0;
    while(ptr1!=NULL || ptr2 !=NULL)
    {
        int sum  = carry + ((ptr1)?(ptr1->data):(0)) + ((ptr2)?(ptr2->data):(0)) ;
        carry = (sum>9)?(1):(0);
        sum%=10;
        struct node *temp = create_node(sum);
        if(start3 == NULL)
           start3 = temp;
        else prev ->next = temp;
        prev = temp;
        if(ptr1) ptr1 = ptr1->next;
        if(ptr2) ptr2 = ptr2->next;
    }
    if(carry)
        prev->next = create_node(carry);
}
void reverse_list(struct node *head)
{
    struct node *ptr = head,*prev = NULL,*next ;

    while(ptr!=NULL)
    {
        next = ptr->next;
        ptr->next = prev;
        prev = ptr;
        ptr = next;
    }
    start3 = prev;
}

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        start1 = start2 = start3 = NULL;
        start1 = NULL;start2=NULL;
        int n,m;
        scanf("%d%d",&n,&m);
        struct node *prev;
        n=revnum(n);
        m=revnum(m);
        while(n)
        {
            struct node *temp = create_node(n%10);
            if(start1==NULL)
            {
                start1 = temp;
            }
            else prev->next =temp;
            prev = temp;
            n/=10;
        }

        while(m)
        {
            struct node *temp = create_node(m%10);
            if(start2==NULL)
            {
                start2 = temp;
            }
            else prev->next =temp;
            prev = temp;
            m/=10;
        }
        addnum();
        struct node *ptr = start3;
        while(ptr!=NULL)
        {
            if(ptr->data!=0)
                break;
            ptr = ptr->next;
        }

        while(ptr!=NULL)
            {
                printf("%d",ptr->data);
                ptr = ptr->next;
            }
    printf("\n");
    }
    return 0;
}
