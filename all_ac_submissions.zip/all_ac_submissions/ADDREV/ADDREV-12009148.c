#include<stdio.h>
inline int reverse(int a)
{
    int ans=0;
    while(a)
    {
        ans=ans*10+a%10;
        a/=10;
    }
    return ans;
}
int main()
{
    int a,b,tc;
    scanf("%d",&tc);
    while(tc--)
    {
        scanf("%d%d",&a,&b);
        a=reverse(a);
        b=reverse(b);
        a=reverse(a+b);
        printf("%d\n",a);
    }
    return 0;
}



