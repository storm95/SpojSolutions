#include <stdio.h>
#include <stdlib.h>
 int rev(int num)
 {
    int r,rev=0;



    while(num)
    {
         r=num%10;
         rev=rev*10+r;
         num=num/10;
    }


    return rev;
}
int main()
{
    int t,a,b;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&a);
        scanf("%d",&b);
        a=rev(a);
        b=rev(b);
        printf("%d\n",rev(a+b));
    }

    return 0;
}
