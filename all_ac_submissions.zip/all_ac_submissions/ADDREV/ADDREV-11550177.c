#include <stdio.h>
#include <stdlib.h>
int fun(int i)
{int p,r=0;
while(i>0)
    {
        p=i%10;
        r=(r*10)+p;
        i=i/10;
    }
return r;
}

int main()
{
    int n,i,j,r,q,s;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d %d",&i,&j);
        r=fun(i);
        q=fun(j);
        s=r+q;
        printf("%d\n",fun(s));
        n--;

    }
    return 0;

}
