#include<bits/stdc++.h>
using namespace std;
#define mod 1000000007
long long pwr(int a,long long b)
{
    if(b==0) return 1;
    long long x=pwr(a,b>>1);
    x=(x*x)%mod;
    if(b&1) return (a*x)%mod;
    return x;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long n;
        scanf("%lld",&n);
        long long k=n%mod;
        long long ans=pwr(10,n);
        long long inv=pwr(9,mod-2);
        ans=10*(ans-1)%mod;
        ans=(ans*inv)%mod;
        ans=ans-(10*k)%mod;
        if(ans<0) ans+=mod;
        ans=(ans*5)%mod;
        ans=(ans*inv)%mod;
        ans=(ans+6*k)%mod;
        printf("%lld\n",ans);
    }
    return 0;
}
