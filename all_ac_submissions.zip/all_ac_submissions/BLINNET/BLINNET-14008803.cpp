#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;
vector< vector<int> > G(10010);
bool visited[10010];
typedef struct 
{
	int x,y,c;
}edge;
vector<edge> edges;
int main()
{
	int t;
	string s;
	int n,m,x,l;
	int c,ans;
	scanf("%d",&t);
	while(t--)
	{
		ans=l=0;
		scanf("%d",&n);
		edges.clear();
		for(int i=1;i<=n;++i)
		{
			G[i].clear();
			visited[i]=false;
		}
		for(int i=1;i<=n;++i)
		{
			cin>>s;
			scanf("%d",&m);
			while(m--)
			{
				scanf("%d%d",&x,&c);
				G[i].push_back(l);
				edges.push_back((edge){i,x,c});
				++l;
			}
		}
		priority_queue<pii,vector<pii>, greater<pii> > pp;
		int cou=1;
		visited[1]=true;
		int len=G[1].size();
		for(int i=0;i<len;++i)
		{
			int ind=G[1][i];
			if(!visited[edges[ind].y])
				pp.push(pii(edges[ind].c,ind));
		}
		while(cou<n)
		{
			
			int z = pp.top().second;
			pp.pop();
			int v=edges[z].y;
			if(visited[v])
				continue;
			visited[v]=true;
			int len=G[v].size();
			for(int i=0;i<len;++i)
			{
				int ind=G[v][i];
				if(!visited[edges[ind].y])
					pp.push(pii(edges[ind].c,ind));
			}
			ans+=edges[z].c;
			++cou;
		}
		printf("%d\n",ans );
	}
	return 0;
}