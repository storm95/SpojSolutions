#include <bits/stdc++.h>

using namespace std;

const int NMAX = 10009;

int tc;
int n,from,to,cost,edges;
int parent[NMAX];
string city;

vector < pair < int , pair < int , int > > > G;

inline int find(int v) {
   if(parent[v] != v)  v = find(parent[v]);
   return v;	
}

int main () {
  scanf("%d",&tc);
  
  while(tc--) {
      scanf("%d",&n);
      
      G.clear();
      
       for (int i = 1;i <= n;++i) {
        int from = i;
        parent[i] = i;
            
        cin >> city;
        scanf("%d",&edges);
 
         while (edges--) {
		     scanf("%d %d",&to,&cost);
		     if(to > from)
		     G.push_back ( make_pair (cost , make_pair(from,to) ) );
		 }
      }
    
      sort(G.begin() , G.end());
      
      int cost = 0;
      for(int i = 0;i < (int)G.size(); ++i) {
		   
		   int u = find( G[i].second.first );
		   int v = find( G[i].second.second );
		   
		   if(find(u) != find(v)) {
			   parent[u] = parent[v];
			   cost = cost + G[i].first;   
		   }  
	  }  
     
     printf("%d\n",cost);
  }	
  return 0;
}
