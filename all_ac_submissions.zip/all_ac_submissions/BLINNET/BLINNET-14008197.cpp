#include<bits/stdc++.h>
using namespace std;
int parent[10010];
int rank[10010];
typedef pair<int,int> pii;
typedef pair<long long ,int> pyy;
vector<pyy> v;
vector<pii> edge;
int find(int x)
{
	if(parent[x]==x)
		return x;
	return (parent[x]=find(parent[x]));
}
int join(int x,int y)
{
	int px = find(x);
	int py = find(y);
	if(rank[px]>rank[py])
	{
		parent[py]=px;
	}
	else 
	{
		parent[px]=py;
		if(rank[px]==rank[py])
			++rank[px];
	}
}
int main()
{
	int t;
	string s;
	int n,m,x,l;
	long long c,ans;
	scanf("%d",&t);
	while(t--)
	{
		l=0;
		ans=0LL;
		edge.clear();
		v.clear();
		scanf("%d",&n);
		for(int i=1;i<=n;++i)
		{
			parent[i]=i;
			rank[i]=0;
			cin>>s;
			//cout<<s<<"\n";
			scanf("%d",&m);
			while(m--)
			{
				scanf("%d%lld",&x,&c);
				edge.push_back(pii(i,x));
				++l;
				v.push_back(pyy(c,l));
			}
		}
		sort(v.begin(),v.end());
		int len=v.size();
		for(int i=0;i<len;++i)
		{
			int ind = v[i].second-1;
			long long  c=v[i].first;
			int x=edge[ind].first;
			int y=edge[ind].second;
			//cout<<"Edge: "<<ind<<" "<<x<<" "<<y<<" "<<c<<"  ";
			if(find(x)!=find(y))
			{
				join(x,y);
			//	cout<<"Selected";
				ans+=c;
			}
			//cout<<"\n";
		}
		printf("%lld\n",ans );
	}
	return 0;
}