#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lf 2*idx
#define rt 2*idx+1

using namespace std;

int main()
{
    ll a[10005],mx,mn;
    int n,t,i,j;
    sfd(t);
    while(t--)
    {
        sfd(n);
        for(i=0;i<n;i++)
        {
            sflld(a[i]);
        }
        i=0;
        j=n-1;
        ll ans=0;
        while(i<=j)
        {
           ans+=(j-i)*(a[j]-a[i]);
           i++;
           j--;
        }
        pflld(ans);
    }


    return 0;
}
