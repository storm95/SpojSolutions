#include <bits/stdc++.h>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>

using namespace std;

int main()
{
    int t,n,i,j;
    long long int a[10000],s;
    scanf("%d",&t);
    while(t--)
    {
        s=0;
         scanf("%d",&n);
         for(i=0;i<n;i++)
             scanf("%lld",&a[i]);
         i=n-1;
         j=i;
         while(i>=1)
         {
             s+=i*(a[i]-a[j-i]);
             //cout<<s;
             i--;
         }
         printf("%lld\n",s);
    }
    return 0;
}
