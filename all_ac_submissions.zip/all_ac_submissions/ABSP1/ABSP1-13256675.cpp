/*
   jetpack
*/
#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstring>
#include <stack>
#include <queue>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <utility>
#include <algorithm>
#include <limits.h>
//or use #include<bits/stdc++.h>

typedef long long ll;
#define loop(i, a, b) for(i=a; i<b; i++)
#define loope(i, a, b) for(i=a; i<=b; i++)
#define loopr(i, a, b) for(i=a; i>b; i--)
#define loopre(i, a, b) for(i=a; i>=b; i--)
#define MOD 1000000007

using namespace std;

int main()
{
    int t,n,i;
    ll a[10005]={0};
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(i=0;i<n;i++)
        {
            cin>>a[i];
        }
        ll s=0,d=0;
        for(i=n-1;i>=0;i--)
        {
            s+=(i*a[i]);
        }
        for(i=0;i<n;i++)
        {
            d+=(n-i-1)*a[i];
        }
        cout<<abs(s-d)<<endl;

    }
    return 0;
}
