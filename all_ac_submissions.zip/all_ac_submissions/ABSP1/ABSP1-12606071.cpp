#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        long long d=0;
        int a[n];
        for(int i=0;i<n;i++) cin>>a[i];
        for(int i=0;i<n;i++)
        {
            d+=((n-1-2*i)*a[n-1-i]);
        }
        cout<<d<<endl;
    }
    return 0;
}
