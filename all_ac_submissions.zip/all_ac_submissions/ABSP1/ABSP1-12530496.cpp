#include<cstdio>
#include<algorithm>
using namespace std;
long long int arr[1000000],a[1000000];
int main()
{
    int test;
    scanf("%d",&test);
    while(test--)
    {
        long long int n,sum=0,i,temp;
        scanf("%lld",&n);
        for(i=0;i<n;i++)
            scanf("%lld",&arr[i]);
        sort(arr,arr+n);
        temp=arr[0];
        for(i=0;i<n-1;i++)
            arr[i]=arr[i+1]-temp;
        n--;
        //for(i=0;i<n;i++)
          //  printf("%d\n",arr[i]);
        for(i=0;i<n;i++)
            sum+=arr[i];
        a[0]=arr[0];
        for(i=0;i<n;i++)
            a[i+1]=arr[i+1]-arr[i];
        temp=sum;
        for(i=0;i<n;i++)
        {
            sum+=(temp-a[i]*(n-i));
            temp=temp-(a[i]*(n-i));
        }
        printf("%lld\n",sum);
    }
    return 0;
}
