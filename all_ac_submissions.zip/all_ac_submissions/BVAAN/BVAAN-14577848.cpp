#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1
using namespace std;
int dp[105][105][105];
char a[101],b[101];
int cal(int i,int j,int k)
{
    if(k==0)
        return 0;
    if(i==-1||j==-1)
        return -1;
    int s1=-1,s2=-1,s3=-1;
    if(dp[i][j][k]!=-2)
        return dp[i][j][k];
    if(a[i]==b[j])
    {
        s1=cal(i-1,j-1,k-1);
        if(s1!=-1)
            s1+=a[i];
    }
    s2=cal(i-1,j,k);
    s3=cal(i,j-1,k);
    dp[i][j][k]=max(s1,max(s2,s3));
    return dp[i][j][k];
}
int main()
{

    int t,k,i,j;
    sfd(t);
    while(t--)
    {
        sfs(a);
        sfs(b);
        sfd(k);
        for(int x=0;x<102;x++)
			for(int y=0;y<102;y++)
				for(int z=0;z<102;z++)
					dp[x][y][z]=-2;
        int ans=cal(strlen(a)-1,strlen(b)-1,k);
        if(ans==-1)
            ans=0;
        pfd(ans);
    }
    return 0;
}
