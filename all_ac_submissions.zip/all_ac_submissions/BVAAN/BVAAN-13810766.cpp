#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <utility>
#include <cassert>
#include <string>
#include <cmath>
#include <cstdlib>
#include <algorithm>

using namespace std;

typedef long long LL;
typedef vector < int > vi;
typedef vector < vi > vvi;

#define pb push_back
#define mp make_pair

const int MAXN = (int)(1e5 + 9);
const int MOD  = (int)(1e9 + 7);

int dp[109][109][109];
string A,B;
int k,tc;

inline int go(int i,int j,int k) {
     if((i < 1) || (j < 1) || (k < 1)) return 0;
     if(dp[i][j][k] != -1) return dp[i][j][k];
     if(A[i - 1] == B[j - 1]) {
     	dp[i][j][k] = max(go(i-1,j,k),go(i,j-1,k));
        int temp = go(i-1,j-1,k-1);
        if((temp > 0) || (k == 1))
     	dp[i][j][k] = max(dp[i][j][k],temp + (int)A[i - 1]);
     } else {
     	dp[i][j][k] = max(go(i-1,j,k),go(i,j-1,k));
     }
     return dp[i][j][k];
}

int main () {
    
    scanf("%d",&tc);

    while(tc--) {
        cin >> A >> B;
        scanf("%d",&k);
        int lenA,lenB;
        lenA = (int)A.length();
 		lenB = (int)B.length();
        memset(dp,-1,sizeof(dp));
        printf("%d\n",go(lenA,lenB,k));
    }

	return 0;
}
