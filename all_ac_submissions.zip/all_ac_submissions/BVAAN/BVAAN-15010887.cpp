#include<bits/stdc++.h>
using namespace std;
char b1[200];
char b2[200];
int dp[102][102][102];
int main()
{
	int t,k;
	int len1,len2;
	cin>>t;
	while(t--)
	{
		cin>>b1;
		cin>>b2;
		cin>>k;
		len1 = strlen(b1);
		len2 = strlen(b2);
	/*	for(int i=0;i<=len1;++i)
			for(int j=0;j<=len2;++j)
				dp[i][j][0]=0;
		for(int i=0;i<=len1;++i)
			for(int j=0;j<=k;++j)
				dp[i][0][j]=0;
		for(int i=0;i<=k;++i)
			for(int j=0;j<=len2;++j)
				dp[0][j][k]=0;
		*/	
		memset(dp,0,sizeof(dp));
		for(int kk=1;kk<=k;++kk)
		{
			for(int i=1;i<=len1;++i)
			{
				for(int j=1;j<=len2;++j)
				{
					dp[i][j][kk] = max(dp[i-1][j-1][kk],max(dp[i][j-1][kk],dp[i-1][j][kk]));
					if(b1[i-1]==b2[j-1])
					{
						if(kk==1||dp[i-1][j-1][kk-1]>0)
						dp[i][j][kk] = max(dp[i][j][kk],dp[i-1][j-1][kk-1]+b1[i-1]);
					}
				}
			}
		}
		/*for(int kk=0;kk<=k;++kk)
		{
			cout<<kk<<":\n";
			for(int i=1;i<=len1;++i)
			{
				for(int j=1;j<=len2;++j)
				{
					cout<<dp[i][j][kk]<<" ";
				}
				cout<<"\n";
			}
		}
		*/
		cout<<dp[len1][len2][k]<<"\n";
	}
	return 0;
}