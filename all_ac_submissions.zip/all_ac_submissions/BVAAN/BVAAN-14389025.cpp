#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int A[102][102][102];
char a[102],b[102];
int chk;
int solve(int n,int m,int k)
{
    if(n==0 || m==0 || k==0)
    {
        if(k==0) chk=1;
    return 0;
    }
    if(A[n][m][k]!=-1) return A[n][m][k];
    else
    {
        if(a[n-1]!=b[m-1]){ A[n][m][k]=max(solve(n-1,m,k),solve(n,m-1,k));}
        else
        {
            A[n][m][k]=max((int)a[n-1]+solve(n-1,m-1,k-1),max(solve(n-1,m,k),solve(n,m-1,k)));
        }
        return A[n][m][k];
    }
}
int main()
{
    int t,k,sum;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s %s %d",a,b,&k);
        int n=strlen(a);
        int m=strlen(b);
        chk=0;
        memset(A,-1,sizeof(A));
        int total=solve(n,m,k);
        if(chk==0) total=0;
       cout<<total<<endl;
    }
    return 0;
}
