#include <bits/stdc++.h>
#define ll long long int
#define  si(x)     scanf("%d",&x)
#define  slli(x)   scanf("%I64d",&x)
#define fil(i,a,b) for(ll i=a;i<b;i++)
#define pb push_back
#define mp make_pair
#define fastScan ios_base::sync_with_stdio(0); cin.tie(NULL);
#define foreach(v, c) for( typeof( (c).begin()) v = (c).begin();  v != (c).end(); ++v)
#define pii pair<int,int>
using namespace std;
char a[102];
char b[102];
int k,l1,l2;
int dp[102][102][102];
int chk=0;
int solve(int x ,int y ,int k)
{
    if(x==0||y==0||k==0)
    {
        if(k==0)
            chk++;
        return 0;
    }
    int ans=0;
    if(dp[x][y][k]!=-1)
        return dp[x][y][k];
    if(a[x-1]==b[y-1])
        dp[x][y][k]=max(max(solve(x-1,y,k),solve(x,y-1,k)),solve(x-1,y-1,k-1)+(int)a[x-1]);
    else
        dp[x][y][k]=max(solve(x,y-1,k),solve(x-1,y,k));
    return dp[x][y][k];
}
int main()
{
 int t;
 si(t);
 while(t--)
{
    memset(dp,-1,sizeof(dp));
    int l,m,k;
    scanf("%s",a);
    scanf("%s",b);
    l=strlen(a);
    m=strlen(b);
    si(k);
    int i,j,mx=0;
    int ns=solve(l,m,k);
    for(i=0;i<=l;i++)
    {
        for(j=0;j<=m;j++)
        {
            if(dp[i][j][k]>mx)
                mx=dp[i][j][k];
        }
    }
    if(chk==0)
        mx=0;
    printf("%d\n",mx);
    chk=0;
}
    return 0;
}
