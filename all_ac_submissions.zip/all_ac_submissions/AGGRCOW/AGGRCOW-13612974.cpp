#include <bits/stdc++.h>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
int c=0;
long int a[100000];
int f(int x,int n)
{
    int s=0,ct=1,lp=a[0],i;
    for(i=1;i<n;i++)
    {
        if(a[i]-lp>=x)
        {
            ct++;
            lp=a[i];
            if(ct==c)
                return 1;
        }

    }
     return 0;
}
int bs(int n)
{
    int l=0,r=a[n-1],mx=0;

    while(l<r)
    {
        int m=(l+r)/2;
        if(f(m,n)==1)
        {
            if(m>mx)
                mx=m;
            l=m+1;
        }
        else
            r=m;
    }
    return mx;
}
int main()
{
   int t,n;
   sfd(t);
   while(t--)
   {
       sfd(n);
       sfd(c);
       for(int i=0;i<n;i++)
        sfld(a[i]);
        sort(a,a+n);
       pfd(bs(n));
   }
    return 0;
}
