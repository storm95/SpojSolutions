#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[100005],n,m;
int func(int x)
{
    if(x==1)
        return 1;
    int last=a[0],c=1,i;
    for(i=1;i<n;i++)
    {
        if((a[i]-last)>=x)
        {
            c++;
            last=a[i];
            //printf("1\n");
        }
        if(c==m)
            return 1;
    }
    return 0;
}
int binsearch()
{
    int lbound=0,ubound=a[n-1],mid;
    while(lbound<=ubound)
    {
        mid=(lbound+ubound)/2;
        //printf("%d %d\n",mid,func(mid));
        if(func(mid)==0)
            ubound=mid-1;
        else if(func(mid)==1&&func(mid+1)==1)
            lbound=mid+1;
        else
            return mid;
    }
}
int main()
{
    int test;
    scanf("%d",&test);
    while(test--)
    {
        int i,res;
        scanf("%d %d",&n,&m);
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        sort(a,a+n);
        res=binsearch();
        printf("%d\n",res);
    }
    return 0;
}
