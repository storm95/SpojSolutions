// A function should be monotonic which is a must for binary search.
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<utility>
using namespace std;
int tc,N,C,arr[100009];
//.......FAST-IO..............
#define gc getchar_unlocked
#define pc putchar_unlocked
inline int inp()
{
    int n = 0, c = gc(), f = 1;
    while(c != '-' && (c < '0' || c > '9')) c = gc();
        if(c == '-')
        {
            f = -1;
            c = gc();
        }
    while(c >= '0' && c <= '9')
        n = (n<<3) + (n<<1) + c - '0', c = gc();
    return n * f;
}
void op(int n)
{
	if(n<0)
	{  n=-n;
	   pc('-');
	}
	int i=10;char output_buffer[11];
	output_buffer[10]='\n';
	do{output_buffer[--i]=(n%10)+'0';n/=10;}
	while(n);
	do{pc(output_buffer[i]);}
    while(++i<11);
}
//........END OF FAST-IO...........................
//Function which tells whether a minimum distance of x is possible or not between two barns
inline int fn(int pos)
{
	int cows = 1, lastpos = arr[0];
	for(int i=1;i<N;i++)
	{
		if(arr[i] - lastpos >= pos)
		{
		 ++cows;
		 if(cows == C)  return 1;
		 lastpos = arr[i];
	    }
	} 
	return 0;
}
inline int search()
{
	int start = 0,res = 0,end = arr[N-1];
	while(start<end)
	{
		int mid = (start+end)>>1;
		if(fn(mid) == 1)
			start = mid+1;
		else
			end  = mid;
	}
	return start-1;
}
inline void solve()
{
	//scanf("%d",&tc);
	tc = inp();
	while(tc--)
	{
		//scanf("%d %d",&N,&C);
		N = inp(); C = inp();
		for(int i=0;i<N;i++)  arr[i] = inp();
		//scanf("%d",&arr[i]);
		sort(arr,arr+N);
        op(search());
	}
}
int main()
{
	solve();
	return 0;
}