#include<bits/stdc++.h>
using namespace std;

bool f (int dist,int a[],int n,int totcow)
{
    int lastpos = a[0];
    int c = 1;
    for(int i = 1; i< n;i++)
    {
        if(a[i] - lastpos >= dist)
            {
                c++;
                lastpos = a[i];
                if(c == totcow)
                    return true;
            }
    }
return false;
}


int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
    int n , totcow;
    scanf("%d",&n);
    scanf("%d",&totcow);
    int a[n];
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
    sort(a,a+n);
    int beg = a[0] ;
    int last = a[n-1];
    int ans = 0;
    while(beg <= last)
    {
        int mid = (beg+last)/2;
     ///   cout<<mid<<" ";
        if(f(mid,a,n,totcow) == true)
            {
             ans = mid ;
             beg = mid+1;
            }
        else
            last = mid-1;
    }
    printf("%d\n",ans);
    }
    return 0;
}
