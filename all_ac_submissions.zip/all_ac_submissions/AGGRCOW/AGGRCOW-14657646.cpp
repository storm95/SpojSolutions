#include<bits/stdc++.h>
#define ll long long 

using namespace std;

ll n, c, arr[200000];

bool possible(ll counting, ll max_dis)
{
	ll i, j, dis;
	dis= arr[0];
	for(i=0;i<n;++i)
	{
		if(dis<= arr[i])
		{
			dis= arr[i]+ max_dis;
			--counting;
		}
	}
	
	//cout<<"mid= "<<max_dis<<"   counting= "<<counting<<"\n";
	
	if(counting<=0)
	return true;
	return false;
}

int main()
{
	ll t, i, j, k, a, b, start, stop, mid;
	cin>>t;
	while(t--)
	{
		cin>>n>>c;	
		
		for(i=0;i<n;++i)
		cin>>arr[i];
		
		sort(arr, arr+n);
		
		start= 1; stop= 1e9;
		while(start<stop)
		{
			mid= (start+ stop+ 1)>>1;
			if(possible(c, mid))
			{
				start= mid;
			}
			else
				stop= mid- 1;
		}
		
		cout<<start<<"\n";
	}	
	
	return 0;
}