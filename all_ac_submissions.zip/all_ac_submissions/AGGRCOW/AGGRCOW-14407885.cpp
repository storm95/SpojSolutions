#include<bits/stdc++.h>
using namespace std;
int x[100010];
int n,c;
bool can(int dis)
{
	int on=x[0];
	int cnt=1;
	int ind=0;
	while((ind=upper_bound(x,x+n,on+dis-1)-x)<n)
	{
		on=x[ind];
		++cnt;
	}
	return cnt>=c;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&c);
		for(int i=0;i<n;++i)
			scanf("%d",&x[i]);
		sort(x,x+n);
		int lo=1,high=1000000000;
		int mid=(lo+high)>>1;
		while((lo+1)<high)
		{
			if(can(mid))
				lo=mid;
			else high=mid;
			mid=(lo+high)>>1;
		}
		int max_dis;
		if(can(high))
			max_dis=high;
		else max_dis=lo;
		printf("%d\n",max_dis );
	}
	return 0;
}