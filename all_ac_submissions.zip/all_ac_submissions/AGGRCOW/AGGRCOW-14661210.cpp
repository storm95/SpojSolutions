#include<bits/stdc++.h>
using namespace std;


long long  cow,n;

long long  put(long long  mid , long long  arr[])
{
    long long  kount = 1;
    long long  c = 1;
    long long  visited = arr[0];

    for(long long  i=1;i<n;i++)
    {
        if(arr[i] -  visited >=mid)
            {
                c++;
                visited = arr[i];


        if(c == cow )
            return 1;
            }
    }
    return 0;
}


long long  bin(long long  left,long long  right,long long  arr[])
{
    long long  mid;

    while(left<right)
    {
        mid = (left+right)/2;

        if(put(mid,arr) == 1)
            left = mid+1;
        else right = mid;
    }
    return left;
}


int  main()
{
    long long  tc,arr[100021];

    scanf("%lld",&tc);

    while(tc--)
    {
        cow = 0;
        scanf("%lld %lld",&n,&cow);
        for(long long  i=0;i<n;i++)
        {
            scanf("%lld",&arr[i]);
        }

        sort(arr,arr+n);

        long long  ans = bin(0,arr[n-1],arr);
        ans--;
        printf("%lld\n",ans);
    }
}
