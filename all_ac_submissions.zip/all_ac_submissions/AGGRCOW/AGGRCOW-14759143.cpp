#include<bits/stdc++.h>
#define ll long long int
using namespace std;
int c,n;
int pos[100001];
bool p(int x)
{
    int pc=1,st=pos[0];
    for(int i=0;i<n;i++)
    {
        if(pos[i]-st>=x)
        {
            if(++pc==c) return true;
            st=pos[i];
        }
    }
    return false;
}
int solve(int l,int h)
{
    while(h-l>1)
    {
        int mid=l+(h-l)/2;
        if(p(mid)) l=mid;
        else h=mid;
    }
    return l;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&c);
        for(int i=0;i<n;i++) scanf("%d",&pos[i]);
        sort(pos,pos+n);
        int l=INT_MAX;
        for(int i=0;i<n-1;i++) l=min(l,pos[i+1]-pos[i]);
        printf("%d\n",solve(l,pos[n-1]-pos[0]));
    }
return 0;
}
