#include<cstdio>
#include<iostream>
#include<set>
#include<climits>
using namespace std;
set<int> S;
set<int> :: iterator p;
int c;
int greedy(int x)
{
	if(x==0)
	return c;
	int f = *S.begin()+x;
	int c = 1,k;
//	p = S.begin();
	while( ( p=S.lower_bound(f) )!=S.end())
	{	
		++c;f=*p+x;
	}
	return c;
}
int main()
{
	int t,n,m,i,j,k;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&c);
		S.clear();
		for(i=0;i<n;++i)
		{
			scanf("%d",&j);S.insert(j);
		}
		int n = 1000000000,m=0;
		int flag=0;
		int mid = (m+n)/2;
		while(m<=n)
		{
			//cout<<m<<" "<<mid<<" "<<n<<"\n";
//			scanf("%d",&k);
			j=greedy(mid);
//			cout<<j<<"\n";
			if(j>=c)
			{
				flag=1;
				m=mid+1;
			}
//			else if(j>c)
//			{
//				 dis+= (dis/2!=0?dis/2:1);
//			}
			else if(j<c)
			{
	//			if(flag) break;
				n=mid-1;
			}
			mid = (m+n)/2;
		}
		printf("%d\n",n);
	}
	return 0;
}

