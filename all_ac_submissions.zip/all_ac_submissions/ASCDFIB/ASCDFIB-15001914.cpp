#include<bits/stdc++.h>
using namespace std;
#define MOD 100000
#define ll long long
#define maxArrlen 2000001
#define Clen 100005
ll A[maxArrlen];
ll B[maxArrlen];
ll cnt[Clen];
ll aux[maxArrlen];
void c_sort(int k)
{
	memset(cnt,0,sizeof(cnt));
	for(int i=0;i<k;++i)
		++cnt[B[i]+1];
	for(int i=1;i<Clen;++i)
	{
		cnt[i] += cnt[i-1];
	}
	for(int i=0;i<k;++i)
	{
		aux[ cnt[B[i]]++ ] = B[i];
	}
}
int main()
{
	A[1]=0;
	A[2]=1;
	for(int i=3;i<maxArrlen;++i)
	{
		A[i] = A[i-1]+A[i-2];
		if(A[i]>=MOD)
			A[i]-=MOD;
	}
	int t,l,r,tc=0;
	scanf("%d",&t);
	while(t--)
	{
		++tc;
		scanf("%d%d",&l,&r);
		r+=l;
		int k=0;
		for(int i=l;i<=r;++i)
		{
			B[k] = A[i];
			++k;
		}
		c_sort(k);
		printf("Case %d: ",tc);
		if(k>100)
			k=100;
		for(int i=0;i<k;++i)
		{
			printf("%lld ",aux[i]);
		}
		printf("\n");
	}
	return 0;
}