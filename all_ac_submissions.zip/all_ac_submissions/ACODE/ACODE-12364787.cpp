#include<cstdio>
#include<cstring>
char s[6000];
int main()
{
	long long a,b,c;
	int i,j,k,n,x;
	while(scanf("%s",s)!=EOF&&s[0]!='0')
	{
		n=strlen(s);
		a=b=1;
		for(i=1;i<n;++i)
		{
			x=(s[i]-'0')+(s[i-1]-'0')*10;
			c=0;
			if(x<27&&x>9)
			c+=a;
			if(s[i]!='0')
			c+=b;
			a=b;
			b=c;
		}
		printf("%lld\n",b);
	}
	return 0;
}