#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    long long int dp[5005]={0};
    int i;
    char a[5005];
    sfs(a);

    while(a[0]!='0')
    {
        dp[0]=1;
        for(i=1;i<strlen(a);i++)
        {
            if(a[i]=='0')
            {
                 if(i==1)
                    dp[i]=1;
                else
                  dp[i]=dp[i-2];
                i++;
                dp[i]=dp[i-1];
            }
            else if((a[i-1]-'0')*10+(a[i]-'0')<=26)
               {
                   if(i==1)
                    dp[i]=2;
                   else
                   dp[i]=dp[i-1]+dp[i-2];
                }
               else
                dp[i]=dp[i-1];
        }

        cout<<dp[i-1]<<endl;
        sfs(a);
    }
    return 0;
}
