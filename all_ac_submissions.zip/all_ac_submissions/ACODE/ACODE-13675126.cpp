#include<iostream>
#include<cstdio>
#include<cstring>
#define lli long long int
using namespace std;
int main()
{
    string s;
    while(cin>>s)
    {
    	if(s=="0")
    		break;
        lli l=s.length();
        lli arr[l],temp1=0,temp2=0;
        //fill(arr,arr+l,0);
        memset(arr,0,sizeof(arr));
 
        arr[0]=1;
 
        for(lli i=1; i<l; i++)
        {
            temp1=s[i]-'0';
            temp2=10*(s[i-1]-'0');
            temp2+=temp1;
            //cout<<temp1<<" "<<temp2<<endl;
            if(temp1>=1 && temp1<=9)    // >=1 and not >=0
            {
                arr[i]=arr[i-1];
            }
            if(temp2>9 && temp2<=26)
            {
                if(i-2>=0)
                    arr[i]+=arr[i-2];
                else
                	arr[i]+=1; // new state  
            }
            //cout<<arr[i]<<endl;
        }
        cout<<arr[l-1]<<endl;
        //scanf(" %s",str);
    }
    return 0;
}
 