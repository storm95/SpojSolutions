#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;

int main()
{
    int a,b,c,d,p,q,r,s;
    float mx;
    sfd(a);
    sfd(b);
    sfd(c);
    sfd(d);
    sfd(p);
    sfd(q);
    sfd(r);
    sfd(s);
    while(a!=-1)
    {
        mx=max(max(ceil(1.0*a/p),ceil(1.0*b/q)),max(ceil(1.0*c/r),ceil(1.0*d/s)));
     a=mx*p-a;
     b=mx*q-b;
     c=mx*r-c;
     d=mx*s-d;
     cout<<a<<" "<<b<<" "<<c<<" "<<d<<endl;
    sfd(a);
    sfd(b);
    sfd(c);
    sfd(d);
    sfd(p);
    sfd(q);
    sfd(r);
    sfd(s);
    }
    return 0;
}
