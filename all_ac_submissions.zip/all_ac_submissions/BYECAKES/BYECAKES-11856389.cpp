#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int a,b,c,d,a1,b1,c1,d1,a2,b2,c2,d2,maz;
    while(1)
    {
        scanf("%d %d %d %d %d %d %d %d",&a,&b,&c,&d,&a1,&b1,&c1,&d1);
        if(a==-1 && b==-1 && c==-1 && d==-1 && a1==-1 && b1==-1 && c1==-1 && d==-1)
            break;
        a2=ceil((1.0*a)/a1);
        b2=ceil((1.0*b)/b1);
        c2=ceil((1.0*c)/c1);
        d2=ceil((1.0*d)/d1);
        maz=max(a2,b2);
        maz=max(maz,c2);
        maz=max(maz,d2);
        printf("%d %d %d %d\n",(a1*maz)-a,(b1*maz)-b,(c1*maz)-c,(d1*maz)-d);
    }
    return 0;
}

