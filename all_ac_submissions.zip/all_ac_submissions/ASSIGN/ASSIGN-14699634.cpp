#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
int a[21][21];
ll dp[1<<21];
ll ct;
int main()
{
    int t,n,i,j,ctb;
    sfd(t);
    while(t--)
   {
       sfd(n);
    for(i=0;i<n;i++)
      for(j=0;j<n;j++)
        sfd(a[i][j]);
    dp[0]=1;
    for(i=1;i<(1<<n);i++)
    {
        dp[i]=0;
        ctb=0;
        for(j=0;j<n;j++)
            if(i&(1<<j))
                ctb++;
        for(j=0;j<n;j++)
        {
            if(a[ctb-1][j]==1&&(i&(1<<j)))
                dp[i]+=dp[i-(1<<j)];
        }
    }

   cout << dp[(1 << n)-1] << endl;
   }
    return 0;
}
