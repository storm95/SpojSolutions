#include<bits/stdc++.h>
#define gc getchar_unlocked
using namespace std;

inline int inp()
{
    int n = 0, c = gc();
    int f = 1;
    while(c != '-' && (c < '0' || c > '9')) c = gc();
        if(c == '-')
        {
            f = -1;
            c = gc();
        }
    while(c >= '0' && c <= '9')
        n = (n<<3) + (n<<1) + c - '0', c = gc();
    return n * f;
}

int adjmat[20][20],size;
long long memo[1<<20];

int main()
{
   memset(adjmat,0,sizeof(adjmat));
   int nT;
   nT = inp();
   while (nT-- && (size=inp())) {
      memset(adjmat,0,sizeof(adjmat));
      memset(memo,0,sizeof(memo));
      for (int i = 0; i < size; i++) {
         for (int j = 0; j < size; j++) {
            int val;  val = inp();
            adjmat[i][j] = val;
         }
      }
      memo[(1<<size)-1] = 1;
      for (int j = (1 << size)-1; j >= 0; j--) {
         int idx = __builtin_popcount(j);
         for (int k = 0; k < size; k++) {
            if (adjmat[idx][k] == 0 || (j & (1 << k))) continue;
            memo[j] += memo[j | (1 << k)];
         }
      }
      printf("%lld\n",memo[0]);
   }
   return 0;
}

