#include<cstdio>
unsigned long long gcd(unsigned long long int a,unsigned long long int b)
{
    if(b==0)
        return a;
    else return gcd(b,a%b);
}
int main()
{
    long long tc,a,b,lcm,g;
   scanf("%llu %llu",&a,&b);
   while(a && b)
   {
       if(a!=b)
       {
        lcm=(a*b);
        g=gcd(a,b);
        lcm=lcm/g;
        lcm=lcm/a * lcm/b;
        printf("%llu\n",lcm);
       }
       else printf("1\n");
       scanf("%llu %llu",&a,&b);
   }
    return 0;
}
