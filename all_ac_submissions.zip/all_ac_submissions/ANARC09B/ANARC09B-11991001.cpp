#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<climits>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
long long int gcd(long long int n,long long int m)
{
    if(m==0)
        return n;
    return gcd(m,n%m);
}
long long int lcm(long long int n,long long int m)
{
    return ((n*m)/gcd(n,m));
}
int main()
{
    long long int t,i,j,n,m,k;
    while(1)
    {
        scanf("%lld %lld",&n,&m);
        if(n==0 && m==0)
            break;
        k=lcm(n,m);
        printf("%lld\n",((k/n)*(k/m)));
    }
    return 0;
}

