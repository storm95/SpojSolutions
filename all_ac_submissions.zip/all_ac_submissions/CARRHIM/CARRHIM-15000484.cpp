#include<stdio.h>
int main()
{
 unsigned int W,B,R,SUMW=0,SUMB=0,R1=0,R2=0,first,count=1;
 char TEAM[10],ch;
 while(scanf("%s",TEAM)!=EOF)
 {
  ch=TEAM[0];
  if(ch!=35)
  {
   scanf("%u%u%u",&W,&B,&R);
   SUMB+=B;
   SUMW+=W;
   if(ch==65||ch==67)
   {
    if(count)
     first=1;
    if(R!=0)
     R1=5;
   }
   else
   {
    if(count)
     first=2;
    if(R!=0)
     R2=5;
   }
   count=0;
  }
  else
  {
   if((SUMW==9||SUMB==9)&&(R1!=0||R2!=0))
   {
    if(SUMW==9)
    {
     if(first==1)
      printf("Team-1 win and the point is %u.\n",9- SUMB+R1);
     else
      printf("Team-2 win and the point is %u.\n",9- SUMB+R2);
    }
    else
    {
     if(first==1)
      printf("Team-2 win and the point is %u.\n",9- SUMW+R2);
     else
      printf("Team-1 win and the point is %u.\n",9- SUMW+R1);
    }
   }
   else
    printf("Incomplete game.\n");
   SUMW=0;
   SUMB=0;
   R2=0;
   R1=0;
   count=1;
  }
 }
 return 0;
}
