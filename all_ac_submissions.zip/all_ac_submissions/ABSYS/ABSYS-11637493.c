#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        printf("\n");
    int l,i,j=0,val1,val2,val3;
    char string[200],a[200],b[200],c[200],x[200],y[200];
    scanf("%s",a);
    scanf("%s",x);
    scanf("%s",b);
    scanf("%s",y);
    scanf("%s",c);
    val1=atoi(a);
    val2=atoi(b);
    val3=atoi(c);
    //printf("%d\t%d\t%d\n",val1,val2,val3);
    l=strlen(a);
    for(i=0;i<l;i++)
    {
        if(a[i]=='m'&&a[i+1]=='a'&&a[i+2]=='c'&&a[i+3]=='h'&&a[i+4]=='u'&&a[i+5]=='l'&&a[i+6]=='a')
            val1=val3-val2;
    }
    l=strlen(b);
    for(i=0;i<l;i++)
    {
        if(b[i]=='m'&&b[i+1]=='a'&&b[i+2]=='c'&&b[i+3]=='h'&&b[i+4]=='u'&&b[i+5]=='l'&&b[i+6]=='a')
            val2=val3-val1;
    }
    l=strlen(c);
    for(i=0;i<l;i++)
    {
        if(c[i]=='m'&&c[i+1]=='a'&&c[i+2]=='c'&&c[i+3]=='h'&&c[i+4]=='u'&&c[i+5]=='l'&&c[i+6]=='a')
               val3=val1+val2;
    }
    printf("%d + %d = %d\n",val1,val2,val3);
}
return 0;
}
