#include <iostream>
#include <cstring>
#include <string>
#include <math.h>
#include <cstdio>

using namespace std;
int cast(char *a)
{
    int i=0,s=0,t=strlen(a);
    s=0;


       while(i<t)
    {
       s=s*10+(a[i]-48);

        i++;

    }

    return s;


    cout<<s<<endl;
}

int main()
{
    int t,l,k,i,m,x,y,z;
    string  g;
     char a[1000],b[1000],c[1000],h[6],v[1000];
    cin>>t;
    /*fflush(stdin);
        scanf("%[^\n]s",h);*/
         fgets(h,6,stdin);
         fgets(h,6,stdin);
    while(t--)
    {
        // fflush(stdin);
        // fgets(h,6,stdin);
     scanf("%[^\n]s",v);
     fgets(h,6,stdin);
        //fflush(stdin);
       //  if(t!=0)
        fgets(h,6,stdin);
           //scanf("%[^\n\n]s",h);


       //cout<<v;
        l=strlen(v);
        i=0;

            k=0;
            while(v[i]!=' ')
            {
                // cout<<v[i];
                a[k]=v[i];
                if(v[i]=='m')
                    m=1;
                k++;
                i++;
            }
            a[k]='\0';
            i+=3;
            k=0;
             while(v[i]!=' ')
            {
               // cout<<v[i];
                b[k]=v[i];
                if(v[i]=='m')
                    m=2;
                k++;
                i++;
            }
            b[k]='\0';
            i+=3;
            k=0;
             while(i<l)
            {
                //cout<<v[i];
                c[k]=v[i];
                if(v[i]=='m')
                    m=3;
                k++;
                i++;
            }
          c[k]='\0';

          switch(m)
           {
               case 1:  y=cast(b);
                        z=cast(c);
                        x=z-y;
                        break;
                case 2: x=cast(a);
                        z=cast(c);
                        y=z-x;
                        break;
                 case 3: x=cast(a);
                        y=cast(b);
                        z=x+y;
                        break;

           }
           //cout<<m<<endl;
          cout<<x<<" "<<"+"<<" "<<y<<" "<<"="<<" "<<z<<endl;

    }
        return 0;
}
