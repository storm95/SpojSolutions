#include<bits/stdc++.h>
using namespace std;

int main()
{
    int tc;

    scanf("%d",&tc);

    while(tc--)
    {
        char a[10002],b[10002],c[10001],d[5],e[5];

        int aa=0,bb=0,cc=0;
        int sum =0;

        scanf("%s%s%s%s%s",a,d,b,e,c);

        for(int i=0;i<strlen(a);i++)
        {
            if(a[i]=='m')
            {
                aa=1;
                break;
            }
        }

        for(int i=0;i<strlen(b);i++)
        {
            if(b[i]=='m')
            {
                bb=1;
                break;
            }
        }

        for(int i=0;i<strlen(c);i++)
        {
            if(c[i]=='m')
            {
                cc=1;
                break;
            }
        }

        int t1=0,t2=0,t3=0;
        if(cc==1)
        {
            t1=atoi(a);
            t2=atoi(b);
            sum = t1+t2;
            cout<<a<<" "<<"+"<<" "<<b<<" "<<"="<<" "<<sum<<endl;
        }

        else if(aa==1)
        {
            t3 = atoi(c);
            t2 = atoi(b);
            sum = t3-t2;
           cout<<sum<<" "<<"+"<<" "<<b<<" "<<"="<<" "<<c<<endl;
        }

        else if(bb==1)
        {
            t3 = atoi(c);
            t2 = atoi(a);
            sum = t3-t2;
           cout<<a<<" "<<"+"<<" "<<sum<<" "<<"="<<" "<<c<<endl;
        }
    }
}
