#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <utility>
#include <cassert>
#include <string>
#include <cmath>
#include <cstdlib>
#include <algorithm>

using namespace std;

typedef long long LL;
typedef vector < int > vi;
typedef vector < vi > vvi;

#define pb push_back
#define mp make_pair

const int MAXN = (int)(1e5 + 9);
const int MOD  = (int)(1e9 + 7);

long double p;
int u,v,n,m;
long double dp[109][109];

int main () {
     
     while((scanf("%d",&m) == 1) && (m) ) {
         scanf("%d",&n);
         memset(dp,0,sizeof(dp));
         
         for(int i = 1;i <= n;++i) {
           scanf("%d %d %Lf",&u,&v,&p);
           dp[u][v] = dp[v][u] = p/100.00; 
         }
         
         /*
         for(int i = 1;i <= n;++i) {
			 for(int j = 1;j <= n;++j) {
				 cout << dp[i][j] << " ";
			 }
			 cout << "\n";
		 } */
         
         for(int k = 1;k <= m;++k) {
          for(int i = 1;i <= m;++i) {
            for(int j = 1;j <= m;++j) {
			  //cout << dp[i][k] * dp[k][j] << " ";
              dp[i][j] = max(dp[i][j],dp[i][k] * dp[k][j]);
              //cout << dp[i][j] << "\n";
            }
          }
         }

         printf("%.6Lf percent\n",dp[1][m] * 100.00);
     }  
  return 0;
}
