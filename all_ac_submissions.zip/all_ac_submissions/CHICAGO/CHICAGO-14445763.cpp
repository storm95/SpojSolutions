#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
 double dp[105][105],p;
int main()
{
    int n,i,k,j,m;

    sfd(n);
    while(n!=0)
    {
        sfd(m);
        for(i=0;i<=n;i++)
            for(j=0;j<=n;j++)
        {
            //if(i==j)
                dp[i][j]=0.0;
            //else
              //  dp[i][j]=100;
        }
        while(m--)
        {
            sfd(i);
            sfd(j);
            cin>>p;
            p/=100.0;
            dp[i][j]=p;
            dp[j][i]=p;
        }
        for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
         for(j=1;j<=n;j++)
          {
              if(i==j||j==k||i==k)continue;
              dp[i][j]=max(dp[i][j],dp[i][k]*dp[k][j]);
          }
        /*for(i=1;i<=n;i++){
         for(j=1;j<=n;j++)
         {
             cout<<dp[i][j]*100<<" ";
         }
         cout<<endl;
        }*/
        cout<<fixed<<setprecision(6)<<dp[1][n]*100<<" percent"<<endl;
        sfd(n);
    }
    return 0;
}
