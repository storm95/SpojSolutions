#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int t,i,vertex,stop,j,a,b,c,n,k,noc,nop;
    double pro,prob;
    double minarr[101];
    //scanf("%d %d",&noc,&nop);
    vector<vector<pair<double,int > > > v(101);
    pair<double,int > p,pai;
    while(1)
    {
        scanf("%d",&noc);
        if(noc==0)
            break;
        scanf("%d",&nop);
        while(nop--)
        {
            scanf("%d %d %lf",&a,&b,&pro);
            v[a].push_back(pair<double,int> (pro/100.0,b));
            v[b].push_back(pair<double,int> (pro/100.0,a));
        }
        for(i=2;i<=noc;i++)
            minarr[i]=0.0;
        minarr[1]=1.0;
        priority_queue<pair<double,int> > q;
        q.push(pair<double,int> (1.0,1));
        while(!q.empty())
        {
            p=q.top();
            q.pop();
            prob=p.first;vertex=p.second;
            if(vertex==noc)
                break;
            if(prob>=minarr[vertex])
            {
                stop=v[vertex].size();
                for(i=0;i<stop;i++)
                {
                    pai=v[vertex][i];
                    if(prob*pai.first>minarr[pai.second])
                    {
                        minarr[pai.second]=prob*pai.first;
                        q.push(pair<double,int> (minarr[pai.second],pai.second));
                    }
                }
            }
        }
        printf("%.6lf percent\n",100*minarr[noc]);
        for(i=1;i<=noc;i++)
            v[i].clear();

    }
    return 0;
}







