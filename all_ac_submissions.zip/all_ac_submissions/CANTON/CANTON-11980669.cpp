//count on cantor
#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
        int t;
        int n,sq,x,y;
        scanf("%d",&t);
        while(t--)
        {
                scanf("%d",&n);
                sq=(sqrt(1+8*n)-1)/2;
                if(2*n==sq*(sq+1))
                {
                        x=1;
                        y=sq;
                }
                else
                {
                 x=n-(sq*(sq+1))/2;
                y=sq+2-x;
                }
                if(sq%2==0)
                        printf("TERM %d IS %d/%d\n",n,y,x);
                else
                        printf("TERM %d IS %d/%d\n",n,x,y);
        }
        return 0;
}
