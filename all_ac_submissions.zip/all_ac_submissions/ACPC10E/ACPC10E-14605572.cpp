#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
ll pw(ll n)
{
    ll m=1;
    while(m<n)
      {
          m=m<<1;
      }
    return m;
}
int main()
{
    ll g,t,a,d,n,m,ans,ex;
    sflld(g);
    sflld(t);
    sflld(a);
    sflld(d);
    while(g>0)
    {
      ans=g*(t*(t-1)/2);
      n=g*a+d;
      //cout<<"as";
      m=pw(n);
      ex=m-n;
      n+=ex;
      ans+=n-1;
      printf("%lld*%lld/%lld+%lld=%lld+%lld\n", g,a,t,d,ans,ex);
        sflld(g);
        sflld(t);
        sflld(a);
        sflld(d);
    }
    return 0;
}
