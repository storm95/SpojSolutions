#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    long long int t,i,j,a,b,c,n,m,arr1[100000],arr2[100000];
    long long int sum;
    while(1)
    {
        sum=0;
        scanf("%lld",&t);
        if(t==0)
            break;
        for(i=0;i<t;i++)
            scanf("%lld",&arr1[i]);
        for(i=0;i<t;i++)
            scanf("%lld",&arr2[i]);
        sort(arr1,arr1+t);
        sort(arr2,arr2+t);
        for(i=0;i<t;i++)
        {
            sum+=arr1[i]*arr2[t-1-i];
        }
        printf("%lld\n",sum);
    }




    return 0;
}

