#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int n;
	while(scanf("%lld",&n))
	{
		if(n == 0) return 0;
		vector<long long int> cls(n),price(n);
		for(int i=0;i<n;i++)  scanf("%lld",&cls[i]);
		for(int i=0;i<n;i++)  scanf("%lld",&price[i]);
		sort(cls.begin(),cls.end());
		reverse(cls.begin(),cls.end());
		sort(price.begin(),price.end());
		long long int sum = 0;
		for(int i=0;i<n;i++)
		sum = sum + (long long)(cls[i]*price[i]);
		printf("%lld\n",sum);
	}
}