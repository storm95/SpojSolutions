#include<bits/stdc++.h>
#define gc getchar_unlocked
using namespace std;
inline long long int inp()
{
    long long int n = 0, c = gc(), f = 1;
    while(c != '-' && (c < '0' || c > '9')) c = gc();
        if(c == '-')
        {
            f = -1;
            c = gc();
        }
    while(c >= '0' && c <= '9')
        n = (n<<3) + (n<<1) + c - '0', c = gc();
    return n * f;
}
int main()
{
	long long int n;
	while(n = inp())
	{
		if(n == 0) return 0;
		vector<long long int> cls(n),price(n);
		for(int i=0;i<n;i++)  cls[i] = inp();
		for(int i=0;i<n;i++)  price[i] = inp();
		sort(cls.begin(),cls.end());
		reverse(cls.begin(),cls.end());
		sort(price.begin(),price.end());
		long long int sum = 0;
		for(int i=0;i<n;i++)
		sum = sum + (long long)(cls[i]*price[i]);
		printf("%lld\n",sum);
	}
}