#include<bits/stdc++.h>
using namespace std;
long long int arr[10000];
int main()
{
	int n;
	while(scanf("%d",&n)!=EOF&&n!=-1)
	{
		long long int sum = 0;
		for(int i = 0;i<n;++i)
		{
			scanf("%lld",&arr[i]);
			sum += arr[i];
		}
		if(sum%n!=0)
		{
			printf("-1\n");
			continue;
		}
		long long carry = 0;
		long long ans = 0;
		sum /= n;
		for(int i = 0;i<n;++i)
		{
			carry = (arr[i]+carry) - sum;
			ans = max( abs(carry), ans);
		}
		printf("%lld\n",ans );
	}
	return 0;
}