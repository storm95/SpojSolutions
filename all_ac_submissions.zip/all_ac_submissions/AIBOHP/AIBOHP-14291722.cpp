#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define si(a) scanf("%d",&a)
#define sl(a) scanf("%ld",&a)
#define sll(a) scanf("%lld",&a)
using namespace std;
int dp[6104][6104];
char s[6104];
int solve(int l,int h)
{
    if(h==l) return 0;
    if(dp[l][h]) return dp[l][h];
    if(s[l]==s[h])
    {
        if(h-l==1) return 0;
        dp[l][h]=solve(l+1,h-1);
        return dp[l][h];
    }
    else
    {
        if(h-l==1) return 1;
        dp[l][h]=min(solve(l+1,h),solve(l,h-1))+1;
        return dp[l][h];
    }
}
int main()
{
    int t;
    si(t);
    while(t--)
    {
        scanf("%s",s);
        int l=strlen(s);
        memset(dp,0,sizeof(dp));
        printf("%d\n",solve(0,l-1));
    }
    return 0;
}
