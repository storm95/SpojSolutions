#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int ct[2][6109],m[3];
int lcs(char str[],char rstr[],int len)
{
    int i,j,k,max,a,b,c,l,p;
    for(i=0;i<=len;i++)
    {
        ct[0][i]=0;
    }
    ct[1][0]=0;
    l=0;
    for(i=1;i<=len;i++)
    {
        l=(i-1)%2;
        p=i%2;
        for(j=1;j<=len;j++)
        {
            m[0]=ct[l][j-1];
            if(str[i-1]==rstr[j-1])
                ++m[0];
            m[1]=ct[l][j];
            m[2]=ct[p][j-1];
            max=m[0];
            for(k=0;k<3;k++)
            {
                if(max<m[k])
                    max=m[k];
            }
            ct[p][j]=max;
        }
    }
    return ct[p][len];
}
int main()
{
    int len,t,i,j,k,a,b,c;
    char str[6109],rstr[6109];
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s",&str);
        len=strlen(str);
        for(i=len-1;i>=0;i--)
            rstr[len-1-i]=str[i];
        k=lcs(str,rstr,len);
        printf("%d\n",len-k);
    }
    return 0;
}

