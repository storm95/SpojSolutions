#include<bits/stdc++.h>
using namespace std;
int main(){
        ios_base::sync_with_stdio(false);
	int test;
	for(scanf("%d",&test);test>0;test--){
		char str1[6110];
		char str2[6110];
		scanf("%s",str1);
		int l=strlen(str1);
		for(int i=0;i<l;i++) str2[i]=str1[l-i-1];
		int L[3][6110];
		int tmp=1;
		memset(L,0,sizeof L);
		for(int i=1;i<=l;++i){
			for(int j=1;j<=l;++j){
				if(str1[i-1]==str2[j-1]) L[tmp][j]=1+L[!tmp][j-1];
				else L[tmp][j]=max(L[tmp][j-1],L[!tmp][j]);
			}
			tmp=!tmp;
		}
		int ans=l-L[!tmp][l];
		printf("%d\n",ans);
	}
	return 0;
}
