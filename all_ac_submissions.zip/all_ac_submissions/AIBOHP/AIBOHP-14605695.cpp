#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
int dp[6105][6105];
int main()
{
    string a,ra;
    int t,i,j,l,rl;
    sfd(t);
    while(t--)
    {
        cin>>a;
        ra=a;
        reverse(ra.begin(),ra.end());
        memset(dp,0,sizeof(dp));
        l=rl=a.length();
        for(i=1;i<=l;i++)
        {
            for(j=1;j<=rl;j++)
            {
                if(a.at(i-1)==ra.at(j-1))
                    dp[i][j]=dp[i-1][j-1]+1;
                else
                    dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
            }
        }
        pfd(l-dp[l][rl]);
    }
    return 0;
}
