#include<bits/stdc++.h>
using namespace std;
int arr[6200][6200];
int main()
{
	char a[6200],b[6200];
	int i,j,k,len,t,ans,ab;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%s",a);
		len=strlen(a);
		for(i=0;i<len;++i)
		b[len-i-1]=a[i];
		for(i=0;i<=len;++i)
		arr[0][i]=arr[i][0]=0;
		for(i=1;i<=len;++i)
		for(j=1;j<=len;++j)
		{
			arr[i][j]=max(a[i-1]==b[j-1]?arr[i-1][j-1]+1:arr[i-1][j-1],max(arr[i-1][j],arr[i][j-1]));
	//		cout<<arr[i][j]<<" ";
		}
		cout<<len-arr[len][len]<<"\n";
		
	}
	return 0;
}
