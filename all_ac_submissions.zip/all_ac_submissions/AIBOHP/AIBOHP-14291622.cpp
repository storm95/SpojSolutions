#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define si(a) scanf("%d",&a)
#define sl(a) scanf("%ld",&a)
#define sll(a) scanf("%lld",&a)
using namespace std;
int dp[10000][10000];
char s[6104];
int solve(int l,int h)
{
    if(h==l) return 0;
    if(h-l==1)
    {
        if(s[l]==s[h]) return 0;
        return 1;
    }
    if(dp[l][h]) return dp[l][h];
    if(s[l]==s[h])
    {
        dp[l][h]=solve(l+1,h-1);
        return dp[l][h];
    }
    dp[l][h]=min(solve(l+1,h),solve(l,h-1))+1;
    return dp[l][h];
}
int main()
{
    int t;
    si(t);
    while(t--)
    {
        scanf("%s",s);
        int l=strlen(s);
        memset(dp,0,sizeof(dp));
        printf("%d\n",solve(0,l-1));
    }
    return 0;
}
