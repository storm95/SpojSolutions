#include<cstdio>
int main()
{
    int tc,n,m,c,d,e;
    scanf("%d",&tc);
    while(tc--)
    {
        c=0,d=0;
        scanf("%d %d",&n,&m);
        c=n-m;
        d=(m-1)/2;
        e=c&d;
        if(e==0)
            printf("1\n");
        else printf("0\n");
    }
    return 0;
}
