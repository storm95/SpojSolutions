#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,m;
        scanf("%d%d",&n,&m);
        int k=(m-1)>>1;
        int ans=((n-m)&k)==0;
        printf("%d\n",ans);
    }
    return 0;
}
