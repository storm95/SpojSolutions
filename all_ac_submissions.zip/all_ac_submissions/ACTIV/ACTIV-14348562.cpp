#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)


using namespace std;

int main()
{
    int i,j,n;
    sfd(n);
    while(n!=-1)
    {
        pair<int,int>p[100005];
       int v[100005];
       ll dp[100005];
        for(i=0;i<n;i++)
        {
             sfd(p[i].second);
            sfd(p[i].first);
        }
        sort(p,p+n);
        for(i=0;i<n;i++)
           {
             v[i]=p[i].first;
            // cout<<v[i]<<endl;
           }
        dp[0]=1;
        int k;
        for(i=1;i<n;i++)
        {
            dp[i]=dp[i-1]+1;
            dp[i]%=100000000;
            k=-1;
            int l=0,r=i-1,mid;

           while(l<=r&&l>=0&&r<n)
          {
             mid=(l+r)/2;
             if(v[mid]<=p[i].second)
             {
                k=mid;
                l=mid+1;
             }
            else
               r=mid-1;
          }
            if(k>=0)
              {
               dp[i]+=dp[k];
               dp[i]%=100000000;
            }
        }
        k=dp[n-1];
        char a[9];
        i=7;
        while(k&&i>=0)
        {
            a[i]=k%10+'0';
            k/=10;
            i--;
        }
            while(i>=0)
            {
                a[i]='0';
                i--;
            }
        a[8]='\0';
        cout<<a<<endl;
        sfd(n);
    }
    return 0;
}
