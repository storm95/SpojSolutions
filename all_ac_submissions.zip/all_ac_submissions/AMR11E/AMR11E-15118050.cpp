#include<bits/stdc++.h>
#define MAX 1000001
using namespace std;
int prime[MAX];
vector<int> dp;
void solve()
{
    for(int i=2;i<=1000;i++)
        if(prime[i]==0)
        {
            for(int j=i;j<MAX;j+=i)
            {
                prime[j]+=1;
            }
        }
    for(int i=0;i<MAX;i++)
    {
        if(prime[i]>=3)
            dp.push_back(i);
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    solve();
    for(int i=1;i<=t;i++)
    {
        int n;
        scanf("%d",&n);
        printf("%d\n",dp[n-1]);
    }
    return 0;
}
