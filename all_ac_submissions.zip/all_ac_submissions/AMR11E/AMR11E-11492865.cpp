#include <iostream>
#include <cstdio>

using namespace std;
bool getprime(int n)
{
    int cnt =0;
    for(int i =2; i <=n; i++)
    {
	if( n % i ==0)
	{
	    cnt++;
	    while( n%i ==0 )
	    {
		n /= i;
	    }
	}
    }
    return cnt >= 3;
	
}
int ans[1111];
int main()
{
    
    int p = 1;
    for(int i =30; i<=30000;i++)
    {
	if(p > 1000)break;
	if(getprime(i))
	{
	    ans[p++] = i;
	}
    }
    int n;
    scanf("%d",&n);
    while(n--)
    {
	int m;
	scanf("%d",&m);
	printf("%d\n",ans[m]);
    }
}