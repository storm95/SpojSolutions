#include <bits/stdc++.h>
using namespace std;

const int MAXN = 185;
const int INF  = 185 * 185 * 185;

typedef pair<int,int> pii;

int tc,N,M;
int graph[MAXN][MAXN];
int dist[MAXN][MAXN];

const int dx[] = {1,-1,0,0};
const int dy[] = {0,0,1,-1};

inline bool ok(int x,int y){
	return (x >= 1 && x <= N && y >= 1 && y <= M);
}

int main (){
	scanf("%d",&tc);
	while(tc--){
		queue < pii > Q;
		scanf("%d %d",&N,&M);
		for(int i = 1;i <= N;++i){
			for(int j = 1;j <= M;++j){
				scanf("%1d",&graph[i][j]);
				dist[i][j] = INF;

				if(graph[i][j] == 1){
					dist[i][j] = 0;
					Q.push(make_pair(i,j));
				}
			}
		}

		while(!Q.empty()){
			pii cur = Q.front();
			Q.pop();
			for(int i = 0;i < 4;++i){
				pii next;
				next.first = cur.first + dx[i];
				next.second = cur.second + dy[i];
				if(ok(next.first,next.second)){
					if(dist[next.first][next.second] > 1 + dist[cur.first][cur.second]){
						dist[next.first][next.second] = 1 + dist[cur.first][cur.second];
						Q.push(next);
					}
				}
			}
		}

		for(int i = 1;i <= N;++i){
			for(int j = 1;j <= M;++j){
				printf("%d ",dist[i][j]);
			}
			printf("\n");
		}
	}
	return 0;
}
