#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
queue<int>x,y;
int main()
{
    int t,n,m,i,j,v[185][185],dp[185][185],k,l;
    sfd(t);
    while(t--)
    {
        string s;
        sfd(n);
        sfd(m);
        for(i=0;i<n;i++)
        {
            cin>>s;
            for(j=0;j<m;j++)
            {
                dp[i][j]==0;
                if(s.at(j)=='1')
                {
                    v[i][j]=0;
                    x.push(i);
                    y.push(j);
                }
                else
                {
                    v[i][j]=1000000;
                }

            }
        }
        while(!x.empty())
        {
            i=x.front();
            j=y.front();
            x.pop();
            y.pop();
             int dx[4]={0,-1,0,1};
             int dy[4]={-1,0,1,0};
           for(int p=0;p<4;p++)
            {
                int nx=i+dx[p],ny=j+dy[p];

                if(nx>=0&&nx<n&&ny>=0&&ny<m)
                {
                        if(v[nx][ny]>v[i][j]+1)
                        {
                          x.push(nx);
                          y.push(ny);
                          v[nx][ny]=v[i][j]+1;
                        }
                }
            }

        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                printf("%d ",v[i][j]);
            }
            printf("\n");
        }

    }

    return 0;
}
