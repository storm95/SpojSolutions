#include<cstdio>
#include<queue>
#include<iostream>
#include<algorithm>
using namespace std;
int a[200][200];
int vis[200][200];
#define inf 1000000
int main()
{
	int dx[]={1,0,-1,0};
	int dy[]={0,1,0,-1};
	int n,t,i,j,k,l,m;
	queue<pair<int,int> > s;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		for(i=0;i<n;++i)
		for(j=0;j<m;++j)
		{
			a[i][j]=inf;vis[i][j]=0;
			scanf("%1d",&k);
			if(k)
			{
				s.push(pair<int,int> (i,j));vis[i][j]=1;a[i][j]=0;
			}
		}
		while(!s.empty())
		{
			pair<int,int> p  = s.front();
			s.pop();
			for(i=0;i<4;++i)
			{
				int x = p.first+dx[i],y = p.second+dy[i];
				if(x>=0&&y>=0&&x<n&&y<m)
				{
					if(vis[x][y]==0&&a[x][y]!=0)
					{
						vis[x][y]=1;
						a[x][y]=a[p.first][p.second]+1;s.push(pair<int,int>(x,y));
						
					}
				}
			}			
		}
		for(i=0;i<n;++i)
		{printf("\n");
		for(j=0;j<m;++j)
		printf("%d ",a[i][j]);
		}
		

	}
	return 0;
}
	

