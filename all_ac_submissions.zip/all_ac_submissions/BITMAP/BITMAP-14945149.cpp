#include<bits/stdc++.h>
#define mp make_pair
using namespace std;
typedef pair<int ,int> pr;
static int fix[][2]={{1,0},{0,1},{-1,0},{0,-1}};
char s[185][185];
int n,m;
int ans[185][185];
void solve(priority_queue< pair<int ,pr> > que)
{
    while(!que.empty())
    {
        int cost=-(que.top()).first;
        int x=que.top().second.first;
        int y=que.top().second.second;
        que.pop();
        for(int i=0;i<4;i++)
        {
            int a=x+fix[i][0];
            int b=y+fix[i][1];
            if(a>=0 && a<n && b>=0 && b<m)
            {
                if(cost+1<ans[a][b])
                {
                    ans[a][b]=cost+1;
                    que.push(mp(-(cost+1),mp(a,b)));
                }
            }
        }
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        for(int i=0;i<n;i++)
            scanf("%s",s[i]);
        priority_queue< pair<int ,pr> > que;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
             {
                 if(s[i][j]=='1')
                {
                    que.push(mp(0,mp(i,j)));
                    ans[i][j]=0;
                }
                else ans[i][j]=1e9;
             }
        }
        solve(que);
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
                printf("%d ",ans[i][j]);
            printf("\n");
        }
    }
return 0;
}
