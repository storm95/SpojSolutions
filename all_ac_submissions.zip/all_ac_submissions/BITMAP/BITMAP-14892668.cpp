#include<bits/stdc++.h>
#define lli long long int
using namespace std;
lli itr=0;
int main()
{
    //ios::sync_with_stdio(false);
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,m,x,y;
        scanf("%d%d",&n,&m);
        char str[n][m];
        for(int i=0; i<n; i++)
            scanf("%s",str[i]);
        int ans[n][m];
        int vis[n][m];
        memset(ans,1000000007,sizeof(ans));
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                if(str[i][j]=='1')
                    ans[i][j]=0;
            }
        }
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                if(ans[i][j]==0)
                {
                    memset(vis,-1,sizeof(vis));
                    vis[i][j]=0;
                    queue<pair<int,int> >q;
                    q.push(make_pair(i,j));
                    while(!q.empty())
                    {
                        itr++;
                        x=q.front().first;
                        y=q.front().second;
                        q.pop();
                        if(x>0)
                        {
                            if(vis[x-1][y]==-1)
                            {
                                vis[x-1][y]=vis[x][y]+1;
                                if(vis[x-1][y]<ans[x-1][y])
                                {
                                    q.push(make_pair(x-1,y));
                                    ans[x-1][y]=vis[x-1][y];
                                }
                            }
                        }
                        if(y>0)
                        {
                            if(vis[x][y-1]==-1)
                            {
                                vis[x][y-1]=vis[x][y]+1;
                                if(vis[x][y-1]<ans[x][y-1])
                                {
                                    q.push(make_pair(x,y-1));
                                    ans[x][y-1]=vis[x][y-1];
                                }
                            }
                        }
                        if(x<n-1)
                        {
                            if(vis[x+1][y]==-1)
                            {
                                vis[x+1][y]=vis[x][y]+1;
                                if(vis[x+1][y]<ans[x+1][y])
                                {
                                    q.push(make_pair(x+1,y));
                                    ans[x+1][y]=vis[x+1][y];
                                }
                            }
                        }
                        if(y<m-1)
                        {
                            if(vis[x][y+1]==-1)
                            {
                                vis[x][y+1]=vis[x][y]+1;
                                if(vis[x][y+1]<ans[x][y+1])
                                {
                                    q.push(make_pair(x,y+1));
                                    ans[x][y+1]=vis[x][y+1];
                                }
                            }
                        }
                    }
                }
            }
        }
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                printf("%d ",ans[i][j]);
            }
            printf("\n");
        }
        //cout<<"Number of iterations->"<<itr<<endl;
    }
    return 0;
}
