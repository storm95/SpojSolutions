#include<cstdio>
int b[200][200];
int n,m;
void bfs(int a,int bi,int i,int j,int len)
{
	if(i>a)
	{
		int flag=0;
		for(int l=i,k=j;l>=a&&k<m;++k,--l)
		{
			if(l<n)
			if(b[l][k]>=len)
			{
				b[l][k]=len;
				flag=1;
			}
		}
		if(flag)
		bfs(a,bi,i+1,j,len+1);
	}
	else if(i<a)
        {
                int flag=0;
                for(int l=i,k=j;l<=a&&k>=0;--k,++l)
                {
			if(l>=0)
                        if(b[l][k]>=len)
                        {
                                b[l][k]=len;
                                flag=1;
                        }
                }
                if(flag)
                bfs(a,bi,i-1,j,len+1);
        }
	else if(j>bi)
        {
                int flag=0;
                for(int l=i,k=j;l>=0&&k>=bi;--k,--l)
                {
			if(k<m)
                        if(b[l][k]>=len)
                        {
                                b[l][k]=len;
                                flag=1;
                        }
                }
                if(flag)
                bfs(a,bi,i,j+1,len+1);
        }
	else if(j<bi)
        {
                int flag=0;
                for(int l=i,k=j;l<n&&k<=bi;++k,++l)
                {
			if(k>=0)
                        if(b[l][k]>=len)
                        {
                                b[l][k]=len;
                                flag=1;
                        }
                }
                if(flag)
                bfs(a,bi,i,j-1,len+1);
        }

}
int main()
{
	int t,i,j,k,l,flag,x;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		for(i=0;i<n;++i)
		for(j=0;j<m;++j)
		{
			scanf("%1d",&x);
			if(x) b[i][j]=0;else b[i][j]=100000;
		}
		for(i=0;i<n;++i)
		for(j=0;j<m;++j)
		{
			if(b[i][j]==0)
			{
				bfs(i,j,i+1,j,1);
				bfs(i,j,i,j+1,1);
				bfs(i,j,i-1,j,1);
				bfs(i,j,i,j-1,1);
			}
		}
		for(i=0;i<n;++i)
		{
			printf("\n");
			for(j=0;j<m;++j)
			printf("%d ",b[i][j]);
		}
	}
	return 0;
}
