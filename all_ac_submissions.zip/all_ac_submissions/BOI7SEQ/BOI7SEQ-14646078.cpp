#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define sz 50005
#define P pair<int,int>
#define fs first
#define sd second

using namespace std;

const int MAXN=1000010;
int st[MAXN];
int main()
{

int n,tp,tm,i;
long long ans;

    sfd(n);
    tp=ans=0;
    for(i=1;i<=n;++i)
    {
        sfd(tm);
        while(tp)
        {
            if(tm>=st[tp])
            {
                if(tp==1)
                    ans+=tm;
                else
                {
                    if(tm>st[tp-1])
                        ans+=st[tp-1];
                    else
                        ans+=tm;
                }
                tp--;
            }
            else
                break;
        }
        st[++tp]=tm;
    }
    for(i=1;i<tp;i++)
      ans+=st[i];
    pflld(ans);
    return 0;
}
