#include<cstdio>
int a[1000];
void ch(int n)
{
	for(int i=0;i<(n-i-1);++i)
	{
		int t=a[i];
		a[i]=a[n-i-1];
		a[n-i-1]=t;
	}
}
void minus(int &n)
{
	int carry=-1,i=0;
	while(carry==-1)
	{
		a[i]+=carry;
		carry=0;
		if(a[i]<0)
		{
			carry=-1;
			a[i]+=10;
		}
		++i;
	}
	while(n>1&&a[n-1]==0)
	--n;
}
void mul(int &n)
{
	int carry=0,i=0,t;
	for(i=0;i<n;++i)
	{
		t=a[i]*2+carry;
		a[i]=t%10;
		carry=t/10;
	}
	while(carry)
	{
		a[n]=carry%10;
		++n;
		carry/=10;
	}
}
int main()
{
	int n,i,j,k;
	char c;
	i=0;
	while(scanf("%c",&c)!=EOF)
	{
		if(c!='\n')
		{
			a[i]=c-'0';
			++i;
		}
		else
		{
			if(i==1&&a[0]==1)
			printf("1\n");
			else 
			{
				ch(i);
				minus(i);
				mul(i);
				for(j=i-1;j>=0;--j)
				printf("%d",a[j]);
				printf("\n");
			}	
			i=0;
		}
	}
	return 0;
	
}
