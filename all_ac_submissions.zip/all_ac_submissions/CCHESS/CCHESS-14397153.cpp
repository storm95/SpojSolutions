#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
using namespace std;
queue<int>x,y;

int v[9][9]={0},dp[9][9],f;
void solve(int i,int j)
{
       int dx[8]={1,1,-1,-1,2,2,-2,-2};
       int dy[8]={2,-2,2,-2,1,-1,1,-1};
       int mx[8];
           for(int p=0;p<8;p++)
            {
                int nx=i+dx[p],ny=j+dy[p];
                //if(nx==3&&ny==2)
                   // cout<<"asd";
                if(nx>=0&&nx<8&&ny>=0&&ny<8)
                {
                        if(dp[nx][ny]>dp[i][j]+i*nx+j*ny)
                        {
                          x.push(nx);
                          y.push(ny);
                          dp[nx][ny]=dp[i][j]+i*nx+j*ny;
                        }
                }
            }


}
using namespace std;

int main()
{
    int i,a,b,j,m,n,k;
    while(sfd(a)!=EOF)
    {
        sfd(b);
        sfd(m);
        sfd(n);
        for( i=0;i<=7;i++)
            for( j=0;j<=7;j++)
           {
             dp[i][j]=100000000;
             v[i][j]=0;
           }
       f=0;
       dp[a][b]=0;
       v[a][b]=1;
       x.push(a);
       y.push(b);
    while(!x.empty())
    {
        i=x.front();
        j=y.front();
        x.pop();
        y.pop();
        solve(i,j);
        v[i][j]=1;
        //cout<<i<<" "<<j<<endl;
    }
    if(v[m][n]==1)
        cout<<dp[m][n]<<endl;
    else
        cout<<"-1"<<endl;
    while(!x.empty())
    {
        i=x.front();
        j=y.front();
        x.pop();
        y.pop();
    }
    }
    return 0;
}
/*for(int i=0;i<=7;i++)
    {
        for(int j=0;j<=7;j++)
            cout<<dp[i][j]<<" ";
        cout<<endl;
    }*/
