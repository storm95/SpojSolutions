#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
char a[]={'A','L','L','I','Z','Z','W','E','L','L'};
int n,m,f=0,vis[100][100];
char dp[101][101];
void dfs(int i,int j,int k)
{
        vis[i][j]=1;
        if(f==1)
            return;
        if(k==9)
            {
                f=1;
                return ;
            }
        
        int dx[8]={0, 0, 1, -1, 1, 1, -1, -1};
        int dy[8]={1, -1, 0, 0, 1, -1, 1, -1};
        for(int p=0;p<8;p++)
        {
                int nx=i+dx[p],ny=j+dy[p];

                if(nx>=0&&nx<n&&ny>=0&&ny<m&&vis[nx][ny]==0&&dp[nx][ny]==a[k+1]&&f==0)
                {
                    vis[nx][ny]=1;
                    dfs(nx,ny,k+1);
                    vis[nx][ny]=0;
                }
        }
        vis[i][j]=0;
        return;
}

int main()
{
    int t,i,j;
    sfd(t);
    while(t--)
    {
        sfd(n);
        sfd(m);
         scanf("%*c");
        for(i=0;i<n;i++)
        {
          sfs(dp[i]);    
        }
         scanf("%*c");
        memset(vis,0,sizeof(vis));
        f=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(dp[i][j]=='A'&&f==0)
                {
                    vis[i][j]=1;
                    dfs(i,j,0);
                    vis[i][j]=0;
                }
            }
        }
        if(f==1)
            cout<<"YES"<<endl;
        else 
            cout<<"NO"<<endl;
    }
    return 0;
}
