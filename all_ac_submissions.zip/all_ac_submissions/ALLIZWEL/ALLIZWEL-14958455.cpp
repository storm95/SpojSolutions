/*  e_coder  :: MD ABDUSSAMAD
    Birla Institute Of technology, Mesra
*/
#include<bits/stdc++.h>
using namespace std;
string str="ALLIZZWELL";
static int fix[][2]={{1,0},{1,-1},{0,1},{0,-1},{-1,0},{-1,1},{1,1},{-1,-1}};
char s[105][105];
int mark[105][105];
int n,m;
bool solve(int a,int b,int idx)
{
    if(idx==10) return true;
    bool flag=false;
    mark[a][b]=1;
    for(int i=0;i<8;i++)
    {
        int x=a+fix[i][0];
        int y=b+fix[i][1];
        if(x>=0 && x<n && y>=0 && y<m && mark[x][y]!=1)
        {
            if(str[idx]==s[x][y])
            {
                mark[x][y]=1;
                flag=flag || solve(x,y,idx+1);
            }
        }
    }
mark[a][b]=0;
return flag;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
    	printf("\n");
        scanf("%d%d",&n,&m);
        for(int i=0;i<n;i++)
            scanf("%s",s[i]);
        bool flag=false;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
             {
                 if(s[i][j]=='A')
                {
                	memset(mark,0,sizeof(mark));
                    if(solve(i,j,1))
                    {
                        flag=true;
                        break;
                    }
                }
             }
            if(flag) break;
        }
        if(flag) printf("YES\n");
        else printf("NO\n");
    }
return 0;
}