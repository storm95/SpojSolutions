#include<bits/stdc++.h>
using namespace std;
int dx[]={-1,-1,-1,0,1,1,1,0};
int dy[]={-1,0,1,1,1,0,-1,-1};
bool vis[101][101] ;
char mat[101][101];
int n,m;
bool valid(int i,int j)
{
    if(i<0 || j<0 || i>=n ||  j>=m)
        return false;
    return true;
}
string pat = "ALLIZZWELL";

bool dfs(int x,int y,int pos)
{
vis[x][y] = true;
if(pos == 9)
    {
        return true;
    }
for(int i = 0 ;  i< 8; i++)
{
    int nbx = x + dx[i];
    int nby = y + dy[i];
    if(!vis[nbx][nby] && valid(nbx,nby))
    {
        bool ret = false;
        if(mat[nbx][nby] == pat[pos+1])
            {
                vis[nbx][nby] = true;
                ret =  dfs(nbx,nby,pos+1);
                if(!ret)
                {
                    vis[nbx][nby] = false;
                }
                else return true;
            }
    }
}
vis[x][y] = false;
return false;
}


int main()
{
    int t= 0;
    scanf("%d",&t);
    while(t--)
    {
    scanf("%d%d",&n,&m);
    memset(vis,0,sizeof(vis));
    memset(mat,' ',sizeof(mat));
    bool res = false;
    for(int i=0;i<n;i++)
        scanf("%s",mat[i]);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
            if(mat[i][j]=='A')
            {
                memset(vis,0,sizeof(vis));
                res = dfs(i,j,0);
                if(res)
                    break;
            }
        if(res) break;
    }
    if(res)
    printf("YES\n");
    else
    printf("NO\n");
    }
    return 0;
}
