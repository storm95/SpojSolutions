#include<iostream>
#include<cstdio>
#include<sstream>
#include<cstring>
using namespace std;
int m[128];
string n[10]={"063","010","093","079","106","103","119","011","127","107"};
int main()
{
	string a,b,c,d;
	int z=0;
	m[63]=0;m[10]=1;m[93]=2;m[79]=3;m[106]=4;m[103]=5;m[119]=6;m[11]=7;m[127]=8;m[107]=9;
	while(cin>>a&&a!="BYE"&&a!="BYE\n")
	{
		if(z!=0)printf("\n");z=1;
		istringstream in(a);
		getline(in,b,'+');
		getline(in,c,'=');
		int len1=b.size(),len2=c.size();
		d="\0";
		int e,f,g=0,k=0,i,j;
		for(i=len1-1,j=len2-1;i>=2&&j>=2;i-=3,j-=3)
		{
			e=(b[i-2]-'0')*100+(b[i-1]-'0')*10+(b[i]-'0');
			f=(c[j-2]-'0')*100+(c[j-1]-'0')*10+(c[j]-'0');
			e=m[e];f=m[f];
//			cout<<e<<" "<<f<<"\n";
			e+=(f+g);
			g=e/10;
			e=e%10;
			d+=n[e];
			++k;
		}
		while(i>=2)
		{
			e=(b[i-2]-'0')*100+(b[i-1]-'0')*10+(b[i]-'0');
			e=m[e];
                        e+=g;
                        g=e/10;
                        e=e%10;
                        d+=n[e];i-=3;
                        ++k; 
		}
		while(j>=2)
		{
                        f=(c[j-2]-'0')*100+(c[j-1]-'0')*10+(c[j]-'0');
			f=m[f];
                        f+=g;j-=3;
                        g=f/10;
                        f=f%10;
                        d+=n[f];
                        ++k;

		}
		while(g)
		{
			d+=n[g%10];
			g/=10;
			++k;
		}
		k*=3;
		cout<<a;
		for(i=k-3;i>=0;i-=3)
		{
			printf("%c%c%c",d[i],d[i+1],d[i+2]);
		}
//		cout<<"\n";
	}
	return 0;
}
