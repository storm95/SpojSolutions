#include <iostream>
#include<cstdio>
#include<stdlib.h>
using namespace std;

int main()
{
    long long int t,n,*a,s,i;
    cin>>t;
    while(t--)
    {
        s=0;

        cin>>n;
        a=( long long int*)malloc(n*sizeof( long long int));
       for(i=0;i<n;i++)
       {
           cin>>a[i];
           a[i]=a[i]%n;
           s=s+a[i];
       }
       if(s%n==0)
        cout<<"YES"<<endl;
       else
         cout<<"NO"<<endl;
    }
    return 0;
}
