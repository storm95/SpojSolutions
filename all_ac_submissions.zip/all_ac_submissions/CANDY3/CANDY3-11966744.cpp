//Candy 3
#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
        long long t,n,sum,a,i;
        scanf("%lld",&t);
        while(t--)
        {
                scanf("%lld",&n);
                sum=0;
                for(i=0;i<n;++i)
                {
                        scanf("%lld",&a);
                        sum=(sum+a)%n;
                }
                if(sum==0)
                printf("YES\n");
                else printf("NO\n");
        }
        return 0;
}
