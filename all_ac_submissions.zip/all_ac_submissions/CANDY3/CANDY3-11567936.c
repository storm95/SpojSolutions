#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        printf("\n");
        int n,i;
        long long int s=0,a;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            scanf("%lld",&a);
            s+=a;
            if(s>=n)
                s%=n;
        }
        if(s==0)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}
