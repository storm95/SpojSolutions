#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long int t,n,p,r,q,u;
    scanf("%llu",&t);
    printf("\n");
    while(t>0)
    {
        r=0;
        scanf("%llu",&n);
        q=n;
        while(n>0)
        {
            scanf("%llu",&p);
            u=p%q;
            r=r+u;
            n--;
        }

        if(r%q==0)
        printf("YES\n\n");
        else
        printf("NO\n\n");
        t--;

    }
    return 0;
}
