/* O(N) - 2 pointers method */
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 9;

int trains[MAXN];
int humans;
int tc,N;

int main (){
	ios_base :: sync_with_stdio(false); cin.tie(0);
	cin >> tc;
	while(tc--){
		cin >> N >> humans;
		
		for(int i = 1;i <= N;++i){
			cin >> trains[i];
		}

		int l = 1,r = 1,sum = 0;
		int ans_dist = 0,ans_hum = 0;

		while(true){
			if(sum <= humans){
				int cur_dist = r - l;
				if((ans_dist < cur_dist) || (ans_dist == cur_dist && ans_hum > sum)){
					ans_dist = cur_dist;
					ans_hum = sum;
				}

				if(r > N) break;
				sum = sum + trains[r++]; // Moving the right pointer.
			} else {
				sum = sum - trains[l++]; // Moving the left pointer.
			}
		}

		cout << ans_hum << " " << ans_dist << endl;
	}
	
	return 0;
}
