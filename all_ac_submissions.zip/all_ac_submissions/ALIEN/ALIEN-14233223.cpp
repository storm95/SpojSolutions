#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int t;
    long m,a,b,*c,i,s,ct,p,mn,mx;
    sfd(t);
    while(t--)
    {
        sfld(a);
        sfld(b);
        c=new long[a];

        for(i=0;i<a;i++)
            {
                sfld(c[i]);

            }
        p=0;

        if(c[0]<=b)
        {
            s=c[0];
            ct=1;
        }
        else
        {
            s=0;
            ct=0;
        }
        p=0;
        mn=s;
        mx=ct;
        for(i=1;i<a;i++)
        {
            s+=c[i];
            ct++;
            while(s>b)
            {
                s-=c[p];
                p++;
                ct--;
            }
            if(ct>mx)
            {
                mx=ct;
                mn=s;
            }
            if(ct==mx)
            {
                if(mn>s)
                    mn=s;
            }

        }

        cout<<mn<<" "<<mx<<endl;
    }
    return 0;
}

