#include<bits/stdc++.h>
#define ll long long int
using namespace std;
ll arr[300001];
int idx=0;
ll mn=0;
void solve(int n,int sum)
{
    ll mx=0;
    ll cur_sum=arr[0];
    int j=0;
    for(int i=1;i<=n;i++)
    {
        while(cur_sum>sum && j<i-1)
        {
            cur_sum-=arr[j];
            j++;
        }
        int x=i-j;
        if(x>=idx)
        {
            if(x>idx)
            {
                idx=x;
                mn=cur_sum;
            }
            else mn=min(mn,cur_sum);
        }
        cur_sum+=arr[i];
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        idx=0;
        mn=0;
        int n,m;
        scanf("%d %d",&n,&m);
        for(int i=0;i<n;i++) scanf("%d",&arr[i]);
        solve(n,m);
        printf("%lld %d\n",mn,idx);
    }
    return 0;
}
