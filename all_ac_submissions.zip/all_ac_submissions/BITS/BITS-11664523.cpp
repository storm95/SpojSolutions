#include<bits/stdc++.h>
using namespace std;
int calc[1005];
void preprocess()
{
	int k,i,temp;
	for(i=1;i<=1000;i++)
	{   k=0;
		temp=i;
		while(temp)
		{
			if(temp&1) k++;
			temp>>=1;
		}
		calc[i]=k+calc[i-1];
	}
}
int main()
{
	ios_base::sync_with_stdio(0);
	int tc,n;
	memset(calc,0,1005);
	preprocess();
	cin>>tc;
	while(tc--)
	{
		cin>>n;
		cout<<calc[n]<<"\n";
	}
	return 0;
}