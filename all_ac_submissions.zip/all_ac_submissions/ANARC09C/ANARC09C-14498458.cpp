#include<bits/stdc++.h>
using namespace std;
#define sz 10001
#define ll long long
bool sieve[sz];
vector<ll> primes;
void init()
{
	memset(sieve,1,sizeof sieve);
	for(ll i=2;i*i<sz;++i)
	{
		if(sieve[i])
		for(ll j=i*i;j<sz;j+=i)
			sieve[j]=false;
	}
	for(int i=2;i<sz;++i)
		if(sieve[i])
		primes.push_back(i);
}
void gen(vector<ll> &lst,vector<ll> &cord,ll x)
{
	ll b=0;
	for(int i=0;primes[i]*primes[i]<=x;++i)
	{
		if(x%primes[i]==0)
		{
			b=1;
			x/=primes[i];
			while(x%primes[i]==0)
			{
				x/=primes[i];
				++b;
			}
			lst.push_back(primes[i]);
			cord.push_back(b);
		}
	}
	if(x!=1)
	{
		lst.push_back(x);
		cord.push_back(1);
	}
}
int main()
{
	init();
	ll a,b;
	ll t=0;
	while(scanf("%lld%lld",&a,&b)!=EOF)
	{
		++t;
		if(a==0&&b==0)
			break;
		vector<ll> lsta;
		vector<ll> corda;
		vector<ll> lstb;
		vector<ll> cordb;
		gen(lsta,corda,a);
		gen(lstb,cordb,b);
		int lena=lsta.size();
		int lenb=lstb.size();

		ll ansa=0;
		ll ansb=0;
		int i=0,j=0;
		for(;i<lena&&j<lenb;)
		{
			if(lsta[i]==lstb[j])
			{
				++ansa;
				ansb+=abs(corda[i]-cordb[j]);
				++i;++j;
			}
			else if(lsta[i]<lstb[j])
			{
				++ansa;
				ansb+=corda[i];
				++i;
			}
			else 
			{
				++ansa;
				ansb+=cordb[j];
				++j;
			}
		}
		for(;i<lena;++i)
		{
			++ansa;
			ansb+=corda[i];
		}
		for(;j<lenb;++j)
		{
			++ansa;
			ansb+=cordb[j];
		}
		printf("%lld. %lld:%lld\n",t,ansa,ansb );
	}
	return 0;
}