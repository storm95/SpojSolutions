#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
int dp[21][21][1001],n,m,k,cb[21],r[21][21],ct[21][21];
int cal(int i,int j,int rem)
{
    if(i==n||j==m||rem==0)
        return 0;
    int &ret=dp[i][j][rem];
    if(ret!=-1)
        return ret;
    ret=0;
    int p,q;
    for(p=i+1;p<n;p++)
        if(rem-cb[p]>=0)
         ret=max(ret,cal(p,0,rem-cb[p]));
    for(q=j;q<m;q++)
        if(rem-ct[i][q]>=0)
        ret=max(ret,r[i][q]+cal(i,q,rem-ct[i][q]));
    return ret;
}
int main()
{
    int t,i,j,mx;
    sfd(t);
    while(t--)
    {
        memset(dp,-1,sizeof(dp));
        sfd(n);
        sfd(m);
        sfd(k);
        for(i=0;i<n;i++)
            sfd(cb[i]);
        for(i=0;i<n;i++)
           for(j=0;j<m;j++)
            sfd(ct[i][j]);
        for(i=0;i<n;i++)
           for(j=0;j<m;j++)
            sfd(r[i][j]);
        mx=0;
        for(i=0;i<n;i++)
            if(k-cb[i]>=0)
            mx=max(mx,cal(i,0,k-cb[i]));
        pfd(mx);
    }
    return 0;
}
