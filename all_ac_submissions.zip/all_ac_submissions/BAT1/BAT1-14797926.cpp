#include <bits/stdc++.h>
using namespace std;

const int MAXN = 23;

int tc,N,M,K;
int batch[MAXN];
int dp[23][2099][2];
int cost[MAXN][MAXN];
int power[MAXN][MAXN];

inline int go(int cur,int left,int open){
    if(cur == N)
        return 0;

    int &ret = dp[cur][left][open];

    if(ret != -1)
        return ret;

    ret = go(cur + 1,left,0);

    if((open == 0) && (left >= batch[cur])){
        left = left - batch[cur];
        for(int i = 0;i < M;++i)
            if(cost[cur][i] <= left)
                ret = max(ret,go(cur,left - cost[cur][i],1) + power[cur][i]);
    } else if(open == 1){
        for(int i = 0;i < M;++i)
            if(cost[cur][i] <= left)
                ret = max(ret,go(cur,left - cost[cur][i],1) + power[cur][i]);
    }

    return ret;
}

int main(){
    scanf("%d",&tc);
    while(tc--){
        memset(dp,-1,sizeof(dp));
        scanf("%d %d %d",&N,&M,&K);
        for(int i = 0;i < N;++i){
           scanf("%d",&batch[i]);
        }
        for(int i = 0;i < N;++i){
            for(int j = 0;j < M;++j){
                scanf("%d",&cost[i][j]);
            }
        }
        for(int i = 0;i < N;++i){
            for(int j = 0;j < M;++j){
                scanf("%d",&power[i][j]);
            }
        }
        printf("%d\n",go(0,K,0));
    }
    return 0;
}
