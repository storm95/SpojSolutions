#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
vector<pair<int,int> > v;
double arr[2210];
int main()
{
	long long tc;
	scanf("%lld",&tc);
	int size,n,infinity,i,j,x,y,ans=0,more;
	while(tc--)
	{
		scanf("%d",&n);
		v.clear();
		ans=0;
		for(i=0;i<n;++i)
		{
			scanf("%d%d",&x,&y);
			v.push_back(pair<int,int>(x,y));
		}
		for(i=0;i<n;++i)
		{
			infinity=size=0;
			for(j=i+1;j<n;++j)
			{
				if(v[j].first==v[i].first)
				++infinity;
				else
				{
					arr[size]=((double)(v[j].second-v[i].second))/(v[j].first-v[i].first);
					++size;
				}
			}
			sort(arr,arr+size);
			ans=max(ans,infinity);
			for(j=0;j<size;++j)
			{
				if((j==0)||(arr[j]>arr[j-1]))
				more=1;
				else ++more;
				ans=max(ans,more);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}