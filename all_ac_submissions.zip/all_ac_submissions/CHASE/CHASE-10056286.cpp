#include<bits/stdc++.h>
using namespace std;
struct cordinates
{
	int x,y;
}s[2205];
double slopes[2205];
int main()
{
	int t,n,i,j,k,horizontal,ma,ans;
	scanf("%d",&t);
	while(t--)
	{
		ans=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
			scanf("%d%d",&s[i].x,&s[i].y);
		for(i=0;i<n;i++)
		{
			horizontal=0;k=0;ma=0;
			for(j=i+1;j<n;j++)
			{
				if(s[j].y==s[i].y)
					horizontal++;
				else
					slopes[k++]=(double)(s[i].x-s[j].x)/(double)(s[i].y-s[j].y);
			}
			ans=max(ans,horizontal);
			sort(slopes,slopes+k);
			for(j=0;j<k;j++)
			{
				if(!j||slopes[j-1]<slopes[j])
					ma=1;
				else
					ma++;
				ans=max(ans,ma);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}