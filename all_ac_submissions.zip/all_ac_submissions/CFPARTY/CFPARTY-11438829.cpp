#include<bits/stdc++.h>
int main()
{   int n,tc;
	scanf("%d",&tc);
	while(tc--){
		scanf("%d",&n);
        if(n==1)
        printf("0\n");
        else
		printf("%d\n",n-2);
	}
	return 0;
}