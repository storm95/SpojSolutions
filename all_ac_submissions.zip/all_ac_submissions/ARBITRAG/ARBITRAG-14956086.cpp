#include<bits/stdc++.h>
using namespace std;
long double arr[50][50],D;
int main()
{
	map<string,int> mp;
	int n,a,b,tc=0;
	string s,d;
	while(scanf("%d",&n)!=EOF&&n!=0)
	{
		++tc;
		mp.clear();
		memset(arr,0,sizeof(arr));
		for(int i = 0;i<n;++i)
		{
			cin>>s;
			mp[s] = i;
		}
		int m;
		scanf("%d",&m);
		while(m--)
		{
			cin>>s;
			scanf("%Lf",&D);
			cin>>d;
			a = mp[s];
			b = mp[d];
			arr[a][b] = max(arr[a][b],D);
		}
		for(int k = 0;k<n;++k)
		{
			for(int i = 0;i<n;++i)
			{
				for(int j = 0;j<n;++j)
				{
					arr[i][j] = max(arr[i][j],arr[i][k]*arr[k][j]);
				}
			}
		}
		bool yes = false;
		for(int i = 0; i<n;++i)
		{
			if(arr[i][i] > (1.0 ))
			{
				yes = true;
				break;
			}
		}
		if(yes)
			printf("Case %d: Yes\n",tc);
		else printf("Case %d: No\n",tc);
	}
	return 0;
}