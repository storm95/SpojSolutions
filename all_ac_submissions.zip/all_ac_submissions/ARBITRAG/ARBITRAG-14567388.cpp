#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lf 2*idx
#define rt 2*idx+1
#define P pair<int,double>
using namespace std;
map<string,int>mp;
double dp[300][300];
int main()
{
    int n,i,m,p,q,k,j,cas=1;
    double d;
    string s;
    sfd(n);
    while(n)
    {
        for(i=0;i<n;i++)
        {
            cin>>s;
            mp.insert(make_pair(s,i));
        }
        sfd(m);
        memset(dp,0,sizeof(dp));
        for(i=0;i<m;i++)
        {
            cin>>s;
            p=mp.find(s)->second;
            cin>>d;
            cin>>s;
            q=mp.find(s)->second;
            dp[p][q]=d;
        }
        for(k=0;k<n;k++)
        {
            for(i=0;i<n;i++)
            {
                for(j=0;j<n;j++)
                    if(dp[i][j]<dp[i][k]*dp[k][j])
                      dp[i][j]=dp[i][k]*dp[k][j];
            }
        }
        for(i=0;i<n;i++)
        {
            if(dp[i][i]>1.0)
                break;
        }
		cout << "Case " << cas << ": ";
		if(i==n)
			cout << "No" << endl;
		else
			cout << "Yes" << endl;
		cas++;
		sfd(n);
    }
    return 0;
}
