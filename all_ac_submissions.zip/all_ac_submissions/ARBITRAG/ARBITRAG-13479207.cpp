#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <utility>
#include <cassert>
#include <string>
#include <cmath>
#include <cstdlib>
#include <algorithm>

using namespace std;

typedef long long LL;
typedef vector < int > vi;
typedef vector < vi > vvi;

#define pb push_back
#define mp make_pair

const int MAXN = (int)(1e5 + 9);
const int MOD  = (int)(1e9 + 7);

int n,m;
string s[32];
string a,b;
double dp[32][32];
double p;
int c = 1;
map < string , int > mymap;

int main () {
    
    while(scanf("%d",&n) == 1) {
    	if(!n) break;
    	for(int i = 0;i < n;++i) {
    		cin >> s[i]; 
    		mymap[s[i]] = i;
    	}

    	scanf("%d",&m);

    	memset(dp,0,sizeof(dp));
    	for(int i = 0;i < n;++i) dp[i][i] = 1.000;
    	for(int i = 0;i < m;++i) {
            cin >> a >> p >> b;
    	    dp[mymap[a]][mymap[b]] = p; 
    	}
        
    	for(int k = 0;k < n;++k) {
    		for(int i = 0;i < n;++i) {
    			for(int j = 0;j < n;++j) {
    				dp[i][j] = max(dp[i][j],dp[i][k] * dp[k][j]);
    			}
    		}
    	}

    	bool ok = false;
        for(int i = 0;i < n;++i) {
            if(dp[i][i] > 1.0000) { ok = true; break; }
        }

        printf("Case %d: ",c++);
        puts((ok) ? "Yes" : "No");
    }

	return 0;
}