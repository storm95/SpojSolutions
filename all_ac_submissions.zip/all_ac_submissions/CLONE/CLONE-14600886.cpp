#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1
using namespace std;
map<string,int> mp;
map<string,int>::iterator it;
int main()
{
    int n,m,i,v[20005];
    string s;
    sfd(n);
    sfd(m);
    while(n!=0&&m!=0)
    {
        mp.clear();
        for(i=0;i<n;i++)
        {
            cin>>s;
            it=mp.find(s);
            if(it==mp.end())
            {
                mp[s]=0;
            }
            else
            {
                 // cout<<i<<" "<<it->first<<endl;
                   mp[s]++;
            }
        }
        memset(v,0,sizeof(v));
        for(it=mp.begin();it!=mp.end();++it)
            {
                v[it->second]++;
            }
        for(i=0;i<n;i++)
            pfd(v[i]);
        sfd(n);
        sfd(m);
    }
    return 0;
}
