#include<bits/stdc++.h>
using namespace std;
int arr[1000];
int main()
{
	int n,s;
	cin>>n>>s;
	//for(int j=-14;j<17;++j){
	//	n=5;s=j;
	int sum=(n*(n+1))/2;
	for(int i=1;i<=n;++i)
		arr[i]=0;
	int target=(sum-s)/2;
	if((sum-s)&1)
		target=-1;
	if(target>0)
	{
		for(int i=n;i>=2;--i)
		{
			if(target-i>=0&&target-i!=1)
				arr[i]=1,target-=i;
		}
	}
	if(target==0)
	{
		if(arr[1]==0)
		printf("1");
		else printf("-1");
		for(int i=2;i<=n;++i)
		{
			if(arr[i]==1)
				printf("-%d",i );
			else printf("+%d",i );
		}
	}
	else printf("Impossible");
	//printf("\n");
	//}
	return 0;
}