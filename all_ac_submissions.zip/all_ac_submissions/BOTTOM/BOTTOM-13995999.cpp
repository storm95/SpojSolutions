#include<bits/stdc++.h>
using namespace std;
vector< vector<int> > graph(10000);
vector< vector<int> > graphRev(10000);
vector< int > sol;
int in[10000],scc[10000];
bool visited[10000],chk[10000];
void dfs1(int v)
{
	visited[v]=true;
	int len=graph[v].size();
	for(int i=0;i<len;++i)
	{
		if(!visited[ graph[v][i] ])
		{
			dfs1(graph[v][i]);
		}
	}
	sol.push_back(v);
}
void dfs2(int v,int sccno)
{
	visited[v]=false;
	scc[v]=sccno;
	int len = graphRev[v].size();
	for(int i = 0 ; i < len ; ++i)
	{
		if(visited[ graphRev[v][i] ])
		{
			dfs2(graphRev[v][i],sccno);
		}
	}
}
int main()
{
	int n,m,t,x,y;
	//scanf("%d",&t);
	while(scanf("%d",&n)&&n!=0)
	{
		scanf("%d",&m);
		for(int i=0;i<=n;++i)
		{
			visited[i]=false;
			in[i]=0;
			graph[i].clear();
			graphRev[i].clear();
			sol.clear();
		}
		for(int i=1;i<=m;++i)
		{
				scanf("%d%d",&x,&y);
				graph[x].push_back(y);
				graphRev[y].push_back(x);
			
		}
		for(int i=1;i<=n;++i)
			if(!visited[i])
				dfs1(i);

		int sccno=0;
		for(int i=sol.size()-1;i>=0;--i)
		{
			chk[sccno]=true;
			if(visited[sol[i]])
				dfs2(sol[i],sccno++);
		}
		
		for(int i=1;i<=n;++i)
		{
			int len=graph[i].size();
			for(int j=0;j<len;++j)
			{
				if(scc[i]!=scc[ graph[i][j] ])
					chk[scc[i]]=false;
			}
		}
		for(int i=1;i<=n;++i)
			if(chk[scc[i]])
				printf("%d ",i);
		printf("\n");
	}
	return 0;
}