#include<iostream>
#include<algorithm>
using namespace std;
int main()
{   ios_base::sync_with_stdio(0);
	int n,j,tc;
	cin>>tc;
	while(tc--)
	{   int flag1,flag2,flag3,others,i;
		flag1=flag2=flag3=others=0;
		cin>>n;
		int arr[n];
		for(i=0;i<n;i++)
		{
			cin>>arr[i];
			if(arr[i]==1)
			flag1++;
			else if(arr[i]==2)
			flag2=1;
			else if(arr[i]==3)
			flag3=1;
			else
			others++;
		}
		sort(arr,arr+n,greater<int>());
		for(i=0;i<flag1;i++) cout<<"1 ";
		if(others)
		{
			for(i=0;i<others;i++)
			cout<<arr[i]<<" ";
			if(flag3) cout<<"3 ";
			if(flag2) cout<<"2 ";
		}
		else
		{
		   if(flag2) cout<<"2 ";
		   if(flag3) cout<<"3 ";
		}
		cout<<"\n";
	}
	return 0;
}