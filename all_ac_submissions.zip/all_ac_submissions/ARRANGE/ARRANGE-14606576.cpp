#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1


using namespace std;
vector<int>v;
int main()
{
    int n,i,t,ct1,k;
    sfd(t);
    while(t--)
    {
        sfd(n);
        ct1=0;
        v.clear();
        for(i=0;i<n;i++)
        {
            sfd(k);
            if(k==1)
                ct1++;
            else
                v.push_back(k);
        }
        sort(v.begin(),v.end());
        while(ct1--)
            cout<<"1 ";
        if(v.size()==2&&v[0]==2&&v[1]==3)
             cout<<2<<" "<<3;
        else
            for(i=v.size()-1;i>=0;i--)
             cout<<v[i]<<" ";
        cout<<endl;
    }
    return 0;
}
