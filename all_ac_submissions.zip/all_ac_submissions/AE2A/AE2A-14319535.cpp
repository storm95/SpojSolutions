#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)


using namespace std;
float dp[600][2000];
int main()
{
    memset(dp,0,sizeof(dp));
    int i,j,k,n,p,t;
    for(i=1;i<7;i++)
        dp[1][i]=1/6.0;
    for(i=2;i<600;i++)
    {
        for(j=1;j<2000;j++)
        {
            for(k=1;k<7&&j-k>=0;k++)
                dp[i][j]+=dp[i-1][j-k]/6.0;
        }
    }
    sfd(t);
    while(t--)
    {
        sfd(n);
        sfd(p);
        if(n<550&&p<1900)
            cout<<(int)(dp[n][p]*100)<<endl;
        else
            cout<<"0"<<endl;
    }
    return 0;
}
