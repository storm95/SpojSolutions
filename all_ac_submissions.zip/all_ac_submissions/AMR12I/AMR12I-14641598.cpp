#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1
#define pb push_back

using namespace std;

int main()
{
    int t,i,j,x,y,k,ans,n;
    bool f;
    sfd(t);
    string s;
    while(t--)
    {
        sfd(n);
        sfd(k);
        f=false;
        cin>>s;
        ans=0;
        for(i=0;i<n;)
        {
            j=i+1;
            while(j<n&&s.at(i)==s.at(j))
                j++;
            x=(j-i)/k;
            y=(j-i)%k;
            if(x)
                f=true;
            if(y)
              ans+=x+1;
            else
                ans+=x;
            i=j;
        }
        if(!f)
            ans=-1;
        pfd(ans);

    }
    return 0;
}
