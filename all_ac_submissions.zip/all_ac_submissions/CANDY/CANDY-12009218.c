#include <stdio.h>
#include <stdlib.h>


int main()
{
    int n,a[10000],i,s,k,m;
    scanf("%d",&n);
    while(n!=-1)
    {
        k=0;
        s=0;
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
            s=s+a[i];
        }

        if(s%n==0)
        {
             m=s/n;
                i=0;
           while(i<n)
           {
               if(a[i]<m)
                k=k+m-a[i];
               i++;
           }
            printf("%d\n",k);
        }
        else
            printf("-1\n");
            scanf("%d",&n);
    }
    return 0;
}
