#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
    int n,i,s,c,j;
    int a[10001]={0};
    scanf("%d",&n);
    while(n!=-1)
    {
        s=0;
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
            s+=a[i];
        }

        if(s%n!=0)
            printf("-1\n");
        else
        {
            sort(a,a+n);


            c=0;j=0;
            while(a[j]<s/n)
            {
                c+=(s/n)-a[j];
                j++;

            }
            printf("%d\n",c);
        }
        scanf("%d",&n);

    }



    return 0;
}
