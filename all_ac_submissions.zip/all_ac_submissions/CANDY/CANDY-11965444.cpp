//Candy I
#include<iostream>
#include<cstdio>
inline int absi(int n)
{
        if(n<0)
        return -n;
        else return n;
}
int main()
{
        int n,arr[10001],i,sum,ans;
        while(scanf("%d",&n)!=EOF&&n!=-1)
        {
                sum=0;
                for(i=0;i<n;i++)
                {
                        scanf("%d",&arr[i]);
                        sum+=arr[i];
                }
                if(sum%n!=0)
                printf("-1\n");
                else
                {
                        sum/=n;
                        ans=0;
                        for(i=0;i<n;++i)
                        ans+=absi(sum-arr[i]);
                        ans/=2;
                        printf("%d\n",ans);
                }
        }
        return 0;
}
