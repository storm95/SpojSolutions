#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    long long int sum1,sum2,ans,t,i,j,m,n,a,b,c,marr[1010],narr[1010];
    scanf("%lld",&t);
    while(t--)
    {
        //sum1=sum2=
        ans=0;
        scanf("\n%lld %lld",&m,&n);
        for(i=0;i<m-1;i++)
            {
                scanf("%lld",&marr[i]);
                //sum1+=marr[i];
            }
        for(j=0;j<n-1;j++)
            {
                scanf("%lld",&narr[j]);
                //sum2+=narr[j];
            }
        sort(marr,marr+m-1);
        sort(narr,narr+n-1);
        i=m-2;
        j=n-2;
        while(i>=0 && j>=0)
        {
            if(marr[i]>narr[j])
            {
                ans+=marr[i]*(n-1-j);
                //sum1-=marr[i];
                --i;
            }
            else
            {
                ans+=narr[j]*(m-1-i);
                //sum2-=narr[j];
                --j;
            }
        }
        if(i==-1)
        {
            while(j!=-1)
            {
                ans+=narr[j]*(m-1-i);
                --j;
            }
        }
        else
        {
            while(i!=-1)
            {
                ans+=marr[i]*(n-1-j);
                --i;
            }
        }
        printf("%lld\n",ans);
    }
    return 0;
}

