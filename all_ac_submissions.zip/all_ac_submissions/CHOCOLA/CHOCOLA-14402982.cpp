#include<bits/stdc++.h>
#include<algorithm>
using namespace std;

int main()
{
    int t;
    scanf("%d",&t);
    printf("\n");
    while(t--)
    {
        int n,m;
        scanf("%d %d",&n,&m);
        n--;
        m--;
        int x[n];
        int y[m];
        for(int i=0;i<n;i++) scanf("%d",&x[i]);
        for(int i=0;i<m;i++) scanf("%d",&y[i]);
        sort(x,x+n);
        sort(y,y+m);
        int a=1;
        int b=1;
        int i=n-1;
        int j=m-1;
        int ans=0;
        while(i>=0 && j>=0)
        {
            if(x[i]>y[j])
            {
                ans+=b*x[i];
                a++;
                i--;
            }
            else
            {
                ans+=a*y[j];
                b++;
                j--;
            }
        }
        for(int k=i;k>=0;k--)
        {
            ans+=b*x[k];
            a++;
        }
        for(int k=j;k>=0;k--)
        {
            ans+=a*y[k];
            b++;
        }
        printf("%d\n",ans);
    }
    return 0;
}