#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	string str;
	cin>>t;
	while(t--)
	{
		cin>>str;
		int len = str.size();
		for(int i=0;i<len;++i)
		{
			cout << (char)((str[i]-'A'-3+26)%26 + 'A');
			cout << (char)((str[i]-'A'+4)%26 + 'A');
		}
		cout<<"\n";
	}
	return 0;
}