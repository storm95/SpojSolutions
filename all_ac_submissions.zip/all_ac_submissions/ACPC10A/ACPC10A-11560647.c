#include<stdio.h>
int main()
{
    for(;;)
    {
        int a,b,c,d;
        scanf("%d",&a);
        scanf("%d",&b);
        scanf("%d",&c);
        if(a==0 && b==0 && c==0)
            break;
        if(b-a == c-b)
        {
            d=c+(b-a);
            printf("AP %d\n",d);
        }
        else
        {
               printf("GP %d\n",(c*b/a));
           }
    }
    return 0;
}
