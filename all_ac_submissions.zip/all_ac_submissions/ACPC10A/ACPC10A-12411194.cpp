#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int a,b,c;

    cin>>a>>b>>c;
    while(a!=0||b!=0||c!=0)
    {
        if(2*b==a+c)
        {
            printf("AP %d\n",c+b-a);
        }
        else
        {
            //t=b/a;
            printf("GP %d\n",(c*b)/a);
        }
          cin>>a>>b>>c;
    }
    return 0;
}
