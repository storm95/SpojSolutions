#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,b,c,d,r,x;
    while(scanf("%f%f%f",&a,&b,&c))
    {
        if(a==0&&b==0&&c==0)
            return 0;
        d=0,r=0,x=0;
        if(b-a==c-b)
        {
            x=c+(c-b);
            printf("AP %.0f\n",x);
        }
        else
        {
            r=c/b;
            d=c*r;
            printf("GP %.0f\n",d);
        }
    }

    return 0;
}
