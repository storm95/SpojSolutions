//What's next
#include<iostream>
#include<cstdio>
int main()
{
        int a,b,c;
        while(scanf("%d%d%d",&a,&b,&c)&&(a!=0||b!=0||c!=0))
        {
                if(a-b==b-c)
                        printf("AP %d\n",c+c-b);
                else printf("GP %d\n",(c*c)/b);
        }
        return 0;
}