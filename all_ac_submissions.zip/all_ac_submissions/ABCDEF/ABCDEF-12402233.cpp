#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int main()
{

    int n,s[100],ct=0,a,b,c,d,e,f,i,k,m=0,l=0,j,*p,*q;
    scanf("%d",&n);
    p=(int *)malloc(sizeof(int)*1000000);
    q=(int *)malloc(sizeof(int)*1000000);

    for(i=0;i<n;i++)
       scanf("%d",&s[i]);
    sort(s,s+n);
    for(a=0;a<n;a++)
    {
        for(b=0;b<n;b++)
    {

        for(d=0;d<n;d++)
    {
        q[l++]=(s[a]*s[b]+s[d]);
        if(s[d]!=0)
       {
            p[m++]=s[d]*(s[a]+s[b]);
        }
        }

    }

    }
       sort(p,p+m);
       sort(q,q+l);
     /*  for(i=0;i<m;i++)
            cout<<p[i]<<" ";
        cout<<endl;
         for(i=0;i<l;i++)
            cout<<q[i]<<" ";*/
    i=0;
    j=0;
    k=0;


        while(i<l&&j<m)
        {

            if(p[j]==q[i])
            {

                j++;
                i++;
                c=1;
                d=1;
                while(q[i]==q[i-1]&&i<l)
                {

                    c++;
                    i++;
                }

                while(p[j]==p[j-1]&&j<m)
                {

                    d++;
                    j++;
                }

                ct=ct+c*d;
            }
            else if(p[j]<q[i])
                j++;
            else if(q[i]<p[j])
                i++;
    }
        printf("%d",ct);

    return 0;
}
