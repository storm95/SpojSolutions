#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long  arr[110];
long long  b[1000010];
long long  d[1000010];
long long  c[1000010];
int size(int len1,int len2)
{
	int i=0,j=0,t,count,count1,count2;
	count=0;
	while(i<len1&&j<len2)
	{
		if(b[i]<c[j])
		++i;
		else if(b[i]>c[j]) ++j;
		else
		{
			count1=count2=1;
			++i;
			while(i<len1&&b[i]==c[j])
			{
				++count1;
				++i;
			}
			t=c[j];
			++j;
			while(j<len2&&c[j]==t)
			{
				++count2;++j;
			}
			count+=count1*count2;
		}
	}
	return count;
}
int main()
{
	int n,i,j,k,bid=0,cid=0;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	scanf("%lld",&arr[i]);
	for(i=0;i<n;++i)
	for(j=0;j<n;++j)
	for(k=0;k<n;++k)
	{
		if(arr[i]!=arr[j])
		{b[bid]=(arr[i]*arr[j]+arr[k]);++bid;}
		else if(i<=j)
		{b[bid]=(arr[i]*arr[j]+arr[k]);++bid;}
	}
	sort(b,b+bid);
	for(i=0;i<n;++i)
	{
		for(j=0;j<n;++j)
		{
			for(k=0;k<n;++k)
			{
				if(arr[k]!=0)
				{
					if(arr[i]!=arr[j])
					{c[cid]=((arr[i]+arr[j])*arr[k]);++cid;}
					else if(i<=j)
					{c[cid]=((arr[i]+arr[j])*arr[k]);++cid;}
				}
			}
		}
	}
	sort(c,c+cid);
/*	for(i=0;i<c.size();++i)
        cout<<c[i]<<" ";
        cout<<"\n";
	d.clear();
*/	printf("%d\n",size(bid,cid));
	return 0;
}