#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int r[1000000],l[1000000],szl=0,szr=0;
int n,i,j,k,temp;
unsigned long int res=0;
int bsearch()
{
	int Mid,Lbound=0,Ubound=szl-1;
	while(Lbound<=Ubound)
	{
		Mid=(Lbound+Ubound)/2;
		if(r[i]>l[Mid])
			Lbound=Mid+1;
		else if(r[i]<l[Mid])
			Ubound=Mid-1;
		else
        {
            if((l[Mid-1]<l[Mid])||Mid==0)
                return Mid;
            else
                Ubound=Mid-1;
		}
	}
	return -1;
}
int bsearch2()
{
	int Mid,Lbound=0,Ubound=szl-1;
	while(Lbound<=Ubound)
	{
		Mid=(Lbound+Ubound)/2;
		if(r[i]>l[Mid])
			Lbound=Mid+1;
		else if(r[i]<l[Mid])
			Ubound=Mid-1;
		else
        {
            if((l[Mid+1]>l[Mid])||Mid==szl-1)
                return Mid;
            else
                Lbound=Mid+1;
		}
	}
	return -1;
}

int main()
{
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
             for(k=0;k<n;k++){
                 r[szr]=(a[i]*a[j])+a[k];
                 szr++;}
    for(i=0;i<n;i++)
        if(a[i]!=0)
        for(j=0;j<n;j++)
             for(k=0;k<n;k++){
                 l[szl]=a[i]*(a[j]+a[k]);
                 szl++;}
    sort(r,r+szr);
    sort(l,l+szl);
    int found,found2;
    for(i=0;i<szr;i++)
    {
        found=bsearch();
        found2=bsearch2();
        //printf("%d %d\n",found,found2);
        if(found!=-1&&found2!=-1)
        res+=(found2-found+1);
    }
    printf("%lu\n",res);
    return 0;
}
