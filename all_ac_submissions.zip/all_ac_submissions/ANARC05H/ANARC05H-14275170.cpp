#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define si(a) scanf("%d",&a)
#define sl(a) scanf("%ld",&a)
#define sll(a) scanf("%lld",&a)

using namespace std;
char s[26];
long int solve(long int prev,int l,int h)
{
    long int sum=0;
    if(l==h) return 0;
    for(int i=l;i<h;i++)
    {
        int sum1=0;
        int sum2=0;
        for(int j=l;j<=i;j++)
            sum1+=s[j]-48;
        for(int j=i+1;j<=h;j++)
            sum2+=s[j]-48;
        if(prev<=sum1 && sum1<=sum2) sum+= 1+solve(sum1,i+1,h);
    }
    return sum;
}
int main()
{
    int t=0;
    while(1)
    {
        t++;
        scanf("%s",s);
        if(s[0]=='b') break;
        int l=strlen(s);
        printf("%d. %ld\n",t,solve(0,0,l-1)+1);
    }
    return 0;
}
