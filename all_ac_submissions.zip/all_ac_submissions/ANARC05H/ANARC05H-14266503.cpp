#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
int ct=0;
void cal(int sm,int i,int n,char a[3])
{
   if(i>=n)
    {
        ct++;
        return ;
    }
   else
   {
        int cr=0;
        for(;i<n;i++)
        {
            cr+=a[i]-'0';
           //cout<<i<<"asda"<<cr<<"hgj"<<a[i];
            if(cr>=sm)
            {
                //cout<<" ";
                cal(cr,i+1,n,a);
            }

        }
        //cout<<endl;
        return;
   }
}


int main()
{

       char a[25];
       int k=1;
       sfs(a);
       while(strcmp(a,"bye"))
       {
           cal(0,0,strlen(a),a);
           cout<<k<<". "<<ct<<endl;
           ct=0;
           k++;
           sfs(a);
       }
     return 0;
}
