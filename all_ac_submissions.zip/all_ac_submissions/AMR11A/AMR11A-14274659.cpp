#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int t,m,n,i,j,k,ct,x,y,cx,cy;
    int a[500][500];
    sfd(t);
    while(t--)
    {
        sfd(m);
        sfd(n);
        int p[500][500];
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
            sfd(a[i][j]);
            }
        }
        //k=cal(a,0,0,m,n,0);
        ct=0;
        for(i=m-1;i>=0;i--)
        {
            for(j=n-1;j>=0;j--)
            {
                if(i==m-1&&j==n-1)
                {
                    a[i][j]=1;
                    p[i][j]=1;
                }
                else if(i==m-1)
                {
                    p[i][j]=p[i][j+1]-a[i][j];
                    if(p[i][j]<=0)
                        {
                            p[i][j]=1;
                        }

                }
                else if(j==n-1)
                {
                    p[i][j]=p[i+1][j]-a[i][j];
                    if(p[i][j]<=0)
                        {
                            p[i][j]=1;
                        }

                }
                else
                {
                    x=min(p[i+1][j],p[i][j+1]);
                    if(x-a[i][j]<=0)
                        p[i][j]=1;
                    else
                        p[i][j]=x-a[i][j];
                }
                //cout<<a[i][j]<<","<<p[i][j]<<" ";
            }
            //cout<<endl;
        }

       pfd(p[0][0]);

    }
    return 0;
}

