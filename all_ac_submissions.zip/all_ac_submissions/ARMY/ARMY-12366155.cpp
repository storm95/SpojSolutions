#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
        int n,m,t,i,j,x,y;
        scanf("%d",&t);
        while(t--)
        {
                scanf("%d%d",&n,&m);
                x=y=0;
                for(i=0;i<n;++i)
                scanf("%d",&j),x=max(x,j);
                for(i=0;i<m;++i)
                scanf("%d",&j),y=max(y,j);
                if(x>=y)
                printf("Godzilla\n");
                else printf("MechaGodzilla\n");
        }
        return 0;
}



