#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
    int test;
    scanf("%d",&test);
    while(test--)
    {
        int n,m,g[100000],mg[100000],i;
        scanf("%d %d",&n,&m);
        for(i=0;i<n;i++)
            scanf("%d",&g[i]);
        for(i=0;i<m;i++)
            scanf("%d",&mg[i]);
        sort(g,g+n);
        sort(mg,mg+m);
        if(g[n-1]>=mg[m-1])
            printf("Godzilla\n");
        else
            printf("MechaGodzilla\n");
    }
    return 0;
}
