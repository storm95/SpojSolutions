#include <bits/stdc++.h>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>

using namespace std;

int main()
{
   int t,g,m,n[100000],a[100000],i,j;
   cin>>t;
   while(t--)
   {
       cin>>g>>m;
       for(i=0;i<g;i++)
       {
           cin>>n[i];

       }
        for(i=0;i<m;i++)
       {
           cin>>a[i];

       }
       sort(n,n+g);
       sort(a,a+m);
       i=0;
       j=0;
       while(g>0&&m>0)
       {
           if(n[i]<a[j])
           {
               g--;
               i++;
           }
           else
           {
               m--;
               j++;
           }
       }
       if(g>m)
       {
           cout<<"Godzilla"<<endl;
       }
       else
       {
           cout<<"MechaGodzilla"<<endl;
       }
   }
    return 0;
}
