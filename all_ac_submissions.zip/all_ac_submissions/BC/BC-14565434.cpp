#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lf 2*idx
#define rt 2*idx+1


using namespace std;
int cal(double n,double m,double k)
{
         int l=0;
          while(n>1)
          {
              l++;
              n/=2;
          }
          while(m>1)
          {
              l++;
              m/=2;
          }
          while(k>1)
          {
              l++;
              k/=2;
          }
          return l;
}
int main()
{
    int t,j=1,l;
    long long ans1;
    double n,m,k;
    sfd(t);
    while(t--)
    {
        scanf("%lf%lf%lf",&n,&m,&k);
         l=cal(n,m,k);
           ans1=(n*m*k)-1;
           printf("Case #%d: %lld %d\n",j,ans1,l);
          j++;
    }
    return 0;
}
