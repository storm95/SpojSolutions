/*
  A.SANDEEP
  1st Year CSE
  BIT MESRA
  PROGRAMMING LANGUAGE ---> C++
*/
using namespace std;

#include<iostream>
#include<cstdio>
#include<sstream>                        //....Header Files..
#include<stack>
#include<queue>
#include<set>
#include<map>
#include<utility>
#include<cmath>
#include<cstdlib>
#include<vector>
#include<list>
#include<deque>
#include<algorithm>
#include<cstring>
#include<ctime>
#include<memory.h>
#include<cassert>
#include<bitset>
#include<functional>
#include<numeric>

//......Definitions
#define mod 1000000007
#define swap(a,b)	((a)^=(b),(b)^=(a),(a)^=(b))       //..Swapping of elements using XOR
#define set0(x) memset(x,0,sizeof(x))                  //..Makes all entries equal to 0
#define set1(x) memset(x,1,sizeof(x))                  //..Makes all entries equal to 1
#define set-1(x) memset(x,-1,sizeof(x))                //..Makes all entries equal to -1
#define s2i(x,y) scanf("%d %d",&x,&y)                  //..Input.. 2 integers
#define s3i(x,y,z) scanf("%d %d %d",&x,&y,&z)          //...Input ..3 integers
#define s4i(x,y,z,k) scanf("%d %d %d %d",&x,&y,&z,&k)  //...Input ..4 integers
#define s2lli(x,y) scanf("%lld %lld",&x,&y)            //...Input ..2 long long integers
#define si(x) scanf("%d",&x)                           //...Input ..1 integer
#define sc(x) scanf("%c",&x)                           //...Input ..1 character
#define slli(x) scanf("%lld",&x)                       //...Input ..1 long long 
#define pi(x) printf("%d\n",x)                         //....Output..1 integer
#define pc(x) printf("%c",x)                           //...Output..1 character
#define plli(x) printf("%lld",x)                       //...Output .. 1 long long integer
#define p2lli(x,y) printf("%lld %lld",x,y)             //...Output ..2 long long integers
#define p2i(x,y) printf("%d %d\n",x,y)                 //...Output..2 integers  
#define MAX(a,b) ((a)>(b))? (a):(b)                    //...Maximum of 2 values
#define MAX3(a,b,c) MAX(a,MAX(b,c))                    //...Maximum of 3 values
#define MIN(a,b) ((a)<(b))? (a):(b)                    //...Mininmum of 2 values
#define MIN3(a,b,c) MIN(a,MIN(b,c))                    //...Minimum of 3 values
#define loop(i,start,comp) for(i=start;i<comp;i++)     //...For Loop 
#define ll long long int                               //..ll for long long ..
#define fastcpp ios_base::sync_with_stdio(false)       //...Fast I/O
#define unsigned long long int ull                     //...ull for unsigned long long
#define input int tc;scanf("%d",&tc);while(tc--)       //....Testcases...
#define INF 1<<32                                      //....For finding minimum  
#define pb(x) push_back(x)                             //...For inserting a element in a vector
#define sz(a) int((a).size())                          //...Returns the size 
#define all(c) (c).begin(),(c).end()                   //... Used in traversal
#define tr(c,i) for(typeof((c).begin() i = (c).begin(); i != (c).end(); i++) //...Traversal...
#define present(c,x) ((c).find(x) != (c).end())       //...Tells whether an element is present or not
#define cpresent(c,x) (find(all(c),x) != (c).end())    
typedef pair<int,int> pii;
typedef vector<int> vi;
typedef vector<pii> vpii;
//...Main code Begins Here
int main()
{
	fastcpp;
	int tc,i;
	cin>>tc;
	for(i=1;i<=tc;i++)
    {   
	    double l,b,h;
	    ll hand=0,knife=0;
    	cin>>l>>b>>h;
    	hand = (l*b*h)-1;
    	while( (l>1) || (b>1) || (h>1) )
    	{
    		if(l>1) {   l=l/2;  knife++; };
    		if(b>1) {   b=b/2;  knife++; };
    		if(h>1) {   h=h/2;  knife++; };
    	}  cout<<"Case #"<<i<<": "<<hand<<" "<<knife<<"\n";
    }
	return 0;
}