#include<bits/stdc++.h>
using namespace std;
int c;
string bn(int n)
{
    c=0;
    string ans="";
    while(n>0)
    {
        if(n%2==0) ans='0'+ans;
        else{ ans='1'+ans;c++;}
        n=n/2;
    }
return ans;
}
int dn(string s)
{
    int n=0;
    int k=1;
    int sz=s.size();
    for(int i=sz-1;i>=0;i--)
    {
        if(s[i]=='1') n+=k;
        k=k*2;
    }
return n;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,k;
        scanf("%d%d",&n,&k);
        if(k==0) printf("-1\n");
        else if(k==1) printf("1\n");
        else
        {
            string a=bn(n);
            int sz=a.size();
            string ans="";
            k=k-1;
            for(int i=0;i<sz-1;i++)
            {
                if(a[i]=='1')
                {
                    if(k>0 && c!=1){ ans+='1';k--;}
                    else ans+='0';
                    c--;
                }
                else
                {
                    if(c>0) ans+='0';
                    else
                    {
                        if(k>0){ans+='1';k--;}
                        else ans+='0';
                    }
                }
            }
            ans+='1';
            printf("%d\n",dn(ans));
        }
    }
    return 0;
}
