#include<iostream>
#include<cstdio>
#include<cstring>
int ch[256];
char arr[1000010];
int main()
{
	int n,i,j,diff,len,in,ans,slen;
	char c;
	while(scanf("%d",&n)!=EOF&&n!=0)
	{
		scanf("%c",&c);
		diff=len=in=ans=0;
		scanf("%[^\n]",arr);
		slen=strlen(arr);
		for(i=0;i<256;++i)
		ch[i]=0;
		for(i=0;i<slen;++i)
		{
			if(ch[arr[i]]==0)
				++diff;
			++ch[arr[i]];
			if(diff>n)
			{
//				printf("%d %d\n",in,i);
				for(j=in;diff>n&&j<i;++j)
				{
					if(ch[arr[j]]==1)
						--diff;
					--ch[arr[j]];
					--len;
				}
				in=j;
			}
			++len;
			if(len>ans)
			ans=len;
		}
		printf("%d\n",ans);
	}
	return 0;
}