//simple airthmetic II
#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
long long sim(long long a,long long b,char op)
{
	switch(op)
	{
		case '+':return a+b;
		case '-':return a-b;
		case '/':return a/b;
		case '*':return a*b;
		case '=':return b;
	}
	return 0;
}
int main() 
{
	long long  t,ans,i,num;
	scanf("%lld",&t);
	string ch;
	char op;
	scanf("%c",&op);
	while(t--)
	{
		getline(cin,ch);
		getline(cin,ch);
		int len=ch.length();
		ans=0;num=0;
		op='=';
		for(i=0;i<len;++i)
		{
			while(ch[i]==' ')
			{
//				cout<<"1 "<<i<<"\n";
				++i;
				if(i>=len)
				break;
			}
			if(ch[i]>='0'&&ch[i]<='9')
			{
//					cout<<"2 "<<i<<"\n";
					num=num*10+ch[i]-'0';
			}
			else
			{
//				cout<<"3 "<<i<<"\n";
				if(ch[i]=='=')
				{
					ans=sim(ans,num,op);
					printf("%lld\n",ans);
					break;
				}
				else if(op!='=')
				{
					ans=sim(ans,num,op);
					num=0;
					op=ch[i];
				}
				else
				{
					ans=num;
					num=0;
					op=ch[i];
				}
			}
		}//for

	}//while
	return 0;
}//main
