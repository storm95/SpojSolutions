#include<bits/stdc++.h>
using namespace std;
typedef struct 
{
	int start;
	int fin;
	int job;
}node;
vector<node> act,act2;
vector<bool> ind;
node tmp;
bool cmp(node a,node b)
{
	return (a.fin<b.fin)||(a.fin==b.fin&&a.start<b.start);
}
bool cmp1(node a,node b)
{
	return (a.start<b.start)||(a.start==b.start&&a.fin<b.fin);
}
int main()
{
	int t,n,x,y;
	scanf("%d",&t);
	while(t--)
	{
		act.clear();
		act2.clear();
		ind.clear();
		scanf("%d",&n);
		for(int i=0;i<n;++i)
		{
			scanf("%d%d",&x,&y);
			tmp.job=i;
			tmp.start=x;
			tmp.fin=y;
			act.push_back(tmp);
			act2.push_back(tmp);
			ind.push_back(false);
		}
		sort(act.begin(),act.end(),cmp);
		sort(act2.begin(),act2.end(),cmp1);
		int i=0,count=0,j=0;
		while(i<n)
		{
			for(;i<n;++i)
				if(ind[act[i].job]==false)
					break;
			//cout<<"i "<<i<<"\n";
			if(i<n){
			++count;
			ind[act[i].job]=true;
			for(;j<n&&act2[j].start<act[i].fin;++j)
			{
				ind[act2[j].job]=true;
			}
			//cout<<"j "<<j<<"\n";
			}
		}
		cout<<count<<"\n";
	}
	return 0;
}