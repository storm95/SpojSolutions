#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
pair<int,int>p[100005];
int main()
{
    int t,n,i,j,ct,cnd;
    sfd(t);
    while(t--)
    {
        sfd(n);
        for(i=0;i<n;i++)
        {
            sfd(p[i].second);
            sfd(p[i].first);
        }
        sort(p,p+n);
//        memset(vis,0,sizeof(vis));
        cnd=p[0].first;
        i=1;
        ct=1;
        while(i<n)
        {
            if(p[i].second>=cnd)
            {
                ct++;
                cnd=p[i].first;
            }
            i++;
        }
        pfd(ct);
    }
    return 0;
}
