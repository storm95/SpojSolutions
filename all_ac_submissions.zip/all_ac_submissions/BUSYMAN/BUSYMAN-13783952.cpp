#include<bits/stdc++.h>
using namespace std;
typedef struct 
{
	int type;
	int val;
	int job;
}node;
vector<node> act;
vector<int> ind;
node tmp;
bool cmp(node a,node b)
{
	return (a.val<b.val)||(a.val==b.val&&a.type>b.type);
}
int main()
{
	int n,t,x,y;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		act.clear();
		ind.clear();
		for(int i=0;i<n;++i)
		{
			scanf("%d%d",&x,&y);
			tmp.job=i;
			tmp.type=0;
			tmp.val=x;
			act.push_back(tmp);
			tmp.type=1;
			tmp.val=y;
			act.push_back(tmp);
			ind.push_back(-1);
		}
		sort(act.begin(),act.end(),cmp);
		int i=0,count=0;
		//for(i=0;i<2*n;++i)
		//	cout<<act[i].val<<" "<<act[i].type<<" "<<act[i].job<<"\n";
		for(i=0;i<2*n;++i)
		{
			if(act[i].type==0)
			{
				ind[act[i].job]=count;
			}
			else
			{
				if(ind[act[i].job]==count)
				{
					++count;
				}
			}
		}
		cout<<count<<"\n";
	}
	return 0;
}