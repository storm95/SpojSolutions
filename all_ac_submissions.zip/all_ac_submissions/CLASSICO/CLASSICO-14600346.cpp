#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
vector<ll>v;
int mx(int i,int j)
{
    ll mn=-1;
    int k;
    while(i<=j)
    {
        if(v[i]>mn)
        {
           k=i;
           mn=v[i];
        }
        i++;
    }
    return k;
}
int main()
{
    int t,n,k,i,ts=1;
    ll a;
    sfd(t);
    while(t--)
    {
        sfd(n);
        v.clear();
        for(i=0;i<n;i++)
        {
            sflld(a);
            v.push_back(a);
        }
        printf("Case %d: ",ts);
        ts++;
        if(n>10)
        {
          int l=0,r=n-11;
          i=0;
          while(i<10)
          {
              k=mx(l,r);
              printf("%d ",v[k]);
              l=k+1;
              r++;
              i++;
          }
          k=mx(l,r);
          printf("%d\n",v[k]);
        }
        else
            printf("go home!\n");
    }
    return 0;
}
