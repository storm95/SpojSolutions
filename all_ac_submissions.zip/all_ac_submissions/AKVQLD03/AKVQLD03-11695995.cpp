#include<iostream>
#include<cstdio>
#include<stdlib.h>
#include<iomanip>
#include<math.h>
#include<limits.h>
#include<string.h>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#define mod 1000000007
#define MAX 100000000
 
using namespace std;
 
#define PB(x) push_back(x)
#define SORT(a) sort(a.begin(),a.end())
#define INF 1000000000
#define V vector
#define S string
typedef long long LL;
typedef long double LD;
typedef long L;
const double pi=acos(-1.0);
LL arr[1000005];
struct T
{
  LL sum;
}tree[12800000];
 
void build(int node,int a,int b)
{
  if(a==b)
  {
    tree[node].sum=arr[a];
	return;
  }
  int mid=(a+b)>>1;
  build(2*node,a,mid);
  build(2*node+1,mid+1,b);
  tree[node].sum=tree[2*node].sum + tree[2*node+1].sum;
}
 
void update(int node,int a,int b,int val,int index)
{
   if(a==b)
   {   
      tree[node].sum+=val;
      return;
   }
   else
   {
      int mid = (a+b)>>1;
      if(index<=mid)
      { 
         update(2*node,a,mid,val,index);
      }
      else
      {
         update(2*node+1,mid+1,b,val,index);
      }
      tree[node].sum=tree[2*node].sum + tree[2*node+1].sum;
   }  
}
 
T query(int node,int i,int j,int a,int b)
{
  if(a<=i && b>=j)
  {
    return tree[node];
  }
  int mid=(i+j)>>1;
  T p1,p2,p3;
  if(b<=mid)
  {
    return query(2*node,i,mid,a,b);         
  }
  else if(a>mid)
  {
    return query(2*node+1,mid+1,j,a,b);         
  }
  else
  {
     p1=query(2*node,i,mid,a,b);
     p2=query(2*node+1,mid+1,j,a,b);
     p3.sum=p1.sum + p2.sum;
     return p3;
  }
}
 
int main()
{
  int n,q;
  char str[5];
  scanf("%d %d",&n,&q);
  for(int i=1;i<=n;i++)
  {
    arr[i]=0;        
  }    
  build(1,1,n);
  for(int j=0;j<q;j++)
  {
    
    int a,b;
    scanf("%s %d %d",str,&a,&b);
    if(str[0]=='f')
    {
       
      printf("%lld\n",query(1,1,n,a,b).sum);  
    }      
    else
    {
        update(1,1,n,b,a); 
    }   
  }
  return 0;
}