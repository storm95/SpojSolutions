#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define sz 50005
#define P pair<int,int>
#define fs first
#define sd second

using namespace std;
int sm[2005][2005],ct[2005],ar[2005],dp[2005][2005];
int main()
{
    int n,m,q,k,i,j,r1,r2,c1,c2,x;
    sfd(n);
    sfd(m);
    sfd(q);
    sfd(k);

    for(i=0;i<=n;i++)
    {
      for(j=0;j<=m;j++)
        {
            if(i==0||j==0)
                sm[i][j]=0;
            else
            {
                sfd(x);
                sm[i][j]=x+sm[i][j-1]+sm[i-1][j]-sm[i-1][j-1];
            }
        }
    }
    for(i=1;i<=q;i++)
    {
        sfd(r1);
        sfd(c1);
        sfd(r2);
        sfd(c2);
        ct[i]=sm[r2][c2]-sm[r1-1][c2]-sm[r2][c1-1]+sm[r1-1][c1-1];
        ar[i]=(r2-r1+1)*(c2-c1+1);
    }
    for(i=0;i<=q;i++)
    {
        for(j=0;j<=k;j++)
        {
            if(i==0||j==0)
                dp[i][j]=0;
            else if(j-ct[i]>=0)
              dp[i][j]=max(dp[i-1][j],dp[i-1][j-ct[i]]+ar[i]);
            else
               dp[i][j]= dp[i-1][j];
        }
    }
    pfd(dp[q][k]);
    return 0;
}
