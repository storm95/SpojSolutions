#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios_base::sync_with_stdio(0);
	int tc,n,k,minimum;
	cin>>tc;
	assert(tc<=30);
	while(tc--)
	{
		cin>>n>>k;
		minimum = 1000000009;
		assert(n<=20000 && k<=20000);
		int arr[n];
		for(int i=0;i<n;i++)
		  cin>>arr[i];
		sort(arr,arr+n);
		for(int i=0;i<=n-k;i++)
		  minimum = min(minimum,arr[i+k-1]-arr[i]);
		cout<<minimum<<"\n";
	}
}