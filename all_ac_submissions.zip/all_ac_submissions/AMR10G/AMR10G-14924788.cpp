#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;
ll a[20005];
int main() {
    int t,n,k,i,lw,hi;
    ll ans;
    sfd(t);
    while(t--)
    {
      sfd(n);
      sfd(k);
      for(i=0;i<n;i++)
      {
        sflld(a[i]);
      }
      ans=1000000005;
      sort(a,a+n);
      lw=0;
      hi=k-1;
      //cout<<hi<<endl;
      while(hi<n)
      {
        ans=min(ans,a[hi]-a[lw]);
        hi++;
        lw++;
      }
      pflld(ans);
    }
    
	return 0;
}