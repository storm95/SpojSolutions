#include<bits/stdc++.h>
#define lli long long int
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    int test;
    cin>>test;
    while(test--)
    {
        int n,k;
        cin>>n>>k;
        int ay,ans=1000000009,temp;
        vector<int>arr;
        for(int i=0;i<n;i++)
        {

            cin>>ay;
            arr.push_back(ay);
        }
        sort(arr.begin(),arr.end());
        for(int i=0;i<=(n-k);i++)
        {
            temp=arr[i+k-1]-arr[i];
            ans=min(ans,temp);
        }

        cout<<ans<<endl;
    }
    return 0;
}
