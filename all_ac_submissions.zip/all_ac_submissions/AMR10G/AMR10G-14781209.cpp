#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tc,n,k;
    int arr[30007];
    scanf("%d",&tc);
    while(tc--)
    {
        scanf("%d%d",&n,&k);
        for(int i=0;i<n;i++)
        {
            scanf("%d",&arr[i]);
        }
        sort(arr,arr+n);
        long long int mini = 1000000102;
        for(int i=0;i<=n-k;i++)
        {
            int diff = arr[i+k-1] - arr[i];
            if(mini>diff) mini = diff;
        }
        printf("%lld\n",mini);
    }
    return 0;
}
