#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int arr[20000];
int main()
{
    int t,n,k,i,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&k);
        for(i=0;i<n;++i)
        scanf("%d",&arr[i]);
        sort(arr,arr+n);
        int mini=1000000000;
        for(i=0;(i+k-1)<n;++i)
        if(mini>(arr[i+k-1]-arr[i]))
        mini=arr[i+k-1]-arr[i];
        printf("%d\n",mini);
        if(n<k)
        mini=arr[n-1]-arr[0];
    }
    return 0;
}
