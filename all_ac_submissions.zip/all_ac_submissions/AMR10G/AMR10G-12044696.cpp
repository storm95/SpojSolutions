#include<bits/stdc++.h>
using namespace std;
int main()
{
	int tc,n,k;
	cin>>tc;
	while(tc--)
	{
		cin>>n>>k;
		int arr[n],ans = 1e9;
		for(int i=0;i<n;i++) cin>>arr[i];
		sort(arr,arr+n);
		for(int i=0;i<=(n-k);i++)
		ans = min(ans,arr[i+k-1]-arr[i]);
		cout<<ans<<"\n";
	}
	return 0;
}