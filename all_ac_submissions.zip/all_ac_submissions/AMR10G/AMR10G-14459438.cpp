#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,k;
        scanf("%d%d",&n,&k);
        int a[n];
        for(int i=0;i<n;i++) scanf("%d",&a[i]);
        sort(a,a+n);
        int mn=INT_MAX;
        for(int i=0;i<=n-k;i++)
        {
            mn=min(mn,a[k+i-1]-a[i]);
        }
        printf("%d\n",mn);
    }
}