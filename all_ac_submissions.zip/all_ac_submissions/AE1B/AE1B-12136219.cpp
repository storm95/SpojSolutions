#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
        long long int n,k,s;
        scanf("%lld%lld%lld",&n,&k,&s);
        long long int i,j,arr[n];
        for(i=0;i<n;++i)
        scanf("%lld",&arr[i]);
        long long int x=k*s,y=0;
        sort(arr,arr+n);
        for(i=n-1;i>=0;--i)
        {
                y+=arr[i];
                if(y>=x)
                break;
        }
        printf("%lld",n-i);
        return 0;

}
