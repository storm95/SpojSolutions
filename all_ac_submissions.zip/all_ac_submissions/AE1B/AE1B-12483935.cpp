#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int main()
{
    int n,k,s,req,arr[100000],i,counter=0;
    scanf("%d %d %d",&n,&k,&s);
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);
    sort(arr,arr+n);
    req=k*s;
    for(i=n-1;i>=0;i--)
    {
        if(req<=0)
            break;
        else
        {
            req-=arr[i];
            counter++;
        }
    }
    printf("%d\n",counter);
    return 0;
}
