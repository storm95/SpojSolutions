#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    while(n!=0)
    {
        int m,a[11000],b[11000],c[11000],d[11000],i,j,k=0,l=0,x=0,y=0,sum=0;
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    scanf("%d",&m);
    for(i=0;i<m;i++)
        scanf("%d",&b[i]);
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
            if(a[i]==b[j])
            {
                c[k]=i;
                k++;
                d[l]=j;
                l++;
            }
    c[k]=n-1;
    d[l]=m-1;
    n=0;
    m=0;
    for(i=0;i<=k;i++)
    {
        while(n<=c[i])
        {
            x+=a[n];
            n++;
        }
        while(m<=d[i])
        {
            y+=b[m];
            m++;
        }
        sum+=(x>y)?x:y;
        x=0;
        y=0;
    }
    printf("%d\n",sum);
    scanf("%d",&n);
    }
    return 0;
}
