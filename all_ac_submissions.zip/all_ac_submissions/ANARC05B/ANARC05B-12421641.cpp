#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int m,n,a[100000],b[100000],s1,s2,s,k,i,j;
    cin>>m;
    while(m!=0)
    {
        s=0;
        for(i=0;i<m;i++)
            cin>>a[i];
        cin>>n;
        for(i=0;i<n;i++)
            cin>>b[i];
            sort(a,a+m);
            sort(b,b+n);
            s1=0;
            s2=0;
            s=0;
            i=0;
            j=0;
         while(i<m&&j<n)
         {
             if(a[i]<b[j]&&i<m)
             {
                 s1+=a[i];
                 i++;
             }
             else if(a[i]>b[j]&&j<n)
             {
                 s2+=b[j];
                 j++;
             }
             else if(a[i]==b[j]&&i<m&&j<n)
             {
                 s1+=a[i];
                 s2+=b[j];
                 s+=max(s1,s2);
                 s1=0;
                 s2=0;
                 i++;j++;
             }

         }
         while(i<m)
         {
             s1+=a[i];
             i++;
         }
          while(j<n)
         {
             s2+=b[j];
             j++;
         }
         s+=max(s1,s2);
            cout<<s<<endl;
            cin>>m;
    }

    return 0;
}
