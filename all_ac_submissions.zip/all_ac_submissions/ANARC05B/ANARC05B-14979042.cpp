#include<bits/stdc++.h>
using namespace std;
int a[10001];
int b[10001];
int main()
{
    while(1)
    {
        int n,m;
        scanf("%d",&n);
        if(n==0) break;
        for(int i=0;i<n;i++) scanf("%d",&a[i]);
        scanf("%d",&m);
        for(int i=0;i<m;i++) scanf("%d",&b[i]);
        int ans=0;
        int al=0;
        int bl=0;
        int i=0,j=0;
        while(i<n && j<m)
        {
            if(a[i]>b[j])
            {
                bl+=b[j];
                j++;
            }
            else if(a[i]<b[j])
            {
                al+=a[i];
                i++;
            }
            else
            {
                ans+=max(al,bl)+a[i];
                al=0;
                bl=0;
                i++;
                j++;
            }
        }
        while(i<n)al+=a[i++];
        while(j<m) bl+=b[j++];
        ans+=max(al,bl);
        printf("%d\n",ans);

    }

return 0;
}
