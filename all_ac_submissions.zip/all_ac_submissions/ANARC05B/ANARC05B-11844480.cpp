#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int i,j,k,no1,no2,sum1,sum2,sum,arr1[10009],arr2[10009];
    scanf("%d",&no1);
    while(no1!=0)
    {
        for(i=0;i<no1;i++)
            scanf("%d",&arr1[i]);
        scanf("%d",&no2);
        for(i=0;i<no2;i++)
            scanf("%d",&arr2[i]);
        i=j=sum=sum1=sum2=0;
        while(1)
        {
            if(i==no1 && j==no2)
                break;
            if(i<no1 && j<no2)
            {
                if(arr1[i]==arr2[j])
                {
                    sum+=max(sum1,sum2);
                    //printf("sum= %d\n",sum);
                    sum+=arr1[i];
                    //printf("sum= %d\n",sum);
                    sum1=sum2=0;
                    ++i;++j;
                }
                else
                {
                    if(arr1[i]<arr2[j])
                    {
                        sum1+=arr1[i];
                        ++i;
                    }
                    else
                    {
                        sum2+=arr2[j];
                        ++j;
                    }
                }
            }
            else if(i<no1)
            {
                sum1+=arr1[i];
                ++i;
            }
            else
            {
                sum2+=arr2[j];
                ++j;
            }
        }
        sum+=max(sum1,sum2);
        printf("%d\n",sum);
        scanf("%d",&no1);
    }
    return 0;
}
