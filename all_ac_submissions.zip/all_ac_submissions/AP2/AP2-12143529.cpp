#include <iostream>

using namespace std;

int main()
{
    long long int t,x,y,z,a,d,n,i;
    cin>>t;
    while(t--)
    {
        cin>>x>>y>>z;
        n=(2*z)/(x+y);

        d=(y-x)/(n-5);
        a=x-(2*d);
        cout<<n<<endl;
        for(i=1;i<=n;i++)
            cout<<a+((i-1)*d)<<" ";
        cout<<endl;
    }
    return 0;
}
