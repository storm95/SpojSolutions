#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long int a3,l2,sum,i,n,d,a;
    int t;
    scanf("%d",&t);
    while(t>0)
    {
        sum=0;
        scanf("%lld %lld %lld",&a3,&l2,&sum);
        n=(sum*2)/(a3+l2);
        printf("%lld\n",n);
        d=(l2-a3)/(n-5);
        a=(a3-2*d);

        for(i=0;i<n;i++)
        {
            printf("%lld ",a+i*d);
        }
        printf("\n");
        t--;


    }
    return 0;
}
