#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long int a,b,s,l,d,n,i;
        scanf("%lld %lld %lld",&a,&b,&s);
        n=2*s/(a+b);
        d=(b-a)/(n-5);
        l=(a-2*d);
        printf("%lld\n",n);
        printf("%lld ",l);
        for(i=1;i<n;i++)
        {
            l+=d;
            printf("%lld ",l);
        }
        printf("\n");
    }
    return 0;
}
