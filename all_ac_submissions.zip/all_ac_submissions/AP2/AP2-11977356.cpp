//AP - complete the series
#include<iostream>
#include<cstdio>
int main()
{
        int t;
        long long a,d,x,y,z,i,n;
        scanf("%d",&t);
        while(t--)
        {
                scanf("%lld%lld%lld",&x,&y,&z);
                n=(2*z)/(x+y);
                d=(y-x)/(n-5);
                a=x-2*d;
                printf("%d\n",n);
                for(i=0;i<n;i++)
                {
                        printf("%d ",a);
                        a+=d;
                }
        }
        return 0;
}

