#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define P pair<int,int>

using namespace std;
int sz[501],m,k;
bool chck(ll s)
{
    ll t=0;
    int ct=1,i;
    for(i=0;i<m;i++)
    {
        if(sz[i]>s)
        {
            ct=1000000;
            break;
        }
        if(t+sz[i]>s)
        {
            ct++;
            t=0;
        }
        t+=sz[i];
    }
    return ct<=k;
}
int print(int idx,ll s,int tk)
{
    ll t=0;
    int i;
    for(i=idx;i>=0;i--)
    {
        if(t+sz[i]>s||i+1==tk-1)
        {
            print(i,s,tk-1);
            break;
        }
        t+=sz[i];
    }
    if(i>=0)
         printf("/ ");
    for(i++;i<=idx;i++) {
      printf("%d ",sz[i]);
  }
}
int main()
{
    int t,n,i,j;
    ll sm=0,avg,l,r,mid;
    sfd(t);
    while(t--)
    {
        sm=0;
        sfd(m);
        sfd(k);
        for(i=0;i<m;i++)
           {
               sfd(sz[i]);
               sm+=sz[i];
           }
       l=0;
       r=sm;
       while(l<r)
       {
          // cout<<"as";
           mid=(l+r)/2LL;
           if(chck(mid)==true)
            r=mid;
           else
            l=mid+1;
       }
    print(m-1,r,k);

        printf("\n");
       // printf("\n");
    }
    return 0;
}
