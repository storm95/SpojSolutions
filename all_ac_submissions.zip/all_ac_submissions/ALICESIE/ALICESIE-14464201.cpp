#include<bits/stdc++.h>
#include<algorithm>
using namespace std;

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int ans=n-(n/2);
        printf("%d\n",ans);
    }
    return 0;
}
