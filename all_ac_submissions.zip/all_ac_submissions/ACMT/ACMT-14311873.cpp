#include<iostream>
#include<cstdio>
using namespace std;
int sol(int ex,int nob)
{
    int sum=0;
   while(1)
   {
       if(ex<=1)
        {
            if(ex==1 && nob>=2) sum++;
        break;
        }
        else if(ex==nob){
            ex=ex-2;
            nob=nob-1;
            sum++;
        }
        else
        {
            ex=ex-1;
            nob=nob-2;
            sum++;
        }
   }
   return sum;
}

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int ex,nob;
        scanf("%d %d",&ex,&nob);
        int m=ex+nob;
        ex=min(ex,nob);
        nob=m-ex;
        int ans=sol(ex,nob);
        printf("%d\n",ans);
    }
    return 0;
}
