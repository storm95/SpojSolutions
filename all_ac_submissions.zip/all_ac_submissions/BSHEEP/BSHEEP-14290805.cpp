#include<bits/stdc++.h>
using namespace std;
typedef struct 
{
	long long  x,y;
	long long  order;
}point;
point p[100010];
long long  n;
long long  stck[100010],top;
bool deleted[100010];
long long  area2(point  a,point b,point c)
{
	return (b.x-a.x)*(c.y-b.y)-(c.x-b.x)*(b.y-a.y);
}
int cmp(const void* ai,const void* bi)
{
	point a = *((point*) ai);
	point b = *((point*) bi);
	point c = p[0];
	long long area = area2(c,a,b);
	if(area>0)
		return -1;
	if(area<0)
		return 1;

	long long x = abs(a.x-c.x)-abs(b.x-c.x);
	long long y = abs(a.y-c.y)-abs(b.y-c.y);

	if((x<0)||(y<0))
	{
		deleted[a.order]=true;
		return -1;
	}
	else if((x>0)||(y>0))
	{
		deleted[b.order]=true;
		return 1;
	}
	else
	{
		if(a.order<b.order)
			deleted[b.order]=true;
		else deleted[a.order]=true;
		return 0;
	}
}
void graham()
{
	if(n==1)
	{
		top=1;
		stck[0]=0;
		return ;
	}
	long long  lowest=0;
	for(long long  i=0;i<n;++i)
	{
		if(p[i].y<p[lowest].y || (p[i].y==p[lowest].y&&p[i].x<p[lowest].x)||(p[i].y==p[lowest].y&&p[i].x==p[lowest].x&&p[i].order<p[lowest].order))
			lowest=i;
	}
	point myp;
	myp=p[0];
	p[0]=p[lowest];
	p[lowest]=myp;
	/*for(int i=0;i<n;++i)
	{
		printf("%lld %lld %lld %d\n",p[i].x,p[i].y,p[i].order,deleted[p[i].order]);
	}*/
	qsort(&p[1],n-1,sizeof(point),cmp);
	/*printf("after\n");
	for(int i=0;i<n;++i)
	{
		printf("%lld %lld %lld %d\n",p[i].x,p[i].y,p[i].order,deleted[p[i].order]);
	}*/
	stck[0]=0;
	long long  i;
	for(i=1;i<n;++i)
		if(!deleted[p[i].order])
			break;
	stck[1]=i;
	top=2;
	++i;
	while(i<n)
	{

		if(deleted[p[i].order])
		{
			++i;continue;
		}
		if(area2(p[stck[top-2]],p[stck[top-1]],p[i])>0)
		{
			stck[top]=i;
			++top;
			++i;
		}
		else --top;
		
	}
	return ;
}
double dist(point a,point b)
{
	return sqrt( (b.x-a.x)*(b.x-a.x)+(b.y-a.y)*(b.y-a.y) );
}
int main()
{
	long long  t;
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld",&n);
		for(long long  i=0;i<n;++i)
		{
			scanf("%lld%lld",&p[i].x,&p[i].y);
			p[i].order=i;
			deleted[i]=false;
		}
		graham();
		double ans=0;
		for(long long i=0;i<top;++i)
		{
			ans+=dist(p[stck[i]],p[stck[(i+1)%top]]);
		}
		printf("%.2lf\n", ans);
		for(long long  i=0;i<top;++i)
			printf("%lld ",p[stck[i]].order+1 );
		printf("\n\n");
	}
	return 0;
}
/*
8
5
0 0
0 5
10 5
3 3
10 0

1
0 0

3
0 0
1 0
2 0

4
0 0
0 0
0 1
1 0

3
0 0
0 1
1 0

6
0 0
-1 -1
1 1 
2 2
3 3
4 4

2
10 0
0 0

7
-3 -4
2 -3
4 3
-4 2
0 5
2 -3
-1 4
*/