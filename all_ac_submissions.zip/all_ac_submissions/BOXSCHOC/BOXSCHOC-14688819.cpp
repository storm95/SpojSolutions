#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)
#define lt 2*idx
#define rt 2*idx+1

using namespace std;
set<int>s[100002];
int main()
{

    int n,a,b,k,t,i,cs=1,ans,q,v,j;
    sfd(t);
    while(t--)
    {
        sfd(n);
         for(i=1;i<=n;i++)
            s[i].clear();
        for(i=1;i<=n;i++)
        {
            sfd(v);
            for(j=1;j<=sqrt(v);j++)
            {
                if(v%j==0)
                {
                    s[j].insert(i);
                    s[v/j].insert(i);
                }
            }
        }
        printf("Case %d:\n",cs);
        cs++;
        sfd(q);
        while(q--)
        {
            sfd(a);
            sfd(b);
            sfd(k);
            ans=0;
            for(set<int>::iterator it=s[k].begin();*it<=b&&it!=s[k].end();it++)
            {
                //cout<<*it<<" ";
                if(*it>=a)
                    ans++;
            }

            pfd(ans);
        }
    }
    return 0;
}
