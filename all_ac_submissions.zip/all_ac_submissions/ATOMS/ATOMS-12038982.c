#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t;
   long long int k,n,m,i;
   scanf("%d",&t);
   while(t--)
   {
       scanf("%lld%lld%lld",&n,&k,&m);
       i=0;
       while(k<=m/n)
       {
           n=n*k;
           i++;
       }

       printf("%lld\n",i);
   }

    return 0;
}
