#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long n,k,m;
        scanf("%lld%lld%lld",&n,&k,&m);
        int ans=0;
        while(n<=m)
        {
            long long x=m/n;
            if(x<k) break;
            n=n*k;
            ans++;
        }
        printf("%d\n",ans);
    }
    return 0;
}
