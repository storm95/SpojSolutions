#include<iostream>
#include<cstdio>
#include<string>
#include<vector>
using namespace std;
/*unsigned long long gcd(unsigned long long a,unsigned long long b)
{
	if(b==0)
	return a;
	return gcd(b,a%b);
}*/
vector<long long int> v;
char ch;
int main()
{
	long long i,j;
	unsigned long long m,n,x,k;
	unsigned long long a,b,gc;
	while(scanf("%llu%llu",&m,&n)!=EOF&&(m!=0||n!=0))
	{
		k=0;
		v.clear();
		scanf("%c",&ch);
		for(i=0;i<m;++i)
		{
			x=0;
			if(i%2)
			{
				while((scanf("%c",&ch)!=EOF)&&ch!='\n')
				{
					if(ch>='0'&&ch<='9')
					x=x*10+ch-'0';
				}
					v.push_back(x);
					++k;
			}
			else {while(scanf("%c",&ch)!=EOF&&ch!='\n') ;}
		}
		a=b=1;
		for(i=k-1;i>=0;--i)
		{
			a=b*v[i]+a;
			unsigned long long z=a;a=b;b=z;
		}
		printf("%llu %llu\n",b,a);
	}
	return 0;
}