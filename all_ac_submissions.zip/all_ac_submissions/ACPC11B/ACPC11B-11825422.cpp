#include <iostream>

using namespace std;

int mod(int x)
{
    if (x*1>0)
        return x;
    else return -x;

}
int main()
{
    int t,m,n,i,j,k,p;
    long long int a[1005],b[1005],mini,s;
    cin>>t;
    while(t>0)
    {
        mini=1000000,s=0;
        cin>>m;
        for(i=0;i<m;i++)
        {
            cin>>a[i];
        }
        cin>>n;
        for(p=0;p<n;p++)
        {
            cin>>b[p];
        }
        for(j=0;j<m;j++)
        {
            for(k=0;k<n;k++)
              {
                  s=mod(a[j]-b[k]);
                  if(mini>s)
                  mini=s;
              }
        }
        cout<<mini<<endl;

        t--;

    }
    return 0;
}
