#include<bits/stdc++.h>
using namespace std;
int a[10000];
int b[10000];
int main()
{
	int t;
	int n,m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(int i=0;i<n;++i)
			scanf("%d",&a[i]);
		scanf("%d",&m);
		for(int i=0;i<m;++i)
			scanf("%d",&b[i]);

		sort(a,a+n);
		sort(b,b+m);
		int i=0,j=0;
		int ans = INT_MAX;
		while(i<n&&j<m)
		{
			if(a[i]<b[j])
			{
				ans = min(ans,b[j]-a[i]);
				++i;
			}
			else
			{
				ans = min(ans,-b[j]+a[i]);
				++j;
			}
		}
		printf("%d\n",ans );
	}
	return 0;
}