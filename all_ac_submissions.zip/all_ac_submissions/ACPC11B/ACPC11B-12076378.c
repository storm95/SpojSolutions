#include<stdio.h>
#include<stdlib.h>
int main()
{
    int test;
    scanf("%d",&test);
    while(test--)
    {
        int n,m,a[100000],b[100000],i,temp=1000000000,x,j;
        scanf("%d",&n);
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        scanf("%d",&m);
        for(i=0;i<m;i++)
            scanf("%d",&b[i]);
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                x=abs(a[i]-b[j]);
                if(x<temp)
                    temp=x;
            }
        }
        printf("%d\n",temp);
    }
    return 0;
}
