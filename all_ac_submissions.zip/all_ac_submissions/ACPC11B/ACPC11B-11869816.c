#include<stdio.h>
#include<math.h>
#define gc getchar_unlocked
inline int inp()
{
    int n = 0, c = gc(), f = 1;
    while(c != '-' && (c < '0' || c > '9')) c = gc();
        if(c == '-')
        {
            f = -1;
            c = gc();
        }
    while(c >= '0' && c <= '9')
        n = (n<<3) + (n<<1) + c - '0', c = gc();
    return n * f;
}
int main()
{
    int tc,N,M,i,j,min = 1000000009,n[1005],m[1005];
    tc = inp();
    while(tc--)
    {
        min = 1000000009;
        N = inp();
        for(i=0;i<N;i++)
            n[i] = inp();
        M = inp();
        for(i=0;i<M;i++)
        {
            m[i] = inp();
            for(j=0;j<N;j++)
                if (abs(m[i]-n[j]) < min) 
                    min = abs(m[i]-n[j]);
        }
        printf("%d\n",min);
    }
    return 0;
}