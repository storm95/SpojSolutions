#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tc,n,arr[100000],m,brr[100000];
    scanf("%d",&tc);
    while(tc--)
    {
        int c[1000][1000];
        int mn;
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            scanf("%d",&arr[i]);
        scanf("%d",&m);
        for(int j=0;j<m;j++)
            scanf("%d",&brr[j]);
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {
                    c[i][j]=abs(arr[i]-brr[j]);
                }
            }
        mn=c[0][0];
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(c[i][j]<mn)
                    mn=c[i][j];
            }
        }
        printf("%d\n",mn);
    }
    return 0;
}


