/*
  A.SANDEEP
  1st Year CSE
  BIT MESRA
  PROGRAMMING LANGUAGE ---> C++
*/
#include<bits/stdc++.h>
using namespace std;
//......Definitions
#define mod 1000000007
#define set0(x) memset(x,0,sizeof(x)) //...For making all elements of an array 0
#define set1(x) memset(x,1,sizeof(x))
#define set-1(x) memset(x,-1,sizeof(x))
#define s2i(x,y) scanf("%d %d",&x,&y)
#define s3i(x,y,z) scanf("%d %d %d",&x,&y,&z)
#define s4i(x,y,z,k) scanf("%d %d %d %d",&x,&y,&z,&k)
#define s2lli(x,y) scanf("%lld %lld",&x,&y)
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define slli(x) scanf("%lld",&x)
#define pi(x) printf("%d\n",x)
#define pc(x) printf("%c",x)
#define plli(x) printf("%lld",x)
#define p2lli(x,y) printf("%lld %lld",x,y)
#define p2i(x,y) printf("%d %d",x,y)
#define MAX(a,b) ((a)>(b))? (a):(b)
#define MAX3(a,b,c) MAX(a,MAX(b,c))
#define MIN(a,b) ((a)<(b))? (a):(b)
#define MIN3(a,b,c) MIN(a,MIN(b,c))
#define loop(i,start,comp) for(i=start;i<comp;i++)
#define ll long long int
#define fastcpp ios_base::sync_with_stdio(false)
#define unsigned long long int ull
#define input int tc;scanf("%d",&tc);while(tc--)
//...Main code Begins Here
int main()
{
    int T,t,N,M,i,j,min = 1000000009;
    int n[1005];
    int m[1005];
    input{
        min = 1000000009;
        si(N);
        loop(i,0,N)
            si(n[i]);
        si(M);
        loop(i,0,M)
        {
            si(m[i]);
             loop(j,0,N)
                if (abs(m[i]-n[j]) < min)
                    min = abs(m[i]-n[j]);
        }
        printf("%d\n",min);
    }
    return 0;
}
