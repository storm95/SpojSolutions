#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int a[n];
        for(int i=0;i<n;i++) scanf("%d",&a[i]);
        sort(a,a+n);
        int m;
        scanf("%d",&m);
        int b[m];
        for(int i=0;i<m;i++) scanf("%d",&b[i]);
        sort(b,b+m);
        int i=0,j=0;
        int ans=INT_MAX;
        while(i<n && j<m)
        {
            if(a[i]>b[j])
            {
                ans=min(ans,a[i]-b[j]);
                j++;
            }
            else if(b[j]>a[i])
            {
                ans=min(ans,b[j]-a[i]);
                i++;
            }
            else
            {
                ans=0;
                break;
            }
        }
        printf("%d\n",ans);
    }
}
