#include <stdio.h>
#include <stdlib.h>

int mod(int x)
{
    if (x*1>0)
        return x;
    else return -x;

}
int main()
{
    int t,m,n,i,j,k,p;
    long long int a[1005],b[1005],mini,s;
    scanf("%d",&t);
    while(t>0)
    {
        mini=1000000,s=0;
        scanf("%d",&m);
        for(i=0;i<m;i++)
        {
            scanf("%lld",&a[i]);
        }
        scanf("%d",&n);
        for(p=0;p<n;p++)
        {
            scanf("%lld",&b[p]);
        }
        for(j=0;j<m;j++)
        {
            for(k=0;k<n;k++)
              {
                  s=mod(a[j]-b[k]);
                  if(mini>s)
                  mini=s;
              }
        }
        printf("%lld\n",mini);

        t--;

    }
    return 0;
}
