#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m,i,j,l,x=0,y=0,k=0;
	string s;
	while(cin>>s&&s[0]!='-')
	{
		++k;
		int len=s.size();x=y=0;
		for(i=0;i<len;++i)
		{
			if(s[i]=='{')
			{
				++x;
			}
			else
			{
				if(x>0) --x; else ++y;
			}
		}
		int ans=0;
		ans+=x/2;
		x%=2;
		ans+=y/2;y%=2;
		if(x)
		ans+=2;
		cout<<k<<". "<<ans<<"\n";
	}
	return 0;
}
