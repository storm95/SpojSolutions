#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int t,n,m,i,j,len,x,y,c;
    char str[2010],arr[2010];
    scanf("%s",&str);t=1;
    while(str[0]!='-')
    {
        stack<char> s;
        len=strlen(str);
        s.push(str[0]);
        for(i=1;i<len;i++)
        {
            if(str[i]=='}')
            {
                if(s.empty()==0)
                {if(s.top()=='{')
                    {
                        s.pop();
                        continue;
                    }
                }
                    s.push(str[i]);
            }
            else
                s.push(str[i]);
        }
        c=0;len=s.size();
        for(i=len-1;(i>=0);i--)
        {
            arr[i]=s.top();
            s.pop();
        }
        for(i=0;i<len;i+=2)
        {
            if(arr[i]==arr[i+1])
                ++c;
            else
                c+=2;
        }
        printf("%d. %d\n",t,c);
        ++t;
        scanf("%s",&str);
    }
    return 0;
}
