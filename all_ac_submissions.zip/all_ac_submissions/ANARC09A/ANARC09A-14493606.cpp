#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    string s;
    int r,l,i,cs=1,ln;
    cin>>s;
    while(s.at(0)!='-')
    {
        ln=s.length();
        l=0;
        r=0;
        int ct=0;
        for(i=0;i<ln;i++)
        {
            if(s.at(i)=='{')
                r++;
            else
                l++;
            if(l>r)
            {
                l--;
                r++;
                ct++;
            }
        }
        ct+=(r-l)/2;
        cout<<cs<<". "<<ct<<endl;
        cs++;
        cin>>s;
    }
    return 0;
}
