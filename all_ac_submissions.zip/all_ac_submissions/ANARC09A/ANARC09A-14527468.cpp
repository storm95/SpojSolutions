#include<bits/stdc++.h>
using namespace std;
int dp[2004][1002];
int n;
char s[2004];
int solve(int i,int c)
{
    if(c<0 || c>n/2) return 1e9;
    if(i==n)
    {
        if(c==0) return 0;
        return 1e9;
    }
    if(dp[i][c]!=-1) return dp[i][c];
    if(s[i]=='{')
    {
        dp[i][c]=min(solve(i+1,c+1),1+solve(i+1,c-1));
        return dp[i][c];
    }
    if(s[i]=='}')
    {
        dp[i][c]=min(solve(i+1,c-1),1+solve(i+1,c+1));
        return dp[i][c];
    }
}
int main()
{
    int t=0;
    while(1)
    {
        scanf("%s",s);
        if(s[0]=='-') return 0;
        n=strlen(s);
        t++;
        memset(dp,-1,sizeof(dp));
        printf("%d. %d\n",t,solve(0,0));
        printf("\r");
    }
    return 0;
}
