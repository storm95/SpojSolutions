#include<iostream>
#include<math.h>
#include<cstring>
#include<string>
#include<algorithm>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

typedef long long ll;
typedef long l;

#define max 64
using namespace std;
int f(ll n, int bits[max])
{
    int index = 0;
    while(n)
    {
        bits[index++]=n%2;
        n=n/2;
    }
    return index;

}
int main()
{
    ll n;
    while(1)
    {
        scanf("%lld", &n);
        if(n==-1)
            break;
        int arr[max];
        int count = f(n,arr);
        ll total = 0;
        for(int i=count-1;i>=0;--i)
        {
            total+= pow(2,(count-1)-i)*arr[i];
        }
        printf("%lld\n",total);
    }
    return 0;
}
 