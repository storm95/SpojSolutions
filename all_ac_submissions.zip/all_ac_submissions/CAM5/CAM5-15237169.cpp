#include <bits/stdc++.h>
#define mp make_pair
using namespace std;
bool mark[100005];
vector<int> v[100005];
void solve(int s)
{
    mark[s]=false;
    queue<int > que;
    que.push(s);
    while(!que.empty())
    {
        int x=que.front();
        que.pop();
        int sz=v[x].size();
        for(int i=0;i<sz;i++)
        {
            int y=v[x][i];
            if(mark[y])
            {
                mark[y]=false;
                que.push(y);
            }
        }
    }
}
int main()
{
    int t;scanf("%d",&t);
    while(t--)
    {
        for(int i=0;i<100005;i++) v[i].clear();
        int n,e;
        scanf("%d%d",&n,&e);
        memset(mark,true,sizeof(mark));
        for(int i=0;i<e;i++)
        {
            int a,b;
            scanf("%d%d",&a,&b);
            v[a].push_back(b);
            v[b].push_back(a);
        }
        int ans=0;
        for(int i=0;i<n;i++)
        {
            if(mark[i])
            {
                ans++;
                solve(i);
            }
        }
        printf("%d\n",ans);
    }

    return 0;
}
