#include<bits/stdc++.h>
#define lli long long int
using namespace std;
int vis[1000005];
int main()
{
    ios::sync_with_stdio(false);
    int test;
    cin>>test;
    while(test--)
    {
        int v,e,a,b;
        cin>>v>>e;
        vector<int>adj[v];
        for(int i=0;i<e;i++)
        {
            cin>>a>>b;
            adj[a].push_back(b);
            adj[b].push_back(a);
        }
        int ans=0;
        fill(vis,vis+v,0);
        for(int i=0;i<v;i++)
        {
            if(vis[i]==0)
            {
                a=i;
            }
            else
                continue;
            queue<int>myq;
            myq.push(a);
            while(!myq.empty())
            {
                a=myq.front();
                vis[a]=1;
                myq.pop();
                for(int j=0;j<adj[a].size();j++)
                {
                    if(vis[adj[a][j]]==0)
                        myq.push(adj[a][j]);
                }
            }
            ans++;
        }
        cout<<ans<<endl;
    }
    return 0;
}
