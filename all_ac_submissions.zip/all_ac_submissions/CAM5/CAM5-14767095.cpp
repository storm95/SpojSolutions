#include<bits/stdc++.h>
using namespace std;
int c=0;
vector<vector<int> > v(100012);
int visited[100012];
void dfs(int x)
{
    if(visited[x]==0)
    {
        visited[x]=1;
        int s = v[x].size();
        for(int i=0;i<s;++i)
            dfs(v[x][i]);
    }
    else return ;
}

int main()
{
    int tc,n,m,x,y;
    scanf("%d",&tc);
    while(tc--)
    {
        c=0;
        scanf("%d%d",&n,&m);
        for(int i=0;i<=n;i++)
            v[i].clear();
        memset(visited,0,sizeof(visited));
        for(int i=0;i<m;i++)
        {
            scanf("%d%d",&x,&y);
            v[x].push_back(y);
            v[y].push_back(x);
        }
        for(int i=0;i<n;i++)
        {
            if(!visited[i])
            {
                c++;
                dfs(i);
            }
        }
        printf("%d\n",c);
    }
    return 0;
}
