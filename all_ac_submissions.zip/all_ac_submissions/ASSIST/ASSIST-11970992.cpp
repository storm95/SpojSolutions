#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<stack>
#include<queue>
#define tr(type,it,s) for(type<int>::iterator it=s.begin();it!=s.end();it++)
#define ft float
#define sg string
#define de double
#define llit long long int
#define ss stringstream
#define pr(type1,type2) pair<type1,type2>
#define vtr vector
#define vr(type) vector< type >
#define ivr vector<int>
#define all(s) (s).begin(),(s).end()
#define fstmp(s,z) (s).find(z)!=(s).end()
#define fvr(s,z) find(all(s),z)!=(s).end()
#define ipr pair<int,int>
#define qe(type) queue<type>
#define qi queue<int>
using namespace std;
int main()
{
    int t,i,j,n,a,b,c;
    int arr[2][33820];
    for(i=2;i<33820;i++)
    {
        arr[0][i]=i-1;
        arr[1][i]=i+1;
    }
    c=2;n=0;
    while(n<=3001)
    {
        a=0;
        ++n;
        for(i=c;i<33820;i=arr[1][i])
        {
            ++a;
            if(a==c+1)
            {
                //if(i==31)
                  //  printf("c=  %d\n",c);
                arr[1][arr[0][i]]=arr[1][i];
                arr[0][arr[1][i]]=arr[0][i];
                a=1;
            }
        }
        c=arr[1][c];
    }
    vector<int> v;n=0;
    for(i=2;n<3002;i=arr[1][i])
    {
        ++n;
        v.push_back(i);
    }
    while(1)
    {
        scanf("%d",&b);
        if(b==0)
            break;
        printf("%d\n",v[b-1]);
    }
    return 0;
}






