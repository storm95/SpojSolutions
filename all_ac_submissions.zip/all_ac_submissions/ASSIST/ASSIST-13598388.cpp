#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> v;
	//vector<int> :: iterator it;
	int i,j,k,n;
	for(i=2;i<34000;++i)
		v.push_back(i);
	int count=34000-2;
	for(i=0;i<count;++i)
	{
		
		int x=v[i];
		
		for(j=i+x;j<count;j=j+x-1)
		{
			--count;
			v.erase(v.begin()+j);
			
		}
	}
	while(cin>>n&&n!=0)
		cout<<v[n-1]<<"\n";
	return 0;
}