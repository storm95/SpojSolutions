#include <bits/stdc++.h>
#define sflld(n) scanf("%lld",&n)
#define sfulld(n) scanf("%llu",&n)
#define sfd(n) scanf("%d",&n)
#define sfld(n) scanf("%ld",&n)
#define sfs(n) scanf("%s",&n)
#define ll long long
#define ull unsigned long long int
#define pflld(n) printf("%lld\n",n)
#define pfd(n) printf("%d\n",n)
#define pfld(n) printf("%ld\n",n)

using namespace std;

int main()
{
    int N,n,i,j,a,b,c;
    sfd(N);
    while(N!=0)
    {
    n=6*N;
    int x[n],y[n],z[n],dp[n];
    for(i=0;i<n;i+=6)
    {
        sfd(a);
        sfd(b);
        sfd(c);
        x[i+0]= a; y[i+0]= b; z[i+0]= c;
        x[i+1]= c; y[i+1]= b; z[i+1]= a;
        x[i+2]= b; y[i+2]= a; z[i+2]= c;
        x[i+3]= c; y[i+3]= a; z[i+3]= b;
        x[i+4]= a; y[i+4]= c; z[i+4]= b;
        x[i+5]= b; y[i+5]= c; z[i+5]= a;

    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if((x[j]<x[i]&&y[j]<y[i])||(x[j]<y[i]&&y[j]<x[i]))
               {
                   swap(x[i],x[j]);
                   swap(y[i],y[j]);
                   swap(z[i],z[j]);
               }
        }
    }
    for(i=0;i<n;i++)
    {
        dp[i]=z[i];
        for(j=0;j<i;j++)
        {
            if((x[j]<x[i]&&y[j]<y[i])||(x[j]<y[i]&&y[j]<x[i]))
               dp[i]=max(dp[i],dp[j]+z[i]);
        }
    }
    cout<<*max_element(dp,dp+n)<<endl;
    sfd(N);
    }
    return 0;
}
