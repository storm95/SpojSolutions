#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long int n,i,ir,or[1001],mir=0,mor=0,tempir=0;
        scanf("%llu",&n);
        for(i=1;i<=n;i++)
        {
            scanf("%llu%llu",&ir,&or[i]);
            if(mir<ir)
            {
                mir=ir;
                tempir=i;
            }
        }
        for(i=1;i<=n;i++)
{
    if(tempir!=i )
    {

             if(mor<or[i])
            {
                mor=or[i];
            }
    }
}



        if(mir>mor)
            printf("%llu\n",tempir);
        else
            printf("-1\n");
    }
    return 0;
}