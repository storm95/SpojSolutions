#include <bits/stdc++.h>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<sstream>

using namespace std;

int main()
{
    int t,n,i;
    long long int r[1000],R[1000],m,p,M,P;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(i=0;i<n;i++)
            {
                 scanf("%lld",&r[i]);
                 scanf("%lld",&R[i]);
            }
         m=-10;
         p=-10;
          for(i=0;i<n;i++)
          {
              if(r[i]>m)
              {
                  m=r[i];
                  p=i;
              }
          }
          M=-10;
          for(i=0;i<n;i++)
          {
              if(R[i]>M&&i!=p)
              {
                  M=R[i];
              }
          }
          if(M<m)
            printf("%d\n",p+1);
          else
            printf("-1\n");
    }
    return 0;
}
