#include<cstdio>
using namespace std;
int main()
{
    int test,n,i,temp,temp2,pos;
    scanf("%d",&test);
    while(test--)
    {
        scanf("%d",&n);
        int a[n],b[n];
        for(i=0;i<n;i++)
            scanf("%d %d",&a[i],&b[i]);
        temp=a[0];
        pos=0;
        for(i=1;i<n;i++)
        {
            if(a[i]>temp)
            {
                temp=a[i];
                pos=i;
            }
        }
        if(pos==0)
            temp2=b[1];
        else
            temp2=b[0];
        for(i=1;i<n;i++)
        {
            if(i!=pos)
            {
                if(b[i]>temp2)
                    temp2=b[i];
            }
        }
        if(temp>temp2)
            printf("%d\n",pos+1);
        else
            printf("-1\n");
    }
    return 0;
}
